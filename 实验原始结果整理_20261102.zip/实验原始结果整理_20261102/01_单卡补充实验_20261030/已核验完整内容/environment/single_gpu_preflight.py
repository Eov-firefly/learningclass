"""Independent one-GPU CUDA/BF16/Triton preflight; no model or data access."""
import importlib.metadata
import json
import sys

import torch
import triton
import triton.language as tl
import xgrammar  # noqa: F401
import google.protobuf  # noqa: F401


@triton.jit
def add_one(x, y, n: tl.constexpr, BLOCK: tl.constexpr):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    tl.store(y + idx, tl.load(x + idx, mask=idx < n, other=0) + 1, mask=idx < n)


def main():
    packages = ('torch', 'triton', 'transformers', 'tokenizers', 'xgrammar',
                'accelerate', 'sentencepiece', 'protobuf')
    versions = {p: importlib.metadata.version(p) for p in packages}
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('Exactly one visible CUDA GPU required; found %d' % torch.cuda.device_count())
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError('Visible GPU does not support BF16')
    props = torch.cuda.get_device_properties(0)
    x = torch.arange(1024, device='cuda:0', dtype=torch.float32)
    y = torch.empty_like(x)
    add_one[(4,)](x, y, 1024, BLOCK=256)
    a = torch.ones((16, 16), device='cuda:0', dtype=torch.bfloat16)
    b = a @ a
    torch.cuda.synchronize()
    if not torch.equal(y, x + 1):
        raise RuntimeError('Triton kernel returned incorrect values')
    if not torch.equal(b, torch.full_like(b, 16)):
        raise RuntimeError('BF16 matrix multiplication returned incorrect values')
    print(json.dumps({'python': sys.version, 'versions': versions,
                      'torch_cuda': torch.version.cuda, 'gpu': props.name,
                      'gpu_total_bytes': props.total_memory,
                      'triton_kernel': 'pass', 'bf16_matmul': 'pass'}, indent=2))


if __name__ == '__main__':
    main()
