#!/usr/bin/env python3
"""Download independent wheel snapshots and verify against PyTorch index SHA256."""
import concurrent.futures
import hashlib
import os
import pathlib
import shutil
import sys
import time
import urllib.request

BASE = 'https://mirrors.nju.edu.cn/pytorch/whl/'
JOBS = [
    ('torch-2.6.0+cu124-cp311-cp311-linux_x86_64.whl', 'cu124/torch-2.6.0%2Bcu124-cp311-cp311-linux_x86_64.whl', 768460593, 'd4c3e9a8d31a7c0fcbb9da17c31a1917e1fac26c566a4cfbd8c9568ad7cade79', '/tmp/pip-unpack-wwkigcee/torch-2.6.0+cu124-cp311-cp311-linux_x86_64.whl'),
    ('triton-3.2.0-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl', 'triton-3.2.0-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl', 166673743, 'f1679fde231fb04c96cb5a01b160c8d0294ce6f7c122565d8b33ad8a910422d7', None),
]

def fetch(job):
    name, remote, total, expected, snapshot = job
    partial = pathlib.Path(name + '.partial')
    final = pathlib.Path(name)
    if partial.exists() or final.exists():
        raise RuntimeError('refusing to overwrite: ' + name)
    if snapshot:
        size = min(os.stat(snapshot).st_size, total)
        with open(snapshot, 'rb') as src, open(partial, 'xb') as dst:
            left = size
            while left:
                block = src.read(min(left, 1024 * 1024))
                if not block: raise RuntimeError('source shrank during snapshot')
                dst.write(block)
                left -= len(block)
        print(name, 'snapshot bytes', size, flush=True)
    else:
        partial.touch(exist_ok=False)
    for attempt in range(1, 6):
        offset = partial.stat().st_size
        if offset == total: break
        try:
            req = urllib.request.Request(BASE + remote, headers={'Range': f'bytes={offset}-'})
            with urllib.request.urlopen(req, timeout=45) as response:
                cr = response.headers.get('Content-Range', '')
                if response.status != 206 or not cr.startswith(f'bytes {offset}-') or not cr.endswith(f'/{total}'):
                    raise RuntimeError(f'bad range response {response.status} {cr}')
                with open(partial, 'ab') as dst:
                    shutil.copyfileobj(response, dst, length=1024*1024)
            print(name, 'downloaded bytes', partial.stat().st_size, flush=True)
        except Exception as exc:
            print(name, 'attempt', attempt, 'error', repr(exc), flush=True)
            if attempt == 5: raise
            time.sleep(3*attempt)
    if partial.stat().st_size != total: raise RuntimeError('incorrect size: ' + name)
    h = hashlib.sha256()
    with open(partial, 'rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
    digest = h.hexdigest()
    print(name, 'sha256', digest, 'expected', expected, flush=True)
    if digest != expected: raise RuntimeError('SHA mismatch: ' + name)
    os.rename(partial, final)
    print(name, 'VERIFIED', flush=True)

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(fetch, job) for job in JOBS]
        for future in futures: future.result()
    print('ALL VERIFIED', flush=True)
