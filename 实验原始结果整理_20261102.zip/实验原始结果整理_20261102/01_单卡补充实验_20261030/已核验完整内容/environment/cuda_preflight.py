"""Server-side preflight: require two actual BF16 GPUs and compile/run Triton on each.
This does not load model weights, use experiment data, or start inference.
"""
import importlib.metadata
import json
import sys

import torch
import triton
import triton.language as tl
import xgrammar  # noqa: F401


@triton.jit
def _add_one(x, y, n: tl.constexpr, BLOCK: tl.constexpr):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    tl.store(y + idx, tl.load(x + idx, mask=idx < n, other=0) + 1, mask=idx < n)


def main():
    names = ['torch', 'triton', 'transformers', 'tokenizers', 'xgrammar', 'accelerate', 'sentencepiece']
    versions = {name: importlib.metadata.version(name) for name in names}
    if not torch.cuda.is_available() or torch.cuda.device_count() < 2:
        raise RuntimeError('Two CUDA devices required; found %d' % torch.cuda.device_count())
    gpus = []
    for idx in range(2):
        with torch.cuda.device(idx):
            if not torch.cuda.is_bf16_supported():
                raise RuntimeError('GPU %d has no BF16 support' % idx)
            x = torch.arange(1024, device='cuda', dtype=torch.float32)
            y = torch.empty_like(x)
            _add_one[(4,)](x, y, 1024, BLOCK=256)
            torch.cuda.synchronize()
            if not torch.equal(y, x + 1):
                raise RuntimeError('Triton kernel result mismatch on GPU %d' % idx)
            gpus.append({'index': idx, 'name': torch.cuda.get_device_name(idx), 'triton_kernel': 'pass', 'bf16': True})
    print(json.dumps({'python': sys.version, 'versions': versions, 'torch_cuda': torch.version.cuda, 'gpus': gpus}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
