import gc
import json
import sys
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

key = sys.argv[1]
manifest = json.loads(Path('modelscope-fetch-20261030-a/model_manifest.json').read_text())
entry = manifest[key]
location = entry['local_path']
print(json.dumps({'model': key, 'spec': entry['spec'], 'local_path': location}), flush=True)
assert torch.cuda.device_count() == 1
assert torch.cuda.memory_allocated() == 0
torch.set_num_threads(2)
kw = dict(local_files_only=True, trust_remote_code=False)
tok = AutoTokenizer.from_pretrained(location, **kw)
ids = tok('Model loading preflight.', add_special_tokens=True)['input_ids']
assert ids and all(isinstance(x, int) for x in ids)
print(json.dumps({'tokenizer_loaded': True, 'token_count': len(ids)}), flush=True)
model = AutoModelForCausalLM.from_pretrained(
    location, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True,
    attn_implementation='sdpa', **kw
).to('cuda:0').eval()
param = next(model.parameters())
assert param.device.type == 'cuda' and param.dtype == torch.bfloat16
torch.cuda.synchronize()
print(json.dumps({'model_loaded': True, 'device': str(param.device), 'dtype': str(param.dtype),
                  'allocated_bytes': torch.cuda.memory_allocated()}), flush=True)
del param, model, tok
gc.collect()
torch.cuda.empty_cache()
torch.cuda.synchronize()
remaining = torch.cuda.memory_allocated()
print(json.dumps({'released_allocated_bytes': remaining}), flush=True)
assert remaining == 0
