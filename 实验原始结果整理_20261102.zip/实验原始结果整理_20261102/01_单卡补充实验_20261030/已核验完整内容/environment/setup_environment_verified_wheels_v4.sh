#!/bin/bash
set -euo pipefail
cd /hy-tmp/janus-control-single-20261030
venv/bin/python -m pip install -r source/experiments_v89/requirements.txt protobuf==4.25.3 --index-url https://pypi.tuna.tsinghua.edu.cn/simple --timeout 30
venv/bin/python -m pip check
venv/bin/python single_gpu_preflight.py
printf "setup complete\n"
