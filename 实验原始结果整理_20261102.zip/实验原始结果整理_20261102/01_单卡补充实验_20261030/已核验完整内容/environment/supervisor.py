#!/usr/bin/env python3
"""One-shot, fail-closed single GPU supervision; never resumes inference."""
import argparse, fcntl, json, os, signal, subprocess, sys, time, traceback
from pathlib import Path

def atomic(path, data):
    tmp = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    os.replace(tmp, path)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--evidence', type=Path, required=True)
    p.add_argument('--control', type=Path, required=True)
    p.add_argument('--gpu-uuid', required=True)
    a = p.parse_args(); ev = a.evidence.resolve(); control = a.control.resolve()
    if not a.gpu_uuid.startswith('GPU-') or ',' in a.gpu_uuid: raise ValueError('exact GPU UUID required')
    if control == ev or ev in control.parents: raise ValueError('control must be outside evidence')
    control.mkdir(parents=True, exist_ok=True)
    lock = (control/'supervisor.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (ev/'run/calibrate/stage-started.json').exists() or (ev/'run/execute/stage-started.json').exists() or (ev/'run/orchestrator.lock').exists():
        raise ValueError('prior stage marker or lock exists; no restart')
    marker = control/'supervisor-started.json'
    fd = os.open(marker, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd,'w') as f: json.dump({'pid':os.getpid(),'started_unix':time.time(),'evidence':str(ev),'gpu_uuid':a.gpu_uuid},f)
    logs = ev/'supervision'; logs.mkdir(exist_ok=False)
    env = os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'
    status = {'pid':os.getpid(),'gpu_uuid':a.gpu_uuid,'evidence':str(ev),'started_unix':time.time()}
    child = None
    def status_write(stage, **fields):
        status.update(stage=stage, updated_unix=time.time(), **fields); atomic(control/'supervisor-status.json', status)
    def interrupted(signum, _frame):
        if child is not None and child.poll() is None:
            child.terminate(); child.wait()
        raise RuntimeError('supervisor interrupted; retain evidence, no retry')
    for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,interrupted)
    def run(name,cmd):
        nonlocal child
        status_write(name)
        with (logs/(name+'.log')).open('xb') as f:
            child = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, env=env)
            rc = child.wait(); child = None
        if rc: raise RuntimeError(name+' exited '+str(rc))
    try:
        probe = subprocess.run(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'], capture_output=True, text=True, check=True)
        if [s.strip() for s in probe.stdout.splitlines() if s.strip()] != [a.gpu_uuid]: raise ValueError('expected exactly one matching GPU')
        base = [sys.executable,str(ev/'adapter/sequential_launcher.py'),'--source',str(ev/'source/controllability_gpu_v1'),'--protocol',str(ev/'protocol'),'--output',str(ev/'run'),'--device',a.gpu_uuid]
        for phase in ('plan','calibrate','execute'):
            run(phase,base+['--stage',phase])
        run('analysis',[sys.executable,str(ev/'source/controllability_gpu_v1/analyze.py'),'--protocol',str(ev/'protocol'),'--run',str(ev/'run/execute'),'--out',str(ev/'analysis')])
        checks = json.loads((ev/'analysis/checks.json').read_text())
        if checks.get('status') != 'READY_FOR_INTERPRETATION': raise ValueError('analysis did not pass')
        result = {'result':'passed','gpu_uuid':a.gpu_uuid,'checks_status':checks['status'],'finished_unix':time.time()}
        atomic(logs/'supervisor-receipt.json',result)
        status_write('completed',result='passed')
    except BaseException as e:
        if child is not None and child.poll() is None:
            child.terminate(); child.wait()
        (logs/'failure.txt').write_text(traceback.format_exc())
        status_write('failed',result='failed',error=str(e))
        raise
if __name__ == '__main__': main()
