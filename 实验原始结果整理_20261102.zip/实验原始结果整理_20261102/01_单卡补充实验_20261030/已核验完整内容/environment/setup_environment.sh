#!/usr/bin/env bash
set -euo pipefail
cd /hy-tmp/janus-control-single-20261030
export PIP_CACHE_DIR="$PWD/pip-cache"
export HF_HOME="$PWD/hf-cache"
printf '%s\n' 'setup started'
printf '%s  %s\n' 36f042882becc59f2706ee1f37bf29a9575e5d043ac36b51172e6fcce953b31f control-gpu-prepared-20261029.tar.gz | sha256sum -c -
tar -xzf control-gpu-prepared-20261029.tar.gz
python3 -m venv venv
venv/bin/python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu124
venv/bin/python -m pip install -r source/experiments_v89/requirements.txt protobuf==4.25.3
venv/bin/python -m pip check
venv/bin/python single_gpu_preflight.py
printf '%s\n' 'setup complete'
