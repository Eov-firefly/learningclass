"""Download manifest-pinned bytes from ModelScope; never overwrite evidence."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import urllib.parse
import urllib.request

EXPECTED = {
    'qwen': {'id': 'Qwen/Qwen2.5-7B-Instruct-1M', 'revision': 'e28526f7bb80e2a9c8af03b831a9af3812f18fba'},
    'mistral': {'id': 'mistralai/Mistral-7B-Instruct-v0.3', 'revision': 'c170c708c41dac9275d15a8fff4eca08d52bab71'},
}
BASE = 'https://modelscope.cn/api/v1/models/'

def write_json(path, obj):
    with path.open('x') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', required=True, type=Path)
    p.add_argument('--run-dir', required=True, type=Path)
    p.add_argument('--workers', type=int, default=4, choices=range(1, 9))
    a = p.parse_args()
    manifest_bytes = a.manifest.read_bytes()
    m = json.loads(manifest_bytes)
    if set(m) != set(EXPECTED): raise ValueError('Unexpected models')
    for name, spec in EXPECTED.items():
        entry = m[name]
        if entry.get('spec') != spec or entry.get('hash_weights') is not True or not entry.get('files'): raise ValueError('Invalid model specification: ' + name)
        for file, info in entry['files'].items():
            q = PurePosixPath(file)
            if q.is_absolute() or '..' in q.parts or str(q) != file or not q.parts: raise ValueError('Unsafe path: ' + file)
            if not isinstance(info.get('bytes'), int) or info['bytes'] < 0 or not re.fullmatch('[a-f0-9]{64}', info.get('sha256','')): raise ValueError('Invalid size/hash: '+file)
    a.run_dir.mkdir(parents=True, exist_ok=False)
    provenance = {'source': 'https://modelscope.cn', 'source_revision': 'master', 'original_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(), 'original_huggingface_specs': EXPECTED, 'metadata': {}}
    for name, spec in EXPECTED.items():
        url = BASE + spec['id'] + '/repo/files?Revision=master&Recursive=true'
        with urllib.request.urlopen(url, timeout=45) as r: data = json.load(r)
        files = {v['Path']: v for v in data['Data']['Files']}
        for file, info in m[name]['files'].items():
            f = files.get(file)
            if not f or f.get('Size') != info['bytes'] or f.get('Sha256') != info['sha256']: raise ValueError('Mirror metadata mismatch: '+name+'/'+file)
            provenance['metadata'][name+'/'+file] = {'sha256': f['Sha256'], 'size': f['Size'], 'mirror_file_revision': f.get('Revision')}
    write_json(a.run_dir/'provenance.json', provenance)
    def fetch(task):
        name, spec, file, info = task
        dest = a.run_dir/'models'/name/file
        dest.parent.mkdir(parents=True, exist_ok=True)
        url = BASE + spec['id'] + '/repo?' + urllib.parse.urlencode({'Revision':'master','FilePath':file})
        h = hashlib.sha256(); count = 0
        print('START', name, file, flush=True)
        with urllib.request.urlopen(url, timeout=120) as response, (dest.with_name(dest.name+'.partial')).open('xb') as out:
            while True:
                block = response.read(8 * 1024 * 1024)
                if not block: break
                out.write(block); h.update(block); count += len(block)
            out.flush(); os.fsync(out.fileno())
        if count != info['bytes'] or h.hexdigest() != info['sha256']: raise ValueError('Downloaded content mismatch: '+name+'/'+file)
        os.rename(dest.with_name(dest.name+'.partial'), dest)
        print('VERIFIED', name, file, count, h.hexdigest(), flush=True)
    tasks = [(name, spec, file, info) for name,spec in EXPECTED.items() for file,info in m[name]['files'].items()]
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        list(pool.map(fetch, tasks))
    result = {name: {'spec':spec, 'local_path':str((a.run_dir/'models'/name).resolve()), 'hash_weights':True, 'files':m[name]['files']} for name,spec in EXPECTED.items()}
    write_json(a.run_dir/'model_manifest.json', result)
    print('ALL FILES VERIFIED', flush=True)

if __name__ == '__main__': main()
