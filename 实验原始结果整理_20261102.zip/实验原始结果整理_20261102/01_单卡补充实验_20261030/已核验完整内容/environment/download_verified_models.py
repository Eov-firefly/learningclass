"""Download only the original manifest files at fixed revisions and verify all bytes."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re

from huggingface_hub import hf_hub_download

EXPECTED = {
    'qwen': {'id': 'Qwen/Qwen2.5-7B-Instruct-1M', 'revision': 'e28526f7bb80e2a9c8af03b831a9af3812f18fba'},
    'mistral': {'id': 'mistralai/Mistral-7B-Instruct-v0.3', 'revision': 'c170c708c41dac9275d15a8fff4eca08d52bab71'},
}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', type=Path, required=True)
    ap.add_argument('--hf-home', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    if args.output.exists():
        raise SystemExit('Output already exists; refusing to overwrite')
    source = json.loads(args.manifest.read_text())
    if set(source) != set(EXPECTED):
        raise ValueError('Source must contain exactly the two expected models')
    # Validate the entire manifest before any network requests.
    for name, spec in EXPECTED.items():
        entry = source[name]
        if entry.get('spec') != spec or entry.get('hash_weights') is not True or not entry.get('files'):
            raise ValueError('Unexpected model spec, missing files, or incomplete weight hashes: ' + name)
        for filename, info in entry['files'].items():
            path = PurePosixPath(filename)
            if path.is_absolute() or '..' in path.parts or str(path) != filename or not path.parts:
                raise ValueError('Unsafe manifest filename: ' + filename)
            if not isinstance(info.get('bytes'), int) or info['bytes'] < 0 or not re.fullmatch(r'[0-9a-f]{64}', info.get('sha256', '')):
                raise ValueError('Missing exact size or SHA256: ' + filename)
    output = {}
    for name, spec in EXPECTED.items():
        snapshot = None
        for filename, info in source[name]['files'].items():
            print('Downloading/verifying', name, filename, flush=True)
            local = Path(hf_hub_download(repo_id=spec['id'], revision=spec['revision'],
                           filename=filename, cache_dir=str(args.hf_home / 'hub')))
            base = local
            for _ in PurePosixPath(filename).parts:
                base = base.parent
            if snapshot is None:
                snapshot = base
            elif snapshot != base:
                raise RuntimeError('Inconsistent snapshot directory')
            if local.stat().st_size != info['bytes'] or digest(local) != info['sha256']:
                raise RuntimeError('Size/SHA256 mismatch for %s/%s' % (name, filename))
        output[name] = {'spec': spec, 'local_path': str(snapshot.absolute()),
                        'hash_weights': True, 'files': source[name]['files']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # O_EXCL prevents replacing an earlier attestation.
    with args.output.open('x') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    print('All manifest files verified; output:', args.output, flush=True)


if __name__ == '__main__':
    main()
