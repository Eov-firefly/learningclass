#!/usr/bin/env bash
set -euo pipefail
cd /hy-tmp/janus-control-single-20261030
export PIP_CACHE_DIR="$PWD/pip-cache"
export HF_HOME="$PWD/hf-cache"
python3 -m pip --python "$PWD/venv/bin/python" install pip==25.0.1
venv/bin/python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu124
venv/bin/python -m pip install -r source/experiments_v89/requirements.txt protobuf==4.25.3
venv/bin/python -m pip check
venv/bin/python single_gpu_preflight.py
printf '%s\n' 'setup complete'
