#!/usr/bin/env bash
set -euo pipefail
cd /hy-tmp/janus-control-single-20261030
export PIP_CACHE_DIR="$PWD/pip-cache" HF_HOME="$PWD/hf-cache"
printf '%s\n' 'd4c3e9a8d31a7c0fcbb9da17c31a1917e1fac26c566a4cfbd8c9568ad7cade79  wheel-verified-accelerator-20261030-a/torch-2.6.0+cu124-cp311-cp311-linux_x86_64.whl' 'f1679fde231fb04c96cb5a01b160c8d0294ce6f7c122565d8b33ad8a910422d7  wheel-verified-accelerator-20261030-a/triton-3.2.0-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl' 'db36cdc64bf61b9b24578b6f7bab1ecdd2452cf008f34faa33776680c26d66f8  wheel-verified-sympy-accelerator-20261030/sympy-1.13.1-py3-none-any.whl' | sha256sum -c -
venv/bin/python -m pip install 'filelock==4.2.4' 'typing_extensions==4.16.0' 'networkx==3.6.1' 'jinja2==3.1.6' 'fsspec==2026.9.0' 'mpmath==1.3.0' 'MarkupSafe==3.0.3' --index-url https://mirror.nju.edu.cn/pypi/web/simple
venv/bin/python -m pip install "$PWD/wheel-verified-accelerator-20261030-a/torch-2.6.0+cu124-cp311-cp311-linux_x86_64.whl" "$PWD/wheel-verified-accelerator-20261030-a/triton-3.2.0-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl" "$PWD/wheel-verified-sympy-accelerator-20261030/sympy-1.13.1-py3-none-any.whl" --index-url https://download.pytorch.org/whl/cu124
venv/bin/python -m pip install -r source/experiments_v89/requirements.txt protobuf==4.25.3 --index-url https://mirror.nju.edu.cn/pypi/web/simple
venv/bin/python -m pip check
venv/bin/python single_gpu_preflight.py
printf '%s\n' 'setup complete'
