#!/usr/bin/env python3
"""Fail-closed single-GPU evidence bundle, offline verification and shutdown guard."""
import argparse,hashlib,json,os,pathlib,socket,stat,subprocess,sys,time,zipfile
from datetime import datetime,timezone
sys.dont_write_bytecode=True
P=pathlib.Path
OFFICIAL=P('/usr/local/bin/shutdown')
OFFICIAL_SHA='30b9ea6f23173078ccfe57d9b15ffe8caf5ba1442477f32c2c170ea0e97771d7'
SOURCE_HASH='fc218c301a171c0cca7d69a34365d2c84aedd0ca6672dff35173e1dd39d7b04f'

def fail(s): raise ValueError(s)
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def regular(p):
 if p.is_symlink() or not p.is_file(): fail('not a regular file: '+str(p))
def write_new(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:
  json.dump(v,f,ensure_ascii=False,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
def inventory(root):
 root=root.resolve(); out={}
 if not root.is_dir(): fail('missing evidence directory')
 def err(e): raise e
 for d,dirs,files in os.walk(root,followlinks=False,onerror=err):
  dirs.sort(); files.sort(); q=P(d)
  for x in dirs:
   if (q/x).is_symlink(): fail('symlink directory: '+str(q/x))
  for x in files:
   p=q/x;regular(p); out[p.relative_to(root).as_posix()]={'sha256':digest(p),'size':p.stat().st_size}
 return out
def safe(n):
 p=pathlib.PurePosixPath(n)
 return bool(n) and not p.is_absolute() and all(s not in ('','.', '..') for s in n.split('/')) and '\\' not in n

def layout(root):
 req=['source/controllability_gpu_v1/common.py','source/controllability_gpu_v1/analyze.py','source/controllability_v1/analyze_control.py','source/experiments_v89/janus_min/spec.py','protocol/protocol.json','protocol/public.jsonl','protocol/scoring.jsonl','protocol/languages.json','protocol/models.json','run/calibrate/stage-receipt.json','run/execute/stage-receipt.json','run/execute/stage-started.json','adapter/sequential_launcher.py','environment/manifest.json']
 for x in req: regular(root/x)
 bindings=[]
 for stage in ('calibrate','execute'):
  receipt=json.loads((root/'run'/stage/'stage-receipt.json').read_text())
  if receipt.get('result')!='passed': fail(stage+' did not pass')
  binding=receipt['binding']; bindings.append(binding)
  if binding['source_sha256']!=SOURCE_HASH or binding['protocol_sha256']!=digest(root/'protocol/protocol.json') or binding['adapter_sha256']!=digest(root/'adapter/sequential_launcher.py') or binding['records']!={'qwen':960,'mistral':960}: fail('incorrect binding for '+stage)
  if binding.get('models')!=['qwen','mistral'] or not (binding.get('device')=='0' or str(binding.get('device','')).startswith('GPU-')) or binding.get('sequential') is not True: fail('unexpected execution design')
  started=json.loads((root/'run'/stage/'stage-started.json').read_text())
  if started.get('binding')!=binding: fail('started marker binding mismatch')
  for model in ('qwen','mistral'):
   for f in (model+'.exit.json',model+'.s0.log'): regular(root/'run'/stage/f)
   e=json.loads((root/'run'/stage/(model+'.exit.json')).read_text())
   if e.get('model')!=model or e.get('exit_code')!=0: fail(stage+' exit failure: '+model)
 if bindings[0]!=bindings[1]: fail('calibration and execution bindings differ')
 calibration=json.loads((root/'run/calibrate/stage-receipt.json').read_text())['artifacts']
 required_calibration=set()
 for model in ('qwen','mistral'):
  required_calibration.update({model+'.s0.log',model+'.exit.json'})
  for suffix in ('calibration','environment','eta'):
   matches=list((root/'run/calibrate').glob(model+'.s0.eta.json' if suffix=='eta' else model+'.s0.*.'+suffix+'.json'))
   if len(matches)!=1: fail('missing calibration evidence')
   required_calibration.add(matches[0].name)
 if set(calibration)!=required_calibration: fail('calibration artifact manifest incomplete')
 for name,sha in calibration.items():
  if not safe(name) or '/' in name or digest(root/'run/calibrate'/name)!=sha: fail('calibration artifact hash mismatch')
 if not calibration: fail('empty calibration manifest')
 if (root/'run/orchestrator.lock').exists(): fail('orchestrator lock remains')
 for model in ('qwen','mistral'): regular(root/'run/execute'/(model+'.s0.raw.jsonl'))

def bundle(a):
 root=a.evidence.resolve(); output=a.archive.resolve()
 if output.is_relative_to(root): fail('archive must be outside evidence')
 layout(root); before=inventory(root)
 if 'MANIFEST.json' in before: fail('reserved manifest path in evidence')
 if not a.gpu_uuid.startswith('GPU-'): fail('invalid GPU UUID')
 if output.exists(): fail('archive exists')
 with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name in before: z.write(root/name,name)
  z.writestr('MANIFEST.json',json.dumps({'schema':'janus-single-evidence-v1','hostname':socket.gethostname(),'gpu_uuid':a.gpu_uuid,'files':before},sort_keys=True))
 if inventory(root)!=before: fail('evidence changed during archive; preserve and inspect')
 print(json.dumps({'archive_sha256':digest(output),'files':len(before)}))

def extract(a):
 regular(a.archive)
 if a.out.exists(): fail('extract output already exists')
 with zipfile.ZipFile(a.archive) as z:
  names=z.namelist()
  if len(names)!=len(set(names)) or any(not safe(n) or n.endswith('/') for n in names): fail('unsafe archive names')
  m=json.loads(z.read('MANIFEST.json'))
  if m.get('schema')!='janus-single-evidence-v1' or set(names)!=set(m['files'])|{'MANIFEST.json'}: fail('manifest mismatch')
  for i in z.infolist():
   if stat.S_ISLNK(i.external_attr>>16): fail('symlink archive entry')
  z.extractall(a.out)
  (a.out/'MANIFEST.json').unlink()
  if inventory(a.out)!=m['files']: fail('archive file hash mismatch')
 return m

def verify(a):
 m=extract(a); root=a.out.resolve();layout(root)
 # Compare every archived source file to an independent, previously frozen local copy.
 if {k:v for k,v in inventory(root/'source').items() if not ('/__pycache__/' in '/'+k and k.endswith('.pyc'))}!={k:v for k,v in inventory(a.trusted_source).items() if not ('/__pycache__/' in '/'+k and k.endswith('.pyc'))}: fail('source differs from trusted local source')
 sys.path.insert(0,str(root/'source/controllability_gpu_v1'))
 import common
 plan,public,languages,_=common.load_protocol(root/'protocol')
 if plan['source_sha256']!=SOURCE_HASH or len(public)!=64 or plan['total_records']!=1920: fail('wrong protocol size or source')
 expected={j['request_id']:j for model in common.MODEL_SPECS for j in common.jobs(public,languages,model)}
 if len(expected)!=1920: fail('non-unique expected grid')
 seen={}
 for f in sorted((root/'run/execute').glob('*.raw.jsonl')):
  for r in common.read_jsonl(f):
   rid=r.get('request_id')
   if rid in seen or rid not in expected or any(r.get(k)!=v for k,v in expected[rid].items()): fail('unexpected or duplicate record')
   seen[rid]=r
 if set(seen)!=set(expected): fail('incomplete grid')
 analysis=a.out.parent/(a.out.name+'-offline-analysis')
 if analysis.exists(): fail('offline analysis output exists')
 cmd=[sys.executable,str(root/'source/controllability_gpu_v1/analyze.py'),'--protocol',str(root/'protocol'),'--run',str(root/'run/execute'),'--out',str(analysis)]
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=600)
 if r.returncode or json.loads((analysis/'checks.json').read_text()).get('status')!='READY_FOR_INTERPRETATION': fail('offline analysis did not pass: '+r.stdout[-4000:]+' '+r.stderr[-4000:])
 ack={'schema':'janus-single-local-verified-v1','archive_sha256':digest(a.archive),'hostname':m['hostname'],'gpu_uuid':m['gpu_uuid'],'files':m['files'],'records':len(seen),'source_sha256':SOURCE_HASH,'protocol_sha256':digest(root/'protocol/protocol.json'),'analysis_checks_sha256':digest(analysis/'checks.json'),'verified_at_utc':datetime.now(timezone.utc).isoformat()}
 write_new(a.ack,ack);print(json.dumps({'status':'PASS','records':len(seen),'archive_sha256':ack['archive_sha256']}))

def cmd(args):
 r=subprocess.run(args,capture_output=True,text=True,timeout=20)
 if r.returncode: fail('command failed: '+args[0]+': '+r.stderr.strip())
 return r.stdout.strip()

# Only the provider's observed root-owned service manager is exempt. Its
# children are still inspected individually and receive no exemption.
MANAGER_FILES={
 '/usr/local/bin/supervisord':'2e671ba1962ceb41d5be45a953d3b588f02ce6e89428c4b34c2d876b1c03609b',
 '/usr/bin/python3.11':'9f0012c128d189eb3bdd43281614f6526e670e9cf5bed4cfc1cc395b2c0a3ab1',
 '/usr/bin/tini':'274f2bed211788a4fcb52d14f93ab6e7c44528493b56af5812a1cfe8ae1d2064',
 '/etc/supervisor/supervisord.conf':'cbe9acfee8295cc08633c90e501354cb30b9ad96e0d997cfe4c0d176bb342e30',
}
MANAGER_ARGS=['/usr/bin/python3.11','/usr/local/bin/supervisord','-c','/etc/supervisor/supervisord.conf']
TINI_ARGS=['tini','--','/usr/local/bin/supervisord','-c','/etc/supervisor/supervisord.conf']

def trusted_manager_file(path,expected):
 p=P(path); s=p.lstat()
 return stat.S_ISREG(s.st_mode) and s.st_uid==0 and not s.st_mode&0o022 and digest(p)==expected

def known_service_manager(p,args):
 if args!=MANAGER_ARGS: return False
 try:
  uid=(p/'status').read_text().split('Uid:',1)[1].splitlines()[0].split()
  if uid!=['0']*4 or (p/'exe').resolve(strict=True)!=P('/usr/bin/python3.11'): return False
  parent=int((p/'stat').read_text().rsplit(')',1)[1].split()[1])
  q=p.parent/str(parent)
  puid=(q/'status').read_text().split('Uid:',1)[1].splitlines()[0].split()
  pargs=[x.decode('utf8','replace') for x in (q/'cmdline').read_bytes().split(b'\0') if x]
  if puid!=['0']*4 or pargs!=TINI_ARGS or (q/'exe').resolve(strict=True)!=P('/usr/bin/tini'): return False
  return all(trusted_manager_file(path,h) for path,h in MANAGER_FILES.items())
 except (OSError,ValueError,IndexError): return False

def idle(gpu):
 devices=cmd(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader']).splitlines()
 if devices!=[gpu] or not gpu.startswith('GPU-'): fail('unexpected GPU identity')
 if cmd(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader']): fail('GPU compute processes present')
 own={os.getpid()}; pid=os.getpid()
 while pid>1:
  pid=int((P('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[1]); own.add(pid)
 for p in P('/proc').iterdir():
  if not p.name.isdecimal() or int(p.name) in own: continue
  try: data=(p/'cmdline').read_bytes()
  except FileNotFoundError: continue
  except OSError as e: fail('cannot inspect process '+p.name+': '+str(e))
  args=[x.decode('utf8','replace') for x in data.split(b'\0') if x]
  if args and (P(args[0]).name.lower().startswith(('python','pypy','vllm','ollama','triton','jupyter')) or any('sequential_launcher.py' in s or 'controllability_gpu_v1/run.py' in s for s in args)):
   if not known_service_manager(p,args): fail('active compute/experiment process '+p.name)

def guard(a):
 root=a.evidence.resolve()
 if any(x.resolve().is_relative_to(root) for x in (a.archive,a.ack,a.receipt)): fail('archive, ACK and receipt must be outside live evidence root')
 regular(a.archive);regular(a.ack);ack=json.loads(a.ack.read_text());layout(a.evidence)
 if ack.get('schema')!='janus-single-local-verified-v1' or ack.get('records')!=1920 or ack.get('source_sha256')!=SOURCE_HASH or ack.get('archive_sha256')!=digest(a.archive) or ack.get('hostname')!=socket.gethostname() or ack.get('files')!=inventory(a.evidence): fail('ACK or evidence mismatch')
 regular(OFFICIAL);s=OFFICIAL.stat()
 if s.st_uid!=0 or not s.st_mode&stat.S_IXUSR or digest(OFFICIAL)!=OFFICIAL_SHA: fail('official shutdown mismatch')
 if a.receipt.exists() or a.receipt.is_symlink(): fail('prior shutdown receipt exists')
 idle(ack['gpu_uuid']);time.sleep(2);idle(ack['gpu_uuid'])
 if ack['files']!=inventory(a.evidence) or ack['archive_sha256']!=digest(a.archive): fail('evidence changed during idle check')
 if not a.execute: print(json.dumps({'status':'READY_DRY_RUN'}));return
 write_new(a.receipt,{'status':'shutdown_request_starting','at_utc':datetime.now(timezone.utc).isoformat(),'archive_sha256':ack['archive_sha256'],'gpu_uuid':ack['gpu_uuid'],'command':str(OFFICIAL),'official_sha256':OFFICIAL_SHA})
 try:
  r=subprocess.run([str(OFFICIAL)],capture_output=True,text=True,timeout=30)
  result={'status':'command_returned','returncode':r.returncode,'stdout':r.stdout[-4000:],'stderr':r.stderr[-4000:]}
 except Exception as e: result={'status':'outcome_unknown','error':str(e)}
 write_new(P(str(a.receipt)+'.result'),result);print(json.dumps(result))
 if result.get('returncode')!=0: fail('shutdown returned nonzero or outcome unknown')

def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='mode',required=True)
 b=s.add_parser('bundle');b.add_argument('--evidence',type=P,required=True);b.add_argument('--archive',type=P,required=True);b.add_argument('--gpu-uuid',required=True)
 v=s.add_parser('verify');v.add_argument('--archive',type=P,required=True);v.add_argument('--out',type=P,required=True);v.add_argument('--trusted-source',type=P,required=True);v.add_argument('--ack',type=P,required=True)
 g=s.add_parser('guard');g.add_argument('--evidence',type=P,required=True);g.add_argument('--archive',type=P,required=True);g.add_argument('--ack',type=P,required=True);g.add_argument('--receipt',type=P,required=True);g.add_argument('--execute',action='store_true')
 a=p.parse_args();{'bundle':bundle,'verify':verify,'guard':guard}[a.mode](a)
if __name__=='__main__':
 try: main()
 except Exception as e: print('ERROR: '+str(e),file=sys.stderr);sys.exit(2)
