#!/usr/bin/env python3
"""Separate single-GPU orchestrator for frozen two-model workers; no inference retries."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, obj):
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    os.replace(tmp, path)


def calibration_artifacts(out, model_names):
    paths = []
    for model in model_names:
        for suffix in ('calibration', 'environment'):
            matches = list(out.glob(model + '.s0.*.' + suffix + '.json'))
            if len(matches) != 1:
                raise ValueError(model + ' calibration ' + suffix + ' output incomplete')
            paths.extend(matches)
        paths.extend(out / (model + suffix) for suffix in ('.s0.eta.json', '.s0.log', '.exit.json'))
    if not all(path.is_file() for path in paths):
        raise ValueError('calibration evidence missing')
    return {p.name: digest(p) for p in sorted(paths)}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--source', type=Path, required=True, help='frozen controllability_gpu_v1 directory')
    p.add_argument('--protocol', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True, help='new parent directory for calibration and formal stages')
    p.add_argument('--device', default='0', help='single CUDA device identifier or GPU UUID')
    p.add_argument('--stage', choices=['plan', 'calibrate', 'execute'], required=True)
    a = p.parse_args()
    source, protocol, base = a.source.resolve(), a.protocol.resolve(), a.output.resolve()
    if not a.device or ',' in a.device:
        raise ValueError('exactly one CUDA device required')
    sys.path.insert(0, str(source))
    import common
    spec = importlib.util.spec_from_file_location('frozen_worker', source / 'run.py')
    worker = importlib.util.module_from_spec(spec); spec.loader.exec_module(worker)
    plan, public, languages, models = common.load_protocol(protocol)
    model_names = list(common.MODEL_SPECS)
    if len(model_names) != 2:
        raise ValueError('expected exactly two frozen models')
    expected = {m: common.jobs(public, languages, m, 0, 1) for m in model_names}
    if sum(map(len, expected.values())) != plan['total_records']:
        raise ValueError('worker grid differs from frozen plan')
    binding = dict(protocol_sha256=digest(protocol / 'protocol.json'), source_sha256=plan['source_sha256'],
                   adapter_sha256=digest(Path(__file__).resolve()), device=a.device, models=model_names,
                   records={m: len(expected[m]) for m in model_names}, sequential=True)
    if a.stage == 'plan':
        print(json.dumps(binding, indent=2)); return
    base.mkdir(parents=True, exist_ok=True)
    lock = base / 'orchestrator.lock'
    fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.write(fd, str(os.getpid()).encode()); os.close(fd)
    child = None
    completed = False
    def interrupted(signum, frame):
        if child is not None and child.poll() is None:
            child.terminate(); child.wait()
        raise RuntimeError('interrupted; inspect retained state; no automatic retry')
    for sig in (signal.SIGTERM, signal.SIGINT): signal.signal(sig, interrupted)
    try:
        if a.stage == 'execute':
            receipt = base / 'calibrate' / 'stage-receipt.json'
            if not receipt.is_file() or json.loads(receipt.read_text()) != dict(
                binding=binding, result='passed', artifacts=calibration_artifacts(base / 'calibrate', model_names)
            ):
                raise ValueError('matching successful calibration receipt required')
        out = base / a.stage
        out.mkdir(exist_ok=True)
        marker = out / 'stage-started.json'
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f: json.dump(dict(binding=binding, started_unix=time.time()), f)
        if any(out.glob('*.raw.jsonl')):
            raise ValueError('existing raw files; refuse rerun')
        write(out / 'execution_config.json', binding)
        for model in model_names:
            cmd = [sys.executable, str(source / 'run.py'), '--worker', '--model', model, '--shard', '0',
                   '--shards', '1', '--protocol', str(protocol), '--output', str(out)]
            if a.stage == 'calibrate': cmd.append('--calibrate-only')
            env = os.environ.copy()
            env.update(CUDA_VISIBLE_DEVICES=a.device, OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false')
            log_path = out / (model + '.s0.log')
            started = time.time()
            with log_path.open('xb') as log:
                child = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
                rc = child.wait(); child = None
            write(out / (model + '.exit.json'), dict(model=model, exit_code=rc, start_unix=started, end_unix=time.time()))
            if rc != 0: raise RuntimeError(model + ' worker failed; no automatic retry')
            if a.stage == 'execute':
                raw = out / (model + '.s0.raw.jsonl')
                seen = worker.resume_records(raw, expected[model], binding['protocol_sha256'])
                if len(seen) != len(expected[model]): raise ValueError(model + ' incomplete grid')
            else:
                if len(list(out.glob(model + '.s0.*.calibration.json'))) != 1 or not (out / (model + '.s0.eta.json')).is_file():
                    raise ValueError(model + ' calibration output incomplete')
        result = dict(binding=binding, result='passed')
        if a.stage == 'calibrate':
            result['artifacts'] = calibration_artifacts(out, model_names)
        write(out / 'stage-receipt.json', result)
        completed = True
    finally:
        if child is not None and child.poll() is None:
            child.terminate(); child.wait()
        if completed: lock.unlink()

if __name__ == '__main__':
    main()
