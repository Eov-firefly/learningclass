"""Typeset the integrated v8.3 manuscript as a reading PDF and editable TeX.

The Markdown is canonical. This is a local review layout, not a journal class.
TeX is exported as source; this script does not compile or validate TeX.
"""
from pathlib import Path
import html
import re

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parent
MD = ROOT / 'revised_manuscript.md'
PDF = ROOT / 'output/pdf/revised_manuscript.pdf'
TEX = ROOT / 'latex/main.tex'
WIDTH = A4[0] - 68 - 54


def normalize(text):
    for c in '\u2010\u2011\u2012\u2013\u2014\u2212':
        text = text.replace(c, '-')
    return text


def tex_plain(text):
    escapes = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%',
               '$': r'\$', '#': r'\#', '_': r'\_', '{': r'\{',
               '}': r'\}', '~': r'\textasciitilde{}', '^': r'\textasciicircum{}'}
    return ''.join(escapes.get(c, c) for c in normalize(text))


def formatted(text, kind='pdf'):
    # Parse inline code first so literal regexes, underscores and markers survive.
    parts = re.split(r'(`[^`]+`|\*\*[^*]+\*\*|https?://[^\s]+)', normalize(text))
    out = []
    for s in parts:
        if s.startswith('`') and s.endswith('`'):
            out.append('<font face="Courier" size="9">' + html.escape(s[1:-1]) + '</font>'
                       if kind == 'pdf' else r'\texttt{' + tex_plain(s[1:-1]) + '}')
        elif s.startswith('**') and s.endswith('**'):
            out.append('<b>' + html.escape(s[2:-2]) + '</b>'
                       if kind == 'pdf' else r'\textbf{' + tex_plain(s[2:-2]) + '}')
        elif s.startswith(('https://', 'http://')):
            out.append('<link href="' + html.escape(s, quote=True) + '">' + html.escape(s) + '</link>'
                       if kind == 'pdf' else r'\url{' + s + '}')
        else:
            out.append(html.escape(s) if kind == 'pdf' else tex_plain(s))
    return ''.join(out)


class NumberedParagraph(Paragraph):
    """Continuous review line numbers for prose, including split paragraphs."""
    def draw(self):
        super().draw()
        c = self.canv
        c.manuscript_line = getattr(c, 'manuscript_line', 0)
        c.saveState()
        c.setFont('Times-Roman', 7)
        c.setFillColor(colors.HexColor('#777777'))
        for i in range(len(self.blPara.lines)):
            c.manuscript_line += 1
            y = self.height - self.style.fontSize - i * self.style.leading
            c.drawRightString(-14, y, str(c.manuscript_line))
        c.restoreState()


def table_widths(rows):
    # Match the eight manuscript tables to readable column widths, in points.
    header = rows[0]
    if header[0] == 'Contract':
        return [125] + [(WIDTH - 125) / 4] * 4
    if len(header) == 4 and header[0] == 'Model/task':
        return [92] + [(WIDTH - 92) / 3] * 3
    if header[0] == 'Stage':
        return [124, 133, 60, 60, WIDTH - 377]
    if header[1] == 'Policy':
        return [123, 36, 67, 62, 89, WIDTH - 377]
    if header[1] == 'Win / loss':
        return [112, 55, 150, WIDTH - 317]
    if len(header) == 6:
        return [133] + [(WIDTH - 133) / 5] * 5
    if len(header) == 3:
        return [148, 210, WIDTH - 358]
    return [WIDTH / len(header)] * len(header)


def main():
    source = MD.read_text(encoding='utf-8-sig').splitlines()
    base = dict(fontName='Times-Roman', textColor=colors.black,
                allowWidows=0, allowOrphans=0, splitLongWords=True)
    styles = {
        'title': ParagraphStyle('title', **{**base, 'fontName': 'Times-Bold'},
                                fontSize=18, leading=22, spaceAfter=12),
        'meta': ParagraphStyle('meta', **base, fontSize=11, leading=14, spaceAfter=6),
        'note': ParagraphStyle('note', **base, fontSize=9.5, leading=12, spaceAfter=10),
        'body': ParagraphStyle('body', **base, fontSize=12, leading=22, spaceAfter=8),
        'h1': ParagraphStyle('h1', **{**base, 'fontName': 'Times-Bold'}, fontSize=14,
                            leading=17, spaceBefore=12, spaceAfter=9, keepWithNext=True),
        'h2': ParagraphStyle('h2', **{**base, 'fontName': 'Times-Bold'}, fontSize=12.5,
                            leading=16, spaceBefore=9, spaceAfter=7, keepWithNext=True),
        'caption': ParagraphStyle('caption', **base, fontSize=10.5, leading=13,
                                 spaceBefore=6, spaceAfter=7, keepWithNext=True),
        'cell': ParagraphStyle('cell', **base, fontSize=9.4, leading=12),
        'reference': ParagraphStyle('reference', **base, fontSize=10.5, leading=14.5,
                                   spaceAfter=9),
    }
    story = []
    tex = [r'\documentclass[12pt,a4paper]{article}', r'\usepackage[T1]{fontenc}',
           r'\usepackage[utf8]{inputenc}', r'\usepackage[margin=25mm]{geometry}',
           r'\usepackage{array,longtable,booktabs,lineno,setspace}',
           r'\usepackage[hidelinks]{hyperref}', r'\usepackage{url}',
           r'\setlength{\parindent}{0pt}', r'\setlength{\parskip}{6pt}',
           r'\setlength{\emergencystretch}{3em}', r'\begin{document}',
           r'\doublespacing', r'\linenumbers']
    i, references, seen_abstract = 0, False, False
    table_count = 0
    while i < len(source):
        line = source[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith('|'):
            rows = []
            while i < len(source) and source[i].strip().startswith('|'):
                row = [s.strip() for s in source[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+', cell) for cell in row):
                    rows.append(row)
                i += 1
            assert len({len(row) for row in rows}) == 1
            widths = table_widths(rows)
            cells = [[Paragraph(formatted('**' + c + '**' if j == 0 else c), styles['cell'])
                      for c in row] for j, row in enumerate(rows)]
            tab = Table(cells, colWidths=widths, repeatRows=1, hAlign='LEFT')
            tab.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEABOVE', (0, 0), (-1, 0), .7, colors.black),
                ('LINEBELOW', (0, 0), (-1, 0), .45, colors.black),
                ('LINEBELOW', (0, -1), (-1, -1), .7, colors.black),
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F1F1F1')),
                ('LEFTPADDING', (0, 0), (-1, -1), 4),
                ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            story.extend([tab, Spacer(1, 10)])
            # The app compiler validates the TeX separately from this reading-PDF build.
            fractions = [w / WIDTH * .86 for w in widths]
            col = ''.join(r'>{\raggedright\arraybackslash}p{' + f'{f:.4f}' + r'\linewidth}' for f in fractions)
            tex += [r'\begin{singlespace}', r'\small', r'\begin{longtable}{' + col + '}', r'\toprule']
            tex.append(' & '.join(formatted(c, 'tex') for c in rows[0]) + r' \\ \midrule \endhead')
            for row in rows[1:]:
                tex.append(' & '.join(formatted(c, 'tex') for c in row) + r' \\')
            tex += [r'\bottomrule', r'\end{longtable}', r'\normalsize', r'\end{singlespace}']
            table_count += 1
            continue
        if line.startswith('# '):
            kind, line = 'title', line[2:]
            tex.append(r'{\Large\bfseries ' + formatted(line, 'tex') + r'\par}')
        elif line.startswith('### '):
            kind, line = 'h2', line[4:]
            tex.append(r'\subsection*{' + formatted(line, 'tex') + '}')
        elif line.startswith('## '):
            kind, line = 'h1', line[3:]
            seen_abstract = True
            references = line == 'References'
            tex.append(r'\section*{' + formatted(line, 'tex') + '}')
        else:
            kind = ('reference' if references else 'caption' if re.match(r'Table \d+\.', line)
                    else 'note' if line.startswith('Revision dated')
                    else 'meta' if not seen_abstract else 'body')
            tex.append(formatted(line, 'tex') + '\n')
        story.append(NumberedParagraph(formatted(line), styles[kind]))
        i += 1
    assert table_count == 8
    tex.append(r'\end{document}')
    TEX.write_text('\n'.join(tex) + '\n', encoding='utf-8')

    def furniture(canvas, doc):
        canvas.saveState()
        canvas.setFont('Times-Roman', 8)
        canvas.setFillColor(colors.HexColor('#666666'))
        canvas.drawString(68, A4[1] - 28, 'Terminal-answer contracts and monitoring cost')
        canvas.drawRightString(A4[0] - 54, A4[1] - 28, 'Review draft - 24 October 2026')
        canvas.setStrokeColor(colors.HexColor('#BBBBBB'))
        canvas.setLineWidth(.3)
        canvas.line(68, A4[1] - 34, A4[0] - 54, A4[1] - 34)
        canvas.setFillColor(colors.black)
        canvas.setFont('Times-Roman', 9)
        canvas.drawCentredString(A4[0] / 2, 27, str(doc.page))
        canvas.restoreState()

    PDF.parent.mkdir(parents=True, exist_ok=True)
    SimpleDocTemplate(str(PDF), pagesize=A4, leftMargin=68, rightMargin=54,
                      topMargin=48, bottomMargin=45, title=source[0][2:],
                      author='Ya Bai et al.').build(story, onFirstPage=furniture, onLaterPages=furniture)
    print(PDF)
    print(TEX)


if __name__ == '__main__':
    main()
