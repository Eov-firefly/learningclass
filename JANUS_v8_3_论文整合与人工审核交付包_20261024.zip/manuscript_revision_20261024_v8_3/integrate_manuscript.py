"""Integrate completed, frozen follow-up evidence; never alter raw experiments."""
from pathlib import Path
import json
import shutil

ROOT = Path(__file__).resolve().parent
P = ROOT.parent
OLD = P / 'peerj_revision_20261022_v6/output/revision'
OUT = P / 'postrun_analysis_20261024_v8_3'
summary = json.loads((OUT / 'results_summary.json').read_text())
text = (OLD / 'revised_manuscript.md').read_text(encoding='utf-8-sig')

def replace_para(prefix, replacement):
    global text
    parts = text.split('\n\n')
    hits = [i for i, p in enumerate(parts) if p.startswith(prefix)]
    assert len(hits) == 1, (prefix, hits)
    parts[hits[0]] = replacement
    text = '\n\n'.join(parts)

def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |'] + ['| ' + ' | '.join(row) + ' |' for row in rows])

text = text.replace('Revision dated 22 October 2026.', 'Revision dated 24 October 2026.')
scope_corrections = {
    'Model revision pins were recorded; weight bytes were not independently rehashed.':
    'For the initial experiment, model revision pins were recorded but weight bytes were not independently rehashed. The follow-up verified model and tokenizer files against its frozen SHA-256 manifest.',
    'without a latched-completion design, which was not tested.':
    'without a latched-completion design. The follow-up included only an execution-consistency smoke check of this design; its prospective quality and latency efficacy were not evaluated.',
}
for before, after in scope_corrections.items():
    assert text.count(before) == 1, before
    text = text.replace(before, after)
replace_para('Output-token allowances do not directly measure', '''Output-token allowances do not directly measure the cost of delivering an acceptable answer. We evaluate answer-boundary stopping and entropy monitoring in two instruction-tuned language models on GSM8K and ARC-Challenge. An initial frozen protocol produced 25,200 scored calls, including 14,400 main calls and 4,320 isolated timing calls. Completion stopping changed terminal-contract accuracy by 2.33, 0.00, 13.50 and 3.17 percentage points for Qwen/GSM8K, Qwen/ARC-Challenge, Mistral/GSM8K and Mistral/ARC-Challenge, respectively, while reducing mean output tokens by 0.00%-2.59%. All 114 additional credited answers preserved a terminal representation rather than corrected an incorrect baseline prediction. Retrospective scoring under five contracts showed that the gains depended on the accepted format; last-marked-answer extraction eliminated every net accuracy difference. A separate three-GPU follow-up added 400 pilot and 10,800 formal scored timing calls. Its output-matched controls separated boundary processing from entropy monitoring: all 36 session-specific monitor contrasts had positive descriptive 95% intervals. Completion stopping nevertheless increased Qwen latency by approximately 2.5%-2.9%, while Mistral intervals included both gains and losses. The original isolated measurements and concurrent follow-up are reported separately. These results support explicit parser contracts and output-invariant runtime controls, without establishing semantic reasoning improvement, universal speedup or joint token/compute scheduling. Independent human semantic assessment remains pending.''')
replace_para('This study began with an implementation audit', '''This study began with an implementation audit of JANUS, an earlier token-budget experiment. Its tested code did not implement the proposed joint scheduling mechanism: TCJS and TokOnly used identical generation paths. That audit motivated an explicitly narrower, prospective evaluation. The initial experiment evaluated six implemented policies in two models and two tasks, included an output-invariant shadow control, and measured latency separately on an isolated GPU. Subsequent work applied alternative parser contracts to saved outputs, audited token traces, and added a separately frozen three-GPU timing experiment with boundary-only and entropy controls. All generation remained single-request, batch-size-one inference. Concurrent execution across three GPUs is a deployment condition, not a model of tool-using agents, multi-agent workflows or directed acyclic graphs.''')
replace_para('Generation used BF16', '''Generation used BF16, Transformers SDPA, batch size one, greedy decoding, one beam, cache enabled, repetition penalty 1.0, no forced EOS token and no minimum new-token requirement. Every policy in the initial experiment and the new timing experiment performed real inference. The separate retrospective analysis reconstructed stopping outcomes from saved baseline sequences and is explicitly identified as replay in Section 2.7. Each inference call recorded generated token IDs, text, token count, stop reason, parser outcomes, timing and provenance. Token counts include an emitted EOS token. Deterministic algorithms were not enabled, so observed identity checks describe these runs rather than a guarantee across kernels or hardware.''')
replace_para('The parser does not validate document syntax', '''The parser does not validate document syntax before the marker. A marked line inside an unclosed LaTeX display or code fence can satisfy the contract when stopped after its newline. Later closing that wrapper can invalidate the terminal suffix. This behavior is central to interpreting the results: terminal-line validity and complete-document validity are different requirements. Section 2.7 retrospectively evaluates several explicit alternatives without changing the frozen primary contract.''')
replace_para('Quality stages used two NVIDIA', '''Quality stages in the initial experiment used two NVIDIA A800 80 GB PCIe GPUs, one model per GPU. Its latency analysis uses only the separate isolated timing stage. Models ran sequentially on the same physical GPU without other GPU inference jobs. Each model had 24 warmup calls, two per task/policy, for 48 timing warmups. Jobs were shuffled by the frozen seed within each model session; the saved order was independently reconstructed. Qwen ran on 21 October 2026 from 14:07 to 16:26 UTC, followed by Mistral from 16:29 to 19:17 UTC. Model-session order was not counterbalanced. The later concurrent three-GPU experiment is described separately in Section 2.7 and is not pooled with these measurements.''')

methods = '''### 2.7. Frozen follow-up and retrospective sensitivity analyses

The follow-up separates reanalysis from newly executed inference. Retrospective reconstruction used 3,600 saved Uniform trajectories (1,200 development and 2,400 main model/question pairs) to form 10,800 reconstructed policy records. Those records are not additional inference calls or independent observations. Reconstruction matched the recorded token sequences, text, stopping outcomes and scores in the audited comparisons. Main-cohort contract sensitivity uses the same 600 questions per model/task cell as the initial experiment. A mechanism audit inspected all 114 strict-contract Complete-over-Uniform wins. These are computational checks of saved outputs, not independent human semantic judgments.

Five operational contracts were applied to the saved main outputs: the frozen strict terminal rule; a closure-tolerant rule allowing recognized closing wrappers; a wrapper-balanced strict rule; a closure-balanced rule combining closure tolerance with wrapper balance; and a last-marked-answer rule that permits later text. These finite rules do not implement a general Markdown or LaTeX parser, and numeric comparison remains exact. The source snapshot used for the reported sensitivity counts requires a line-start marker. A received alternative implementation also accepts indentation before the marker. Their sole affected main-cohort question changes both policies' absolute correct counts in three Qwen/GSM8K contract cells by one, while all 20 paired accuracy differences and win/loss counts remain unchanged. The preserved parser provenance audit documents both implementations; none of these alternatives replaces the frozen primary endpoint.

A separate trace audit reused 240 SHA-verified trajectories and evaluated 12 parameter combinations (2,880 replay evaluations). The frozen entropy conjunction used threshold 0.01, five stable steps and a minimum of 21 steps. More permissive combinations were exploratory and were not used to replace the deployed rule or select new accuracy results. The previously completed 56-call smoke check and 240-call trace set were reused by hash; five-GPU timing observations were excluded from the three-GPU analysis. No additional quality extension was executed.

The v8.3 protocol first ran a three-GPU timing pilot with 400 scored calls and 120 warmups, using six workers in two waves. Its complete grid, exit codes, barriers, token identity checks and analysis underwent independent AI-agent technical review before a hash-bound decision released formal timing. This operational review was not a human semantic audit. Formal timing comprised 10,800 scored calls: two models, two tasks, 60 questions per task, five policies, three within-session repetitions and three sessions. Eighteen workers ran in six waves with 360 additional warmups. Thus, new generation comprised 11,200 scored calls and 480 warmups. The formal 120 distinct questions are a reused subset of the original main cohort; the three sessions do not add new questions.

Each of three A800 80 GB GPUs ran one independent batch-size-one worker. Models, revisions, allowance of 512 tokens, BF16 precision and SDPA attention were retained. Workers used four assigned CPU cores and two intra-operation and two inter-operation threads. Model order was Qwen then Mistral in sessions 0 and 2 and Mistral then Qwen in session 1. This partly varies order but does not fully counterbalance it. The five follow-up policies were Uniform (U); boundary_observe (BO), which processes the token prefix and parses the boundary without stopping early; Complete (C), which stops at that boundary; entropy_observe (EO), which adds entropy observation to Complete without gating it; and entropy_uniform (EU), which adds entropy observation to BO without early stopping. These five controls differ from the six-policy initial accuracy experiment.

Four prespecified operational contrasts were evaluated: EO-C for added entropy monitoring on the completion path, BO-U for boundary processing without truncation, EU-BO for added entropy monitoring on the full-output path, and C-U for the net effect of completion stopping. Calls were paired by model, task, session, question, repetition and recorded worker/GPU provenance. Within each contrast and session, three repetitions were averaged per question before a paired question-cluster percentile bootstrap (5,000 replicates; seed 20261019; n = 60). All 48 resulting 95% intervals are descriptive and unadjusted for multiple comparisons. The same questions recur across sessions and models; neither repeated calls nor GPU shards are treated as independent questions. Ranges across the three session means are descriptive ranges, not confidence intervals.

The new end-to-end timer starts before tokenization of an already constructed prompt and includes transfer, synchronized generation, token-ID transfer to CPU and decoding. It excludes chat-template construction, model loading, warmups, scoring, logging and network or queue latency. The original end-to-end timer also included chat-template construction and used different CPU thread settings. Hardware sharing, model order and timing boundaries therefore preclude pooling the old isolated, old five-GPU and new three-GPU results or attributing their differences solely to GPU count. The experiment measures paired request latency under concurrent deployment, not aggregate service throughput or a threefold speedup.

'''
assert text.count('## 3. Results') == 1
text = text.replace('## 3. Results', methods + '## 3. Results')

cells = [('qwen', 'gsm8k', 'Qwen/GSM8K'), ('qwen', 'arc', 'Qwen/ARC'), ('mistral', 'gsm8k', 'Mistral/GSM8K'), ('mistral', 'arc', 'Mistral/ARC')]
contracts = [('strict', 'Strict terminal'), ('closure_tolerant', 'Closure-tolerant'), ('wrapper_balanced_strict', 'Wrapper-balanced strict'), ('closure_balanced', 'Closure-balanced'), ('last_marked', 'Last marked answer')]
rows = []
for key, label in contracts:
    vals = []
    for model, task, _ in cells:
        r = next(x for x in summary['contract_sensitivity'] if x['model_task'] == f'{model}/{task}' and x['contract'] == key)
        vals.append(f"{r['difference_percentage_points']:.2f}")
    rows.append([label] + vals)
t6 = table(['Contract'] + [x[2] for x in cells], rows)
monitor_pairs = [('entropy_observe', 'complete'), ('boundary_observe', 'uniform'), ('entropy_uniform', 'boundary_observe')]
rows = []
for model, task, label in cells:
    vals = []
    for policy, control in monitor_pairs:
        r = next(x for x in summary['monitor_session_mean_ranges'] if (x['model'], x['task'], x['policy'], x['control']) == (model, task, policy, control))
        vals.append(f"{r['mean_difference_ms_min']:.2f}-{r['mean_difference_ms_max']:.2f}")
    rows.append([label] + vals)
t7 = table(['Model/task', 'Entropy EO-C (ms)', 'Boundary BO-U (ms)', 'Entropy EU-BO (ms)'], rows)
rows = []
for model, task, label in cells:
    vals = []
    for session in range(3):
        r = next(x for x in summary['formal_contrasts'] if (x['model'], x['task'], x['policy'], x['control'], x['session']) == (model, task, 'complete', 'uniform', session))
        vals.append(f"{r['mean_ms']:.2f} [{r['lo_ms']:.2f}, {r['hi_ms']:.2f}]")
    rows.append([label] + vals)
t8 = table(['Model/task', 'Session 0', 'Session 1', 'Session 2'], rows)

results = f'''### 3.4. Contract sensitivity and trace evidence

The apparent accuracy benefit depends on which output representation a consumer accepts (Table 6). Closure tolerance eliminates the 14 Qwen/GSM8K strict-contract wins; adding a wrapper-balance requirement reverses the Qwen/GSM8K difference under the closure-balanced rule. Last-marked-answer extraction gives zero Complete-Uniform difference in all four model/task cells. These are paired rescoring results on existing outputs and do not show that continuation is semantically harmless.

Table 6. Retrospective Complete-Uniform contract-accuracy differences, in percentage points, on 600 main questions per model/task cell. The columns use the same paired outputs under each operational parser. These alternative endpoints are sensitivity analyses, not new primary tests.

{t6}

The 114 strict-contract wins were mechanically categorized as 13 LaTeX-wrapper cases, one code-fence case, 98 post-answer continuations and two loop cases. The generated prefix and last marked answer value were unchanged in the audited pairs. Two lexical disavowal or placeholder flags overlap these categories; they are not human semantic labels. Under the frozen conjunction settings, the trace audit found 3,116 stable non-EOS steps but no simultaneous answer-boundary opportunity and no early trigger across 240 trajectories. A more permissive exploratory combination produced 16 triggers, which does not validate a revised stopping policy or its accuracy.

### 3.5. Repeated concurrent three-GPU timing

The formal run completed the full 10,800-call scored grid across 18 workers and six waves after the separately reviewed pilot. All three output-invariant monitoring contrasts preserved both generated and returned token IDs. Their 36 model/task/session contrasts yielded 6,480 matched output-pair checks; outputs are reused across contrasts, so this is not a count of independent observations. The pilot had 240 additional matched pair checks. Each formal inference comparison still has 60 question clusters. All 36 descriptive monitoring intervals were above zero, and all 108 corresponding GPU-stratum mean differences were positive. The latter are descriptive point estimates, not 108 independent significance tests or causal GPU effects.

Table 7. Ranges of the three session-specific mean latency differences in the formal concurrent experiment. Each cell is the minimum and maximum of three point estimates, not an interval estimate. EO-C adds entropy monitoring to completion; BO-U adds boundary processing without truncation; EU-BO adds entropy monitoring without truncation. Full session estimates and descriptive bootstrap intervals are retained in the supplement.

{t7}

Boundary processing without early stopping added approximately 91-155 ms per call across the model/task/session cells. Added entropy monitoring ranged from approximately 13-59 ms on the completion path and 20-52 ms on the full-output path. The consistency of the matched-output contrasts isolates overhead from output truncation within this runtime; it does not imply an implementation-independent monitoring cost.

Table 8. Complete-Uniform mean latency differences in milliseconds, with descriptive, unadjusted 95% paired question-cluster bootstrap intervals. Negative values favor completion stopping. Every cell uses 60 questions with three within-session repetitions averaged per question; sessions reuse the same questions.

{t8}

Completion stopping did not produce a stable overall latency improvement. All Qwen session intervals were above zero, corresponding to approximately 2.5%-2.9% more elapsed time despite unchanged or slightly shortened output. Mistral point differences were near zero or positive and every interval spanned zero; these intervals permit both benefit and harm and do not establish equivalence. Mistral's shorter output therefore did not establish a net latency gain in this concurrent setting. The Complete-Uniform contrast includes output differences and is not an output-invariant overhead control. These findings complement, but are not pooled with, the earlier isolated measurements in Tables 4 and 5.

'''
assert text.count('## 4. Discussion') == 1
text = text.replace('## 4. Discussion', results + '## 4. Discussion')
replace_para('The main accuracy differences arise', '''The main accuracy differences arise because the interface accepts a marked final line and rejects later non-whitespace continuation. Stopping preserves an accepted representation; it does not demonstrate additional solved problems. The retrospective contracts make this dependence explicit: closure handling removes the Qwen/GSM8K strict-contract gain, whereas last-marked-answer extraction removes every net difference. Wrapper-balance requirements can instead penalize a truncated response. These operational alternatives are finite parser rules rather than semantic or document-validity oracles. A richer structured-output interface could change the observed benefit, while a tolerant consumer may accept continuation; neither possibility establishes that the continuations are correct or harmless.''')
replace_para('The study contains two approximately', '''The study contains two approximately 7B instruction-tuned models, two tasks, one allowance, one question-sampling/order seed, greedy decoding and batch size one on A800 hardware. The models share questions, and all timing cohorts reuse subsets of the accuracy cohort. Three follow-up sessions add repeated measurements under a concurrent deployment condition, not independent datasets or a budget sweep. The benchmarks do not represent long-horizon agents, tool calls, concurrent service queues, speculative decoding or reasoning-model budget forcing. Model order was fixed in the original experiment and only partly varied in the follow-up. Session-level drift, host contention and different timer boundaries prevent direct attribution of cross-experiment differences to concurrency. Small effects may differ under another runtime.''')
replace_para('Independent human semantic audit is pending.', '''Independent human semantic audit is pending. Two blinded rating packages have been prepared for the same 600 sampled outputs (525 distinct model/task/question identities), drawn in 12 strata from the original 14,400-call main cohort. No human ratings or agreement statistics are complete. Each of two human raters must independently assign correctness and completeness labels of 1, 0 or U, with reasons; U denotes unresolved judgment and must remain visible. Original returns will be sealed before comparison or adjudication. Because the sample enriches contract/diagnostic disagreements, an unweighted mean would not estimate population semantic accuracy. Later analysis must retain inclusion probabilities and report appropriately weighted estimates and unresolved-case sensitivity. Computational audits and AI-agent deployment review do not substitute for this work.''')
replace_para('The record motivates tests of latched completion', '''The record now includes retrospective richer-contract and trace sensitivity analyses and an executed control for boundary processing, but it contains no prospective quality evaluation of latched completion, revised stopping thresholds or a cheaper monitoring implementation. The exploratory trace triggers do not authorize a new accuracy claim. The single-allowance design cannot estimate a budget-response function or validate dynamic allocation. Public release and an independent rerun would strengthen external reproducibility beyond the local computational checks.''')
replace_para('Under a frozen terminal-answer contract, completion stopping', '''Under a frozen terminal-answer contract, completion stopping preserved 114 additional credited answers across 2,400 question/model pairs, with modest or zero token savings. Retrospective alternative contracts changed or eliminated those differences, confirming that they depend on the accepted output representation. Output-invariant controls measured positive boundary-processing and entropy-monitoring costs in a separate three-GPU follow-up, while completion stopping did not establish an overall speedup. The earlier isolated study and later concurrent study support explicit parser contracts, policy-path audits and matched-output runtime controls within their respective conditions. They do not establish semantic reasoning gains, universal acceleration or joint token/compute scheduling. Independent human assessment and public archival release remain outstanding.''')
replace_para('A complete local archive contains', '''Complete local archives contain frozen protocols, revision pins, input manifests, raw outputs, attempt/completion receipts, environment snapshots and analysis scripts. Downloaded bundles were verified before the rental instances were shut down. The 24 October revision adds contract sensitivity, parser provenance, repeated three-GPU timing results, dated offline checks and editable manuscript sources while preserving the frozen experimental files. The supplement includes all 48 formal timing contrasts and the 20 contract-sensitivity cells. A public repository/archive URL and, if obtained, DOI must be inserted after authors approve release and verify redistribution permissions. No public deposit is claimed. Reproduction and human-audit instructions distinguish release material from the private sampling key and unblinding records.''')
# Extend monitoring discussion with the operational decomposition, retaining its original context.
anchor = '### 4.3. Generalization limits and further validation'
assert anchor in text
text = text.replace(anchor, '''The concurrent follow-up further separates the cost of processing a boundary from the incremental cost of entropy. BO-U changes the callback path without shortening the output, whereas C-U combines that overhead with any token savings. Their different results explain why fewer tokens need not reduce elapsed time. The three repeated sessions show consistent positive monitor costs under this implementation, while the net completion effect remains model- and condition-dependent. Positive descriptive intervals across the 36 monitor contrasts should not be read as multiplicity-adjusted confirmatory tests, and ranges of session means should not be read as confidence bounds.

''' + anchor)
(ROOT / 'revised_manuscript.md').write_text(text, encoding='utf-8')
# Copy only evidence already curated for the supplement. Human private key is not included.
sup = ROOT / 'supplement'
sup.mkdir(exist_ok=True)
for name in ['results_summary.json', 'source_manifest.json', 'parser_provenance_audit.json', 'parser_provenance_note.txt', 'formal_contrasts.txt', 'build_summary.py', 'build_report.py']:
    shutil.copy2(OUT / name, sup / name)
for name in ['sources', 'latex_supplement']:
    shutil.copytree(OUT / name, sup / name, dirs_exist_ok=True)
shutil.copy2(OUT / 'README.txt', sup / 'original_analysis_README.txt')
model_receipt = P / 'server_operations_20261023_v8_3/server_backup/1e57f53e927235e24888c6c07d51a7ead747379a41229cdbdc106c868477e26a/verified/project/provenance/model-verification.json'
shutil.copy2(model_receipt, sup / 'sources/model-verification.json')
shutil.copytree(OUT / 'output', sup / 'output', dirs_exist_ok=True)
# Adapt the original reading-layout generator without modifying the original source.
builder = (OLD / 'build_submission.py').read_text()
builder = builder.replace('completed v6 manuscript', 'integrated v8.3 manuscript')
builder = builder.replace('Path(__file__).resolve().parents[2]', 'Path(__file__).resolve().parent')
builder = builder.replace("ROOT / 'output/revision/revised_manuscript.md'", "ROOT / 'revised_manuscript.md'")
builder = builder.replace("ROOT / 'output/revision/revised_manuscript.tex'", "ROOT / 'latex/main.tex'")
builder = builder.replace('the five known tables', 'the eight manuscript tables')
builder = builder.replace("    if header[0] == 'Stage':", "    if header[0] == 'Contract':\n        return [125] + [(WIDTH - 125) / 4] * 4\n    if len(header) == 4 and header[0] == 'Model/task':\n        return [92] + [(WIDTH - 92) / 3] * 3\n    if header[0] == 'Stage':")
builder = builder.replace('assert table_count == 5', 'assert table_count == 8')
builder = builder.replace('22 October 2026', '24 October 2026')
builder = builder.replace("col = ''.join('p{'", "col = ''.join(r'>{\\raggedright\\arraybackslash}p{'")
builder = builder.replace('# TeX is an editable export, never represented as compiled.', '# The app compiler validates the TeX separately from this reading-PDF build.')
(ROOT / 'build_submission.py').write_text(builder)
print(ROOT / 'revised_manuscript.md')
