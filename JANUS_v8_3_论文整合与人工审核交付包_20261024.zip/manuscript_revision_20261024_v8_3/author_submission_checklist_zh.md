# JANUS v8.3 作者提交前检查清单

更新日期：2026-10-24。当前阶段：实验、安全收尾、稿件整合与技术核验已完成；待作者最终校稿、文献原始来源核验及真人语义核验。

这份清单区分“已有实验与技术核验证据”和“仍需作者/真人完成的事项”。方框未勾选不表示一定需要追加 GPU 实验；现阶段主要待办可以在本地完成。本文件不证明论文已经投稿、通过评审，或已经获得不存在的人工标注结果。

## 一、已经完成的技术工作

- [x] 原 v5.1 / v6 实验的 25,200 条计分记录已完成并保留：pilot 480、dev 6,000、main 14,400、独立 timing 4,320。
- [x] 旧轨迹前缀回放及 Completion 身份复现核验完成。离线产生的 10,800 条反事实回放记录与新增推理严格区分。
- [x] v8.2 smoke 56 条、trace 240 条按 SHA 复用；旧五卡延迟不与新三卡结果混池。
- [x] 新三卡 pilot 完成 400 条计分 + 120 条预热；正式 timing 完成 10,800 条计分 + 360 条预热。新增合计 11,200 条计分、480 条预热。
- [x] 正式网格、退出码、屏障、token identity、阶段分析、技术门控和归档核验通过。独立技术审阅按 `ai_agent` 标记；它不是人工语义审核。
- [x] 已形成三卡计时、五契约敏感性、trace 诊断及解析器来源说明。所有新计时区间为冻结分析产生的未校正描述性区间。
- [x] 正文整合完成，共 8 张表（新增表 6–8），本地来源与数值已技术核对；独立 AI 科学技术审阅通过，已修正其两项范围表述发现。审阅不包含人工评分、原始文献逐条核验或作者事实确认。
- [x] LaTeX 源文件已编译通过；从同一 Markdown 生成的 20 页阅读 PDF 已完成视觉核对。二者分别验证，阅读 PDF 不是 LaTeX 导出。
- [x] 两份独立真人评审分发 ZIP、组织者操作指南及只读回收校验脚本已准备并核对；此项只指交接材料，不指真人评分完成。
- [x] 三卡结果与日志已归档到本地，离线验证 258 个文件并回传 ACK。新归档不能替代旧主实验及复用 smoke / trace 的原始归档。
- [x] 已通过安全保护发出关机请求，用户随后确认 SSH 端口 54725 的平台实例为“已关机”；本地记录 `platform_state_confirmed_off=true`、`billing_stop_verified=true`，控制器已结束、巡检已暂停。

关机状态的依据是用户对租赁平台的确认；并非本代理直接读取账单或控制台。北京时间 2026-10-24 03:15 是关机请求时刻，不能写成已经核实的实际停止计费时刻。证据见 [平台状态确认记录](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/server_operations_20261023_v8_3/platform-off-user-confirmation.json)。

三卡完整归档：

[janus-v8_3-three-gpu-timing-1e57f53e927235e24888.tar.gz](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/server_operations_20261023_v8_3/server_backup/1e57f53e927235e24888c6c07d51a7ead747379a41229cdbdc106c868477e26a/janus-v8_3-three-gpu-timing-1e57f53e927235e24888.tar.gz)

归档 SHA-256：`fcbf85e0351c058cae11867eb30b847dddb5b2df45f883963471d8b524e72254`。完整来源及旧数据依赖见 [离线分析说明](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/postrun_analysis_20261024_v8_3/README.txt)。

## 二、优先安排：两名真人的独立语义核验

当前两份评审表均为空白。已准备 600 份输出，对应 525 个不同的模型 × 任务 × 题目组合；需要两名评审分别独立标注相同的 600 份输出，不是每人分担 300 份。

- [ ] 指定两名能独立判断相应题目的真人评审，记录角色与完成日期，明确需要对“语义正确性”和“回答完整性”分别标注。
- [ ] 分别发放 [评审 1 包](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/human_review/for_rater1/rater1_package.zip) 与 [评审 2 包](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/human_review/for_rater2/rater2_package.zip)。每位只拿自己的盲审包，不接触另一人的标注、策略/模型映射、自动评分或 `PRIVATE_sampling_key.json`。
- [ ] 两名评审独立填写 `semantic_correct`、`answer_complete` 和 `reason`；两个判断字段各使用 `1` / `0` / `U`。不得修改题目、输出、样本 ID 或行顺序，不得用 LLM 代填。
- [ ] 原样回收独立的 `rater1_completed.csv`、`rater2_completed.csv`，按组织者指南用只读校验脚本检查各 600 条记录、样本身份、原文、评分和理由；保留原始文件及 SHA。格式通过不等于证明真人独立评分，仍需组织者确认；两份原表封存后才揭盲和讨论分歧。
- [ ] 保留 `U`，包括两人一致为 `U` 的样本；需要仲裁时另存仲裁记录，记录由谁、何时、为何裁定，不能覆盖原始评分。
- [ ] 形成两维标签的完整交叉表和一致性报告，清楚写出全部样本与剔除 `U` 子集的各自分母。
- [ ] 按冻结的 12 个分层及入样概率计算设计加权结果；原抽样各层 50 份不能直接用普通 600 行平均数替代总体估计。重复题目及成对输出不应按独立样本处理。
- [ ] 把 `U` 按失败/成功处理所得的加权上下界标明为不确定标签的界限，而非置信区间。在有效方差估计尚未实现前，不补造普通独立同分布 bootstrap 区间。
- [ ] 如发现题干、参考答案或抽样材料问题，单独记录，不静默更改冻结数据，也不为了结果好看重新抽样。

先阅读本轮[组织者操作指南](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/human_review/组织者操作指南.txt)，只向每位评审分别发放其 ZIP，不发送整个交接目录。回收文件使用[只读校验脚本](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/human_review/validate_returned_ratings.py)核验；每行理由必填，漏填交回原评审，组织者不代填。原抽样与统计方案仍以 [语义核验实施说明](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/peerj_revision_20261022_v6/output/revision/semantic_audit_instructions_zh.md) 为准。600 样本核验是当前研究安排，不应未经核实写成目标期刊规定的固定样本要求。

## 三、作者事实与研究声明

- [ ] 确认作者姓名、顺序、单位、通讯作者联系方式及每位作者对最终稿件的同意；按真实工作填写贡献声明。
- [ ] 确认资助机构、项目号与利益冲突。未知信息保持待确认，不能自动填“无”。
- [ ] 确认真实的 AI 辅助使用范围，区分代码/文本辅助、AI 技术审阅和真人语义标注；按目标期刊当日要求披露，不能将 AI 审阅者列为真人。
- [ ] 根据实际数据来源、参与方式和机构要求核对伦理、许可及隐私声明；没有证据时不得虚构伦理批准号、豁免或人员同意。
- [ ] 确认模型、数据集、代码和题目/输出再分发的许可范围，识别不能公开的文件及匿名化要求。
- [ ] 确认原始投稿意见的准确来源。拒稿关注点用作者持有的原信核对；本轮补充建议不冒充真实审稿意见。

## 四、已完成的稿件技术核对与作者定稿待办

- [x] 全文分清旧 25,200 条主证据、离线 10,800 条反事实回放、新正式 10,800 条计时、400 条新 pilot，以及尚未完成的人工 600 份输出核验；不可把它们相加成独立样本量。
- [x] 原主比较的四个校正区间与原统计方案保留，新计时的未校正描述性 95% 区间不替换旧主比较结论。
- [x] 三卡正式计时注明同一批题目跨重复/session 使用，并注明题目聚类 bootstrap、5,000 次重采样及 session 的共享题目关系；session 均值范围不称为置信区间。
- [x] 描述 EO − C、BO − U、EU − BO 和 C − U 的差别：前几项是对应监控控制的增量，最后一项是 Completion 相对 Uniform 的净延迟，不能把二者混为加速收益。
- [x] 保留三卡结果的限制：36 个监控对比的描述性区间均为正，但不支持总体推理加速；Qwen 的 C − U 更慢，Mistral 的区间跨零不证明等效。
- [x] 明确三卡并发、旧独立计时与旧五卡环境分别报告；线程设置、计时边界、模型执行次序等差异不能略去，也不能用服务器租金推出已实测成本收益。
- [x] 114 个严格契约收益案例只能描述为前缀、解析和最后标记答案值的机械核验。未完成真人核验前，不使用“人工确认语义无害”“推理能力提升”等表述。
- [x] 解析器来源差异已披露：一题两个输出在三个契约下产生六次评分差异；三个 Qwen/GSM8K 绝对计数单元两侧各加一，C − U 差异不变。采用本地回放的绝对数，保留历史原件，不偷偷统一成同一来源。
- [x] 原六策略与新五策略控制的用途分别说明；不把本轮计时描述成已重跑旧策略或补齐未运行的 quality 扩展。
- [x] 整合稿的科学结论和本地实验来源已技术核对；表 6 的 20 个契约差值、表 7 的 12 个 session 均值范围、表 8 的 12 组均值及区间与机器可读结果一致。章节定位为 2.7 方法、3.4 / 表 6 回放与 trace、3.5 / 表 7–8 三卡计时、4.1 / 4.2 讨论、4.3 局限与待人工核验、4.4 历史。
- [x] 当前 LaTeX 编译通过；20 页阅读 PDF 的版式已视觉检查。阅读 PDF 与 LaTeX 源文件同源于整合 Markdown，但阅读 PDF 由 Markdown 构建，LaTeX 编译为另一次独立验证。
- [ ] 作者对题目、摘要、全部正文与 8 张表、补充材料、交叉引用、声明及最终阅读 PDF 做最终校稿；排版检查与 AI 技术审阅不替代作者定稿确认。
- [ ] 逐条核验引文的文献原始来源、题名/作者/年份/永久标识、引用内容与实际支持关系；此项尚未由本轮独立 AI 技术审阅覆盖。

本轮技术审阅范围与绑定版本见[独立 AI 技术审阅记录](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/independent-scientific-review.json)；通过状态不能外推到人工核验、文献逐条核验或后续未经检查的修改。本轮修订依据见 [证据对照表](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/manuscript_revision_20261024_v8_3/revision_response_matrix_zh.md) 和 [解析器来源说明](/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/postrun_analysis_20261024_v8_3/parser_provenance_note.txt)。

## 五、公开材料与正式提交

- [ ] 确定目标期刊及文章类型，并在实际提交日核对官方作者指南、数据政策、AI 披露规则及附件要求；旧版检查记录不能代替当日要求。
- [ ] 建立可访问的代码/数据存档，确认永久链接或 DOI 后再填进稿件。当前本地路径不是公开数据可用性地址。
- [ ] 公开包保留必要的冻结协议、模型/数据版本、分析代码、原始输出、去敏日志和校验说明；排除 SSH 密钥、访问凭据、平台账户资料和其他非研究私有运维信息。
- [ ] 人工核验公开材料另做许可与去标识检查；不要把组织者私有映射表直接混进盲审包或公共仓库。
- [ ] 由作者核对引用与文献元数据、图表许可、补充材料命名、作者贡献与其他声明，确认所有必要附件已齐。
- [ ] 如采用逐条回复信，核对原问题编号与原文，新增证据注明真实来源和实际完成状态；不得把本内部对照表直接当作收到的新审稿信。
- [ ] 所有作者确认最终版本、投稿目标及无一稿多投后，由作者执行正式提交并保存回执。

当前最直接的作者配合事项是安排两名独立语义评审，同时确认作者/资助/利益冲突/AI 辅助声明，并审阅整合后的稿件。当前下一步无需开启 GPU 服务器；如决定追加质量扩展，应先另行确定研究问题与冻结方案。
