#!/usr/bin/env python3
"""Read-only checks of returned human ratings; never assigns or changes ratings.

Usage: python3 validate_returned_ratings.py --rater 1 --file rater1_completed.csv
Exit 0: structurally valid, all ratings/reasons present. Exit 2: incomplete or
invalid ratings/reasons. Exit 1: file, baseline, or structural integrity error.
Passing this check does not establish human authorship, independence or accuracy.
"""
import argparse
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

FIELDS = ['audit_id', 'question', 'output', 'semantic_correct', 'answer_complete', 'reason']
FIXED = FIELDS[:3]
SCORES = FIELDS[3:5]
LABELS = ('1', '0', 'U')
FORM_SHA = '76706cd0fe2b073a4982b93803cc22b60269c0e3b44d2f94045ade8993579baf'
INSTRUCTIONS_SHA = '57862030ccd13de22cd9bf3dc1f7fe1893e283201b6d42ba5e5143b621cf99b5'
PACKAGE_SHA = {
    1: 'c2b4c2343c7661f405c98179d5254a132aeeb5ef288f75219e9cf83b1e481e38',
    2: 'e3a101817ea563628919fb4d94213c06cb4c4bfa8ccc2f35a3e19dff9e459667',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse_csv(raw):
    # A UTF-8 BOM is accepted; content and rating whitespace are not normalized.
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig'), newline=''), strict=True)
    fields = reader.fieldnames
    rows = list(reader)
    return fields, rows


def load_baseline(rater):
    package = Path(__file__).resolve().parent / f'for_rater{rater}' / f'rater{rater}_package.zip'
    raw = package.read_bytes()
    if sha(raw) != PACKAGE_SHA[rater]:
        raise ValueError('Canonical rater package SHA256 mismatch')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        csv_name = f'rater{rater}.csv'
        if sorted(archive.namelist()) != sorted([csv_name, 'rater_instructions_zh.md']):
            raise ValueError('Unexpected canonical package members')
        form = archive.read(csv_name)
        if sha(form) != FORM_SHA or sha(archive.read('rater_instructions_zh.md')) != INSTRUCTIONS_SHA:
            raise ValueError('Canonical package member SHA256 mismatch')
    fields, rows = parse_csv(form)
    if fields != FIELDS or len(rows) != 600 or len({row['audit_id'] for row in rows}) != 600:
        raise ValueError('Canonical form structure mismatch')
    if any(row[field] != '' for row in rows for field in FIELDS[3:]):
        raise ValueError('Canonical form must remain blank')
    return rows


def validate(raw, baseline):
    fields, rows = parse_csv(raw)
    issues = []
    counts = collections.Counter()

    def issue(kind, **details):
        counts[kind] += 1
        if len(issues) < 30:
            issues.append({'kind': kind, **details})

    if fields != FIELDS:
        issue('header_mismatch', expected=FIELDS, actual=fields)
    if len(rows) != len(baseline):
        issue('row_count_mismatch', expected=len(baseline), actual=len(rows))
    ids = [row.get('audit_id') for row in rows]
    for identifier, count in collections.Counter(ids).items():
        if count > 1:
            issue('duplicate_id', audit_id=identifier, count=count)
    if set(ids) != {row['audit_id'] for row in baseline}:
        issue('id_set_mismatch')

    score_counts = {field: collections.Counter() for field in SCORES}
    for index, row in enumerate(rows):
        context = {'record_number': index + 1, 'audit_id': row.get('audit_id')}
        if None in row or any(row.get(field) is None for field in FIELDS):
            issue('column_count_mismatch', **context)
        if index < len(baseline):
            changed = [field for field in FIXED if row.get(field) != baseline[index][field]]
            if changed:
                issue('fixed_content_or_order_changed', fields=changed, **context)
        for field in SCORES:
            value = row.get(field)
            bucket = value if value in LABELS else ('blank' if value in ('', None) else 'invalid')
            score_counts[field][bucket] += 1
            if bucket in ('blank', 'invalid'):
                issue('missing_score' if bucket == 'blank' else 'invalid_score', field=field, **context)
        reason = row.get('reason')
        if reason is None or not reason.strip():
            issue('missing_reason', **context)

    structure_kinds = {'header_mismatch', 'row_count_mismatch', 'duplicate_id', 'id_set_mismatch',
                       'column_count_mismatch', 'fixed_content_or_order_changed'}
    structurally_valid = not any(counts[kind] for kind in structure_kinds)
    complete = structurally_valid and not counts
    return {
        'status': 'complete_format_valid' if complete else ('annotation_incomplete_or_invalid' if structurally_valid else 'structural_error'),
        'structurally_valid': structurally_valid,
        'annotation_complete': complete,
        'returned_sha256': sha(raw),
        'expected_records': len(baseline),
        'actual_records': len(rows),
        'score_counts': {field: dict(value) for field, value in score_counts.items()},
        'issue_counts': dict(counts),
        'first_issues': issues,
        'issues_truncated': sum(counts.values()) > len(issues),
        'human_authorship_independence_and_accuracy_verified': False,
        'note': 'Read-only format/content-integrity check. Does not assign ratings, assess reasons, verify a human reviewer, establish independence, or adjudicate disagreements.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rater', type=int, required=True, choices=(1, 2))
    parser.add_argument('--file', type=Path, required=True, help='Returned CSV to read; never modified')
    args = parser.parse_args()
    try:
        report = validate(args.file.read_bytes(), load_baseline(args.rater))
        report['rater'] = args.rater
        report['file'] = str(args.file.resolve())
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report['annotation_complete'] else (2 if report['structurally_valid'] else 1)
    except (OSError, ValueError, UnicodeError, csv.Error, zipfile.BadZipFile) as error:
        print(json.dumps({'status': 'file_or_baseline_error', 'error': str(error)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == '__main__':
    sys.exit(main())
