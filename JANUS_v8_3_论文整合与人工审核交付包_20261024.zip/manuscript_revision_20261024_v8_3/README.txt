JANUS 论文整合与人工审核交付包
日期：2026 年 10 月 24 日

当前状态
三卡计时结果已整合进英文论文，包括 8 张结果表、方法、讨论及限制。阅读版 PDF 为
20 页；同一 Markdown 另导出可编辑 LaTeX，并已通过桌面内置编译器验证。阅读版 PDF
由 ReportLab 生成，不是该编译器导出的 PDF。论文仍是作者审阅稿，尚不可标记为投稿终稿。

主要结论保持证据边界：监控增加了耗时；本轮不支持整体加速，也不证明普遍的语义
质量提升。旧单卡隔离计时、新三卡并发计时分别报告，旧五卡 pilot 不混入三卡结果。
本轮新增 11,200 条计分及 480 次预热已完成；人工语义评分仍未完成。

建议阅读顺序
1. output/pdf/revised_manuscript.pdf：完整英文阅读稿，20 页、8 张表。
2. revision_response_matrix_zh.md：补充建议与证据、修改位置的对应关系。它是内部修订
   对照表，不冒充期刊真实审稿意见或已发送的审稿回复。
3. author_submission_checklist_zh.md：作者确认和投稿前待办。
4. human_review/组织者操作指南.txt：双人独立人工审核的具体交接方式。
5. supplement/output/pdf/JANUS_v8_3_结果解读与下一步.pdf：中文结果解读。

文件说明
- revised_manuscript.md：本次论文正文的规范编辑源。
- latex/main.tex：可编辑 LaTeX，使用常规文章排版；不是期刊官方模板。
- build_submission.py：从本目录 Markdown 生成阅读 PDF 和 LaTeX 源文件。
- integrate_manuscript.py：从原 v6 稿件和本地结果汇总重新整合；依赖原项目目录。
- supplement/：选取的分析汇总、图、完整会话对比、方法代码快照和溯源记录。
- independent-scientific-review.json：独立 AI 子代理的技术核对，绑定正文、LaTeX 和
  结果汇总的 SHA；不等同于外部同行评议、人工语义评分或外部独立复现实验。
- validation-record.json：编译、渲染、文件一致性和交接验证的范围与结果。
- package-manifest.json、SHA256SUMS：本包文件完整性清单。

下一步需要作者配合的事项
两位真人评分者各自独立完成同一批 600 条输出，不是各分 300 条。分别只发送：
  human_review/for_rater1/rater1_package.zip
  human_review/for_rater2/rater2_package.zip
不要向评分者发送整个论文交付包、解盲 key 或另一人的评分。两人完成、原始表封存后，
再比较和仲裁。本包没有替任何研究记录填入人工评分，也没有复制私有解盲 key。
样本来自旧主实验的 14,400 条输出，包含 525 个模型×任务×题目组合，不是新增
10,800 条计时记录的逐条审核。细节、理由填写要求及抽样加权限制见组织者指南。

收到 CSV 后，在本目录运行（或使用脚本绝对路径）：
  python3 human_review/validate_returned_ratings.py --rater 1 --file /绝对路径/rater1_completed.csv
  python3 human_review/validate_returned_ratings.py --rater 2 --file /绝对路径/rater2_completed.csv
验证器只读；退出码 0 表示结构和字段填写完整，2 表示评分字段待修正，1 表示结构或
文件问题。通过不证明真人身份、相互独立或判断正确。不要覆盖首次收到的原始文件。

还需确认作者与单位、贡献、资助及利益冲突等事实，逐条核验参考文献原始来源，完成
公开数据/代码存档及最终校稿。本次没有新增模型推理，这些后续事项无需开启 GPU 服务器。

编辑与复建
在安装了 reportlab 的 Python 环境中，运行 python3 build_submission.py 可从 Markdown
重建阅读 PDF 和 TeX。此操作会覆盖这两个派生文件；修改后需重新编译、审阅并更新 SHA。
在 Codex 中打开 latex 文件夹可编辑并预览 LaTeX；编译成功不等于科学结论或投稿条件通过。
integrate_manuscript.py 以及 supplement/build_summary.py/build_report.py 是本地项目的
整合记录，含原项目路径依赖，不能假定解压后能独立重算全部原始实验。

原始证据与保管范围
本包用于作者内部审阅，收录选取的证据，包含本地运维/来源路径，不是完整原始实验
档案，也不是未经审核即可公开发布的数据包。三卡完整已验证备份仍位于原项目的：
  server_operations_20261023_v8_3/server_backup/
  1e57f53e927235e24888c6c07d51a7ead747379a41229cdbdc106c868477e26a/
原 v6 稿件和人工审核抽样协议位于 peerj_revision_20261022_v6；历史主实验原始证据
仍保存在原项目中。本包未修改这些冻结文件。

supplement/source_manifest.json 原样记录 19 个分析快照；新增的第 20 个来源快照
supplement/sources/model-verification.json 由本包 package-manifest.json 覆盖。
supplement/original_analysis_README.txt 是先前分析包的原始说明；其中“尚未整合正文”
描述的是先前交付阶段，本目录已经完成正文整合。

关机收尾依据
实例状态已依据用户对租赁平台“已关机”的确认记录，巡检已暂停。本轮未连接服务器。
该确认不是本工具直接核验账单，也不提供精确停费时间；原回执与用户确认保留在运维目录。
