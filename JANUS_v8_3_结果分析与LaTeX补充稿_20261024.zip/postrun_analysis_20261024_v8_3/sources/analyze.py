"""Verify new run completeness, analyze output identity, and replay trace gates.

Only measured policies have measured latency. Replay never estimates runtime.
"""
import argparse
from collections import defaultdict
import itertools
import json
import math
from pathlib import Path
import random
from statistics import mean
from .audit import dump, csv_dump
from .contracts import CONTRACTS, EntropyGate, same_answer, score
from .run import sha, select_cases, code_hashes
from .prior import verify_prior_evidence
from .parallel import execution_metadata, shard_count, select_shard
from .stats import paired_binary, paired_bootstrap


def replay_policy_paths(record, entropy):
    """Replay token positions, including non-EOS events at the cap boundary.

    Natural EOS has priority. A callback trigger on the cap token is recorded as
    policy, with cap_reached separately true, matching the engine and old core.
    No latency is inferred from replay.
    """
    trace, ids = record['trace'], record['generated_ids']
    if not ids or len(trace) != len(ids) or any(t['step'] != i+1 for i,t in enumerate(trace)):
        raise ValueError('Incomplete or misindexed trace')
    if any(t['eos'] for t in trace[:-1]):
        raise ValueError('EOS before the last trace token')
    if any(bool(t['completion']) != (t['prediction'] is not None) for t in trace):
        raise ValueError('Completion/prediction mismatch')
    if any(bool(t['structured_completion']) != (t['structured_prediction'] is not None) for t in trace):
        raise ValueError('Structured completion/prediction mismatch')
    if [t['eos'] for t in trace] != [i in record['eos_token_ids'] for i in ids]:
        raise ValueError('Trace EOS does not match token IDs')
    if len(ids) > record['cap'] or (not trace[-1]['eos'] and len(ids) != record['cap']):
        raise ValueError('Uniform trace ends without EOS or cap')
    gate = EntropyGate(**entropy)
    opened = [gate.update(t['step'],t['entropy']) for t in trace]
    events = {
        'complete': [t['step'] for t in trace if t['completion'] and not t['eos']],
        'structured_complete': [t['step'] for t in trace if t['structured_completion'] and not t['eos']],
        'conjunction': [t['step'] for t,o in zip(trace,opened) if t['completion'] and not t['eos'] and o],
    }
    first = events['complete'][0] if events['complete'] else None
    events['latched_buffer'] = [t['step'] for t,o in zip(trace,opened)
                               if first is not None and t['step'] >= first and not t['eos'] and o]
    events['entropy_observe'] = events['complete']
    outcomes = {}
    for policy in ['uniform','uniform_trace','boundary_observe','entropy_uniform',
                   'complete','entropy_observe','structured_complete','conjunction','latched_buffer']:
        trigger = events.get(policy, [])[0] if events.get(policy) else None
        end = trigger or len(ids)
        prefix = ids[:end]
        prefix_eos = trace[end-1]['eos']
        buffer_length = first if first is not None and first <= end else None
        returned = prefix[:buffer_length] if policy == 'latched_buffer' and buffer_length else prefix
        returned_eos = trace[len(returned)-1]['eos']
        outcomes[policy] = {
            'generated_ids': prefix, 'returned_ids': returned,
            'policy_trigger_step': trigger,
            'first_complete_step': None if policy == 'uniform' else buffer_length,
            'stop_reason': 'eos' if prefix_eos else 'policy' if trigger else 'cap',
            'returned_eos': returned_eos, 'cap_reached': end == record['cap'],
            'end_conditions': {'eos': prefix_eos, 'policy': trigger is not None, 'cap': end == record['cap']},
        }
        if policy == 'latched_buffer':
            outcomes[policy]['buffer_length'] = buffer_length
    return outcomes


def replay_trace(record, plan):
    trace=record['trace']; ids=record['generated_ids']; end=len(ids)
    replay_policy_paths(record,plan['entropy'])
    if any(t['gate_open'] != o for t,o in zip(trace,_gate_decisions(trace,plan['entropy']))):
        raise ValueError('Saved baseline gate decisions differ from v5.1-aligned replay')
    results=[]
    grid=plan['trace_replay_grid']
    for threshold,window,min_steps in itertools.product(grid['thresholds'],grid['windows'],grid['min_steps']):
        config=dict(threshold=threshold,window=window,min_steps=min_steps,alpha=plan['entropy']['alpha'])
        paths=replay_policy_paths(record,config)
        c,e,l=[paths[p] for p in ['complete','conjunction','latched_buffer']]
        gate=EntropyGate(**config)
        opportunities=blocked=min_blocked=stability_blocked=stable_count=overlap=0
        for t in trace:
            opened=gate.update(t['step'],t['entropy'])
            if not t['eos'] and opened:stable_count+=1
            if t['completion'] and not t['eos']:
                opportunities+=1; blocked+=not opened
                min_blocked+=t['step']<min_steps; stability_blocked+=gate.streak<window
                overlap+=opened
        def credited(path):
            pos=len(path['returned_ids'])
            pred=trace[pos-1]['prediction']
            if trace[pos-1]['eos']:
                return record['scores']['strict']['correct']
            return same_answer(pred,record['gold'],record['kind'])
        results.append({'stage':record['stage'],'model':record['model'],'task':record['task'],
                'question_id':record['question_id'],'threshold':threshold,'window':window,'min_steps':min_steps,
                'uniform_tokens':end,'complete_tokens':len(c['generated_ids']),
                'complete_trigger_step':c['policy_trigger_step'],'complete_stop_reason':c['stop_reason'],
                'conjunction_tokens':len(e['generated_ids']),
                'conjunction_trigger_step':e['policy_trigger_step'],'conjunction_stop_reason':e['stop_reason'],
                'completion_opportunities':opportunities,'stable_non_eos_steps':stable_count,
                'overlap_opportunities':overlap,'blocked_completion_steps':blocked,
                'minimum_step_blocks':min_blocked,'stability_blocks':stability_blocked,
                'latched_generated_tokens':len(l['generated_ids']),'latched_returned_tokens':len(l['returned_ids']),
                'latched_trigger_step':l['policy_trigger_step'],'latched_stop_reason':l['stop_reason'],
                'complete_replayed_strict_correct':credited(c),'replayed_strict_correct':credited(e),
                'triggered_before_uniform':len(e['generated_ids'])<end,
                'status':'offline-replay-not-measured-latency'})
    return results


def _gate_decisions(trace, entropy):
    gate=EntropyGate(**entropy)
    return [gate.update(t['step'],t['entropy']) for t in trace]


def expected_job_grid(rows, spec):
    """Independent grid reconstructed from per-task IDs, not trusted job_order."""
    questions={task:{r['question_id'] for r in rows if r['task']==task} for task in ['gsm8k','arc']}
    if set(r['task'] for r in rows) != {'gsm8k','arc'}:
        raise ValueError('Both planned tasks required')
    if any(len(ids)!=spec['n_per_task'] for ids in questions.values()):
        raise ValueError('Per-task question count differs from plan')
    if questions['gsm8k'] & questions['arc']:
        raise ValueError('Question IDs overlap across tasks')
    return {(task,q,p,r) for task,ids in questions.items() for q in ids
            for p in spec['policies'] for r in range(spec['repeats'])}


def validate_worker_layout(meta, rows, warmups, cases):
    """Check a worker against frozen inputs, not its self-reported job list.

    `cases` is the full deterministic model/stage selection from verified data.
    Shards remain pieces of one session; all policy pairs stay on one device.
    """
    errors=[]
    def check(ok,message):
        if not ok:errors.append(message)
    plan,stage=meta['plan'],meta['stage'];spec=plan['stages'][stage]
    try:
        expected=execution_metadata(plan,stage,meta.get('shard_index'),meta.get('shard_count'))
        selected=select_shard(cases,expected['shard_index'],expected['shard_count'])
    except (ValueError,KeyError,TypeError) as exc:
        return ['Invalid worker shard configuration: '+str(exc)]
    check(all(meta.get(k)==v for k,v in expected.items()),'Worker execution metadata differs from plan')
    ids=[r['question_id'] for r in selected]
    check(meta.get('selected_question_ids')==ids,'Selected IDs differ from deterministic task-rank shard')
    check(meta.get('global_selected_question_ids')==[r['question_id'] for r in cases],
          'Global selected IDs differ from frozen inputs')
    grid={(r['task'],r['question_id'],p,i) for r in selected for p in spec['policies'] for i in range(spec['repeats'])}
    observed={(r['task'],r['question_id'],r['policy'],r['repeat']) for r in rows}
    check(observed==grid and len(rows)==len(grid),'Independent complete shard call grid')
    check(meta.get('expected_calls')==len(grid),'Expected calls differ from frozen shard grid')
    jobs=[(r['question_id'],p,i) for r in cases for p in spec['policies'] for i in range(spec['repeats'])]
    random.Random(plan['seed']+meta['session']*1009+(0 if meta['model']=='qwen' else 1)).shuffle(jobs)
    jobs=[job for job in jobs if job[0] in set(ids)]
    check([(r['question_id'],r['policy'],r['repeat']) for r in rows]==jobs,
          'Shard order differs from full-session shuffle then filter')
    gpu=meta.get('gpu_uuid');affinity=meta.get('cpu_affinity')
    check(isinstance(gpu,str) and gpu.startswith('GPU-') and len(gpu)>4,'Missing canonical GPU UUID')
    check(isinstance(affinity,list) and len(affinity)==plan['execution']['cpu_cores_per_worker'] and
          all(type(cpu) is int and cpu>=0 for cpu in affinity) and len(set(affinity))==len(affinity),
          'Invalid worker CPU affinity')
    isolation=meta.get('isolation',{})
    check(isolation.get('lock_acquired') is True and isolation.get('other_compute_pids')==[] and
          isolation.get('gpu_uuid')==gpu and isinstance(isolation.get('checked_utc'),str) and bool(isolation['checked_utc']),
          'Missing GPU exclusive-use evidence')
    for key in ['launch_id','worker_id','wave_relative_path']:
        check(isinstance(meta.get(key),str) and bool(meta.get(key)),'Missing parallel launch identity: '+key)
    for row in rows+warmups:
        check(all(row.get(k)==meta.get(k) for k in
                  ['shard_index','shard_count','gpu_uuid','cpu_affinity','timing_regime']),
              'Record/worker execution metadata mismatch')
    task_cases={task:[r for r in selected if r['task']==task] for task in ['gsm8k','arc']}
    for row in warmups:
        cs=task_cases.get(row['task'],[])
        check(bool(cs) and row['question_id']==cs[row['warmup_index']%len(cs)]['question_id'],
              'Warmup question differs from frozen shard selection')
    return errors


def aggregate_sessions(workers, records, plan):
    """Return complete model/session summaries, never count shards as sessions."""
    sessions=[];errors=[]
    groups=defaultdict(list)
    for worker in workers:groups[worker['stage'],worker['model'],worker['session']].append(worker)
    for (stage,model,session),items in sorted(groups.items()):
        expected=set(range(shard_count(plan,stage)))
        indices=[w['shard_index'] for w in items]
        if set(indices)!=expected or len(indices)!=len(expected):
            errors.append('Missing/duplicate worker shard: '+str((stage,model,session)));continue
        if len({w['gpu_uuid'] for w in items})!=len(items):
            errors.append('Session shards reuse a GPU: '+str((stage,model,session)))
        rows=[r for r in records if (r['stage'],r['model'],r['session'])==(stage,model,session)]
        try:
            grid=expected_job_grid(rows,plan['stages'][stage])
            if len(rows)!=len(grid) or {(r['task'],r['question_id'],r['policy'],r['repeat']) for r in rows}!=grid:
                errors.append('Incomplete merged session grid: '+str((stage,model,session)));continue
        except ValueError as exc:
            errors.append('Incomplete merged session: '+str((stage,model,session))+': '+str(exc));continue
        sessions.append({'stage':stage,'model':model,'session':session,'calls':len(rows),'shards':len(items),
                         'timing_regime':plan['execution']['timing_regime']})
    by_question=defaultdict(set)
    for r in records:
        by_question[r['stage'],r['model'],r['session'],r['task'],r['question_id']].add(
            (r.get('run_uuid'),r.get('gpu_uuid'),r.get('shard_index')))
    if any(len(v)!=1 for v in by_question.values()):errors.append('Question policies/repeats cross run or GPU')
    waves=defaultdict(list)
    for worker in workers:waves[worker.get('launch_id'),worker.get('wave_relative_path')].append(worker)
    for key,items in waves.items():
        gpu_ids=[w.get('gpu_uuid') for w in items]
        cpus=[cpu for w in items for cpu in w.get('cpu_affinity',[])]
        if len(gpu_ids)!=len(set(gpu_ids)) or len(cpus)!=len(set(cpus)):
            errors.append('Concurrent wave workers share GPU or CPU affinity: '+str(key))
    return sessions,errors


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--runs',type=Path,default=Path('runs'))
    ap.add_argument('--out',type=Path,default=Path('analysis'))
    ap.add_argument('--data',type=Path,default=Path('data'))
    ap.add_argument('--prior-gate-report',type=Path,help='Frozen prior smoke/trace report; old timing rows are not pooled')
    ap.add_argument('--require-stage',action='append',default=[],
                    choices=['smoke','trace','quality','timing_pilot','timing'],
                    help='Require the complete two-model stage; repeat for several stages')
    a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    report={'errors':[],'warnings':[],'sessions':[],'workers':[], 'required_stages':a.require_stage,
            'validation_scope':'Observed records plus explicitly required stages; not an all-experiments completion receipt',
            'smoke_replay_checked_cases':0}
    def check(ok,msg):
        if not ok:report['errors'].append(msg)
    manifest=json.loads((a.data/'manifest.json').read_text())
    for name,digest in manifest['files'].items():
        check(sha(a.data/name)==digest,'Prepared input changed: '+name)
    manifest_sha=sha(a.data/'manifest.json')
    all_records=[];replayed=[];plans=set();implementations=set();data_manifests=set();plan_contents=set()
    session_plans=[]
    for mf in sorted(a.runs.glob('*/meta.json')):
        m=json.loads(mf.read_text())
        if m['status']!='complete':
            report['errors'].append('Incomplete session retained: '+str(mf));continue
        path=mf.parent/'records.jsonl'
        if not path.exists():
            report['errors'].append('Missing records: '+str(path));continue
        check(sha(path)==m['records_sha256'],'Record checksum: '+str(path))
        rows=[json.loads(s) for s in path.read_text().splitlines()]
        check(len(rows)==m['expected_calls'],'Call count: '+str(path))
        check(m.get('completed_calls')==len(rows),'Completed call count: '+str(path))
        identities=[(r['question_id'],r['policy'],r['repeat']) for r in rows]
        expected=[(r['question_id'],r['policy'],r['repeat']) for r in m['job_order']]
        check(identities==expected,'Call grid/order: '+str(path))
        check(all(r['session']==m['session'] and r['run_uuid']==m['run_uuid'] for r in rows),'Session IDs')
        plans.add(m['plan_sha256'])
        plan_contents.add(json.dumps(m['plan'],sort_keys=True))
        session_plans.append(m['plan'])
        implementations.add(json.dumps(m['source_hashes'],sort_keys=True))
        data_manifests.add(m['data_manifest_sha256'])
        check(m['data_manifest_sha256']==manifest_sha,'Worker does not bind analyzed inputs: '+str(mf))
        check(m['stage'] in {'timing_pilot','timing'},'Old smoke/trace rows cannot be pooled into this three-GPU analysis')
        stage=m['stage']; report['workers'].append({'directory':str(mf.parent),'stage':stage,'model':m['model'],
            'session':m['session'],'calls':len(rows),**{k:m.get(k) for k in
            ['shard_index','shard_count','gpu_uuid','cpu_affinity','timing_regime','launch_id','worker_id','wave_relative_path']}})
        check(all(r['actual_generated_tokens']==len(r['generated_ids']) and r['returned_tokens']==len(r['returned_ids']) for r in rows),'Token lengths')
        spec=m['plan']['stages'][stage]
        check(0 <= m['session'] < spec['sessions'],'Session outside plan: '+str(mf))
        check(all(r['stage']==stage and r['model']==m['model'] for r in rows),'Stage/model identity: '+str(mf))
        check(m['model'] in m['plan'].get('models',['qwen','mistral']),'Unknown model: '+str(mf))
        check(set(m['selected_question_ids'])=={r['question_id'] for r in rows},'Selected question identity: '+str(mf))
        warmup_path=mf.parent/'warmups.jsonl'
        check(warmup_path.exists() and sha(warmup_path)==m.get('warmups_sha256'),'Warmup checksum: '+str(mf))
        warmups=[json.loads(s) for s in warmup_path.read_text().splitlines()] if warmup_path.exists() else []
        check(len(warmups)==2*spec['warmups_per_task_policy']*len(spec['policies']),'Warmup count: '+str(mf))
        warmup_grid={(r['task'],r['policy'],r['warmup_index']) for r in warmups}
        expected_warmups={(task,policy,i) for task in ['gsm8k','arc'] for policy in spec['policies']
                          for i in range(spec['warmups_per_task_policy'])}
        check(warmup_grid==expected_warmups and len(warmups)==len(expected_warmups),'Warmup task/policy/index grid: '+str(mf))
        check(all(r['warmup'] is True and r['stage']==stage and r['model']==m['model'] and
                  r['session']==m['session'] and r['run_uuid']==m['run_uuid'] and
                  r['question_id'] in m['selected_question_ids'] for r in warmups),'Warmup identity: '+str(mf))
        cases=select_cases(a.data,m['model'],stage,spec['n_per_task'],m['plan']['seed'])
        report['errors'].extend(error+': '+str(mf) for error in validate_worker_layout(m,rows,warmups,cases))
        runtime=m.get('actual_runtime',{})
        check(runtime=={'torch_threads':m['plan']['runtime']['torch_threads'],
                        'torch_interop_threads':m['plan']['runtime']['torch_interop_threads'],
                        'dtype':'torch.'+m['plan']['runtime']['dtype'],'attention':m['plan']['runtime']['attention'],
                        'allow_tf32':False,'cudnn_benchmark':False},'Measured runtime differs from frozen plan: '+str(mf))
        for r in rows+warmups:
            check(r['kind']=={'gsm8k':'numeric','arc':'choice'}.get(r['task']),'Task/answer kind mismatch')
            check(r['actual_generated_tokens']==len(r['generated_ids']) and r['returned_tokens']==len(r['returned_ids']),'Token lengths')
            check(bool(r['generated_ids']) and 0<len(r['generated_ids'])<=m['plan']['cap'],'Empty/over-cap output')
            check(bool(r['returned_ids']),'Empty returned output')
            check(r['returned_ids']==r['generated_ids'][:len(r['returned_ids'])],'Returned IDs are not generated prefix')
            check(r['cap']==m['plan']['cap'] and r['cap_reached']==(len(r['generated_ids'])==r['cap']),'Cap metadata')
            eos=bool(r['generated_ids'] and r['generated_ids'][-1] in r['eos_token_ids'])
            check(not any(i in r['eos_token_ids'] for i in r['generated_ids'][:-1]),'Early EOS token in output')
            trigger=r['policy_trigger_step']
            check(trigger is None or trigger==len(r['generated_ids']),'Trigger position')
            reason='eos' if eos else 'policy' if trigger is not None else 'cap'
            check(r['stop_reason']==reason and (reason!='cap' or r['cap_reached']),'End reason')
            check(r['end_conditions']=={'eos':eos,'policy':trigger is not None,'cap':r['cap_reached']},'End conditions')
            check(r['returned_eos']==bool(r['returned_ids'] and r['returned_ids'][-1] in r['eos_token_ids']),'Returned EOS')
            check(all(math.isfinite(r[k]) and r[k]>=0 for k in ['generation_seconds','end_to_end_seconds'])
                  and r['end_to_end_seconds']>=r['generation_seconds'],'Invalid timing values')
            check(set(r['scores'])==CONTRACTS,'Missing/extra scoring contract')
            for contract,stored in r['scores'].items():
                if contract not in CONTRACTS:continue
                check(stored==score(r['text'],r['kind'],r['gold'],r['choices'],r['returned_eos'],contract),'New score mismatch')
        for r in rows:
            if r['policy']=='uniform_trace':
                check(r['diagnostic_only'],'Trace timing not labeled diagnostic')
                try:replayed.extend(replay_trace(r,m['plan']))
                except (ValueError,KeyError) as exc:check(False,'Invalid trace: '+str(exc))
            else:
                check(not r['diagnostic_only'],'Measured policy mislabeled diagnostic')
        if stage=='smoke':
            by_case=defaultdict(dict)
            for r in rows:by_case[r['question_id'],r['repeat']][r['policy']]=r
            for key,by_policy in by_case.items():
                reference=by_policy.get('uniform_trace')
                check(reference is not None,'Smoke requires uniform_trace for actual/replay gate')
                if reference is None:continue
                try:
                    paths=replay_policy_paths(reference,m['plan']['entropy'])
                    for policy,actual in by_policy.items():
                        for field,expected_value in paths[policy].items():
                            check(actual.get(field)==expected_value,
                                  'Smoke live/replay mismatch '+str((m['model'],key,policy,field)))
                    report['smoke_replay_checked_cases']+=1
                except (ValueError,KeyError) as exc:check(False,'Smoke replay failed: '+str(exc))
        all_records.extend(rows)
    check(bool(report['workers']),'No complete workers discovered')
    check(len(plans)<=1,'Mixed plan hashes; use separate analysis roots')
    check(len(plan_contents)<=1,'Mixed embedded plans')
    check(len(implementations)<=1,'Mixed implementation hashes; do not pool modified source versions')
    check(len(data_manifests)<=1,'Mixed prepared input manifests')
    # Prevent duplicate retries being pooled and changing question/session weighting.
    identity=[(r['stage'],r['model'],r['session'],r['question_id'],r['policy'],r['repeat']) for r in all_records]
    check(len(identity)==len(set(identity)),'Duplicate retry/session records; select one documented run set')
    report['completed_stages']=[]
    if session_plans:
        plan=session_plans[0]
        try:
            report['sessions'],errors=aggregate_sessions(report['workers'],all_records,plan)
            report['errors'].extend(errors)
        except (ValueError,KeyError,TypeError) as exc:check(False,'Invalid parallel session layout: '+str(exc))
        report['timing_regime']=plan['execution']['timing_regime']
        for stage,spec in plan['stages'].items():
            observed={(s['model'],s['session']) for s in report['sessions'] if s['stage']==stage}
            expected={(model,s) for model in plan.get('models',['qwen','mistral']) for s in range(spec['sessions'])}
            if observed==expected:report['completed_stages'].append(stage)
            if stage in a.require_stage:check(observed==expected,'Required stage incomplete: '+stage)
        for stage in a.require_stage:check(stage in plan['stages'],'Required stage absent from plan: '+stage)
        # Every cross-stage overlap must preserve the same token trajectory.
        traces=defaultdict(dict)
        for r in all_records:
            if r['policy']=='uniform_trace':traces[r['model'],r['task'],r['question_id']][r['stage']]=r
        for key,by_stage in traces.items():
            if 'smoke' in by_stage and 'trace' in by_stage:
                check(by_stage['smoke']['generated_ids']==by_stage['trace']['generated_ids'],
                      'Smoke/trace shared trajectory mismatch: '+str(key))
        if 'trace' in report['completed_stages'] and 'smoke' in report['completed_stages']:
            for model in plan.get('models',['qwen','mistral']):
                for task in ['gsm8k','arc']:
                    smoke={r['question_id'] for r in all_records if r['stage']=='smoke' and r['model']==model and r['task']==task}
                    trace={r['question_id'] for r in all_records if r['stage']=='trace' and r['model']==model and r['task']==task}
                    check(smoke <= trace,'Smoke cases are not a trace subset: '+model+'/'+task)
    else:
        for stage in a.require_stage:check(False,'Required stage incomplete: '+stage)
    report['all_requested_stages_complete']=bool(a.require_stage) and set(a.require_stage)<=set(report['completed_stages'])
    report['plan_sha256']=next(iter(plans)) if len(plans)==1 else None
    report['source_hashes']=json.loads(next(iter(implementations))) if len(implementations)==1 else None
    report['data_manifest_sha256']=next(iter(data_manifests)) if len(data_manifests)==1 else None
    report['prior_evidence_gate_passed']=False
    if session_plans:
        try:
            check(report['source_hashes']==code_hashes(),'Analysis code differs from measured source hashes')
            prior_path=a.prior_gate_report or a.data.resolve().parent.parent/'provenance/prior-first-stage/analysis_status.json'
            report.update(verify_prior_evidence(session_plans[0],report,prior_path))
        except (ValueError,KeyError,OSError,TypeError) as exc:
            check(False,'Prior evidence verification failed: '+str(exc))
    summaries=[];paired=[];identity_results=[]
    timing_regime=report.get('timing_regime')
    grouped=defaultdict(list)
    for r in all_records:
        if not r['diagnostic_only']:grouped[r['stage'],r['model'],r['session'],r['task'],r['policy']].append(r)
    for (stage,model,session,task,policy),rs in sorted(grouped.items()):
        for contract in rs[0]['scores']:
            summaries.append(dict(stage=stage,model=model,session=session,task=task,policy=policy,
                timing_regime=timing_regime,
                contract=contract,n_calls=len(rs),n_questions=len({r['question_id'] for r in rs}),
                accuracy=mean(r['scores'][contract]['correct'] for r in rs),
                valid_rate=mean(r['scores'][contract]['valid'] for r in rs),
                mean_generated_tokens=mean(r['actual_generated_tokens'] for r in rs),
                mean_returned_tokens=mean(r['returned_tokens'] for r in rs),
                mean_end_to_end_seconds=mean(r['end_to_end_seconds'] for r in rs),
                end_to_end_p50_seconds=sorted(r['end_to_end_seconds'] for r in rs)[math.ceil(.5*len(rs))-1],
                end_to_end_p95_seconds=sorted(r['end_to_end_seconds'] for r in rs)[math.ceil(.95*len(rs))-1],
                generated_tokens_per_credited_correct=sum(r['actual_generated_tokens'] for r in rs)/sum(r['scores'][contract]['correct'] for r in rs) if any(r['scores'][contract]['correct'] for r in rs) else None))
    contrasts=[('complete','uniform'),('structured_complete','complete'),('entropy_observe','complete'),
               ('conjunction','complete'),('latched_buffer','complete'),
               ('boundary_observe','uniform'),('entropy_uniform','boundary_observe')]
    context=sorted({(r['stage'],r['model'],r['session'],r['task']) for r in all_records if not r['diagnostic_only']})
    for stage,model,session,task in context:
        for p,c in contrasts:
            ps,cs=grouped[stage,model,session,task,p],grouped[stage,model,session,task,c]
            if not ps or not cs:continue
            pm={(r['question_id'],r['repeat']):r for r in ps}
            cm={(r['question_id'],r['repeat']):r for r in cs}
            check(pm.keys()==cm.keys(),'Unpaired new policies')
            keys=sorted(pm.keys() & cm.keys())
            check(all((pm[k].get('gpu_uuid'),pm[k].get('run_uuid'),pm[k].get('shard_index'))==
                      (cm[k].get('gpu_uuid'),cm[k].get('run_uuid'),cm[k].get('shard_index')) for k in keys),
                  'Paired policies cross GPU, run, or shard')
            generated_same=all(pm[k]['generated_ids']==cm[k]['generated_ids'] for k in keys)
            returned_same=all(pm[k]['returned_ids']==cm[k]['returned_ids'] for k in keys)
            output_same=generated_same and returned_same
            identity_results.append(dict(stage=stage,model=model,session=session,task=task,policy=p,control=c,
                n_pairs=len(keys),generated_ids_equal=generated_same,returned_ids_equal=returned_same,
                output_matched=output_same))
            if p in {'entropy_observe','boundary_observe','entropy_uniform'}:
                check(output_same,'Monitoring contrast output mismatch: '+str((stage,model,session,task,p,c)))
            if c=='uniform':
                check(all(pm[k]['generated_ids']==cm[k]['generated_ids'][:pm[k]['actual_generated_tokens']] for k in keys),'New stopping policy not Uniform prefix')
            # Average repeat differences within question before resampling.
            d=defaultdict(list)
            for k in keys:d[k[0]].append(pm[k]['end_to_end_seconds']-cm[k]['end_to_end_seconds'])
            ids=sorted(d)
            paired.append(dict(stage=stage,model=model,session=session,task=task,policy=p,control=c,
                metric='end_to_end_seconds',output_matched=output_same,
                timing_regime=timing_regime,
                descriptive_unadjusted=True,**paired_bootstrap([mean(d[q]) for q in ids])))
            if stage in {'quality','smoke'}:
                for contract in ps[0]['scores']:
                    # Accuracy repeats must be deterministic for binary question analysis.
                    check(all(len({pm[k]['scores'][contract]['correct'] for k in keys if k[0]==q})==1 for q in ids),'Output variation in accuracy repeats')
                    one={q:next(k for k in keys if k[0]==q) for q in ids}
                    paired.append(dict(stage=stage,model=model,session=session,task=task,policy=p,control=c,
                        metric='correct',contract=contract,descriptive_unadjusted=True,
                        **paired_binary([pm[one[q]]['scores'][contract]['correct'] for q in ids],
                                        [cm[one[q]]['scores'][contract]['correct'] for q in ids])))
    # Runtime generalization is reported per session; no pseudo-independent pooling of repetitions.
    timing_sessions=[s for s in report['sessions'] if s['stage']=='timing']
    if timing_sessions:
        for model in ['qwen','mistral']:
            observed={s['session'] for s in timing_sessions if s['model']==model}
            plan=json.loads(next(a.runs.glob('*/meta.json')).read_text())['plan']
            expected=set(range(plan['stages']['timing']['sessions']))
            check(observed==expected,'Incomplete formal timing sessions for '+model)
    csv_dump(a.out/'new_summaries.csv',summaries)
    dump(a.out/'paired_contrasts.json',paired)
    dump(a.out/'output_identity.json',identity_results)
    csv_dump(a.out/'trace_replay.csv',replayed)
    # Hardware strata describe imbalance/heterogeneity; they are not new sessions
    # and receive no separate inferential pooling or cross-version comparison.
    strata=defaultdict(list)
    for r in all_records:
        if not r['diagnostic_only']:
            strata[r['stage'],r['model'],r['session'],r['task'],r.get('shard_index'),r.get('gpu_uuid'),r['policy']].append(r)
    gpu_summaries=[];gpu_pairs=[]
    for key,rs in sorted(strata.items(),key=lambda item:str(item[0])):
        stage,model,session,task,index,gpu,policy=key
        gpu_summaries.append(dict(stage=stage,model=model,session=session,task=task,shard_index=index,
            gpu_uuid=gpu,policy=policy,n_calls=len(rs),n_questions=len({r['question_id'] for r in rs}),
            mean_end_to_end_seconds=mean(r['end_to_end_seconds'] for r in rs)))
    for stage,model,session,task,index,gpu in sorted({key[:-1] for key in strata},key=str):
        for policy,control in contrasts:
            ps=strata.get((stage,model,session,task,index,gpu,policy),[])
            cs=strata.get((stage,model,session,task,index,gpu,control),[])
            pm={(r['question_id'],r['repeat']):r for r in ps};cm={(r['question_id'],r['repeat']):r for r in cs}
            if not pm or pm.keys()!=cm.keys():continue
            differences=defaultdict(list)
            for key in pm:differences[key[0]].append(pm[key]['end_to_end_seconds']-cm[key]['end_to_end_seconds'])
            gpu_pairs.append(dict(stage=stage,model=model,session=session,task=task,shard_index=index,
                gpu_uuid=gpu,policy=policy,control=control,n_questions=len(differences),
                mean_paired_difference_seconds=mean(mean(v) for v in differences.values())))
    dump(a.out/'gpu_stratified_timing.json',{'timing_regime':timing_regime,
         'interpretation':'Descriptive GPU strata within a model/session under concurrent server load; shards are not independent sessions. No comparison with previous isolated timing.',
         'summaries':gpu_summaries,'paired_differences':gpu_pairs})
    original_match=defaultdict(list)
    for r in all_records:
        if r['policy'] in {'uniform','uniform_trace'}:original_match[r['stage'],r['model']].append(r['original_uniform_ids_equal'])
    report['original_uniform_compatibility']=[dict(stage=k[0],model=k[1],n=len(v),exact_id_matches=sum(v)) for k,v in sorted(original_match.items())]
    if any(not all(v) for v in original_match.values()):
        report['warnings'].append('Some new Uniform trajectories differ from archived Uniform. Treat v8 as a separate implementation/runtime experiment; do not combine policy contrasts across versions.')
    report['warnings'] += ['All follow-up intervals are descriptive and unadjusted.',
       'A passing analysis without --require-stage certifies only discovered sessions, not completion of any missing stage.',
       'Trace replay is counterfactual prefix analysis under verified shared-path assumptions, not measured latency.',
       'Three-GPU workers share host resources. Timing is conditional on concurrent_three_gpu_paired; do not pool with the prior five-GPU pilot or previous isolated timing or treat shards as independent sessions.',
       'Per-session timing intervals do not establish a cross-hardware population effect.']
    report['passed']=not report['errors']
    report['smoke_replay_gate_passed']=('smoke' in report['completed_stages'] and report['passed'])
    dump(a.out/'analysis_status.json',report)
    print(json.dumps(report,indent=2))
    if not report['passed']:raise SystemExit(1)


if __name__=='__main__':main()
