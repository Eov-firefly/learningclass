import argparse
from contextlib import contextmanager
import datetime as dt
import fcntl
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import random
import subprocess
import sys
import traceback
import uuid

from .parallel import atomic_json as dump
from .parallel import (THREAD_ENV, execution_metadata, normalize_gpu_uuid, select_shard,
                       validate_worker_launch, wait_for_release, utc_now)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def select_cases(data, model, stage, n, seed):
    rows = [json.loads(s) for s in (Path(data)/f'{model}.jsonl').read_text().splitlines()]
    rows = [r for r in rows if r['stage']=='main']
    selected=[]
    for task in ['gsm8k','arc']:
        task_rows = [r for r in rows if r['task']==task]
        if stage in {'smoke','timing','timing_pilot','trace'}:
            task_rows = [r for r in task_rows if r['timing_member']]
        task_rows.sort(key=lambda r:hashlib.sha256((str(seed)+r['question_id']).encode()).hexdigest())
        if len(task_rows)<n:raise ValueError('Not enough eligible cases; no silent undersampling')
        selected.extend(task_rows[:n])
    return selected


def code_hashes():
    root=Path(__file__).parent.parent
    return {str(p.relative_to(root)):sha(p) for p in sorted((root/'janus_v8').glob('*.py'))}


def verify_stage_gate(plan, stage, fingerprints, gate_report=None, decision_receipt=None):
    """Fail closed before GPU imports; AI technical review is not semantic annotation."""
    from .prior import verify_prior_evidence
    spec=plan['stages'][stage]
    if stage=='quality':
        raise RuntimeError('Quality stage is disabled pending review of offline replay; no GPU calls allowed')
    if stage in {'smoke','trace'}:
        raise RuntimeError('Completed prior smoke/trace are reused; no repeat GPU calls allowed')
    if not spec.get('enabled',False) and not (stage=='timing' and spec.get('requires_reviewed_decision')):
        raise RuntimeError('Stage is disabled in this plan: '+stage)
    if gate_report is None:
        raise ValueError('A passing --gate-report is required before '+stage)
    if stage=='timing_pilot':
        verify_prior_evidence(plan,fingerprints,gate_report)
        return
    report=json.loads(Path(gate_report).read_text())
    required={'timing_pilot'}
    if (report.get('passed') is not True or report.get('errors') or
        report.get('prior_evidence_gate_passed') is not True or
        set(report.get('reused_stages',[])) != {'smoke','trace'} or
        report.get('prior_gate_sha256') != plan['prior_evidence']['analysis_sha256'] or
        not required <= set(report.get('required_stages',[])) or
        not required <= set(report.get('completed_stages',[]))):
        raise ValueError('Stage gate report does not certify complete three-GPU pilot and prior evidence')
    for field,value in fingerprints.items():
        if report.get(field)!=value:
            raise ValueError('Stage gate provenance mismatch: '+field)
    if decision_receipt is None:
        raise ValueError('Formal timing requires a reviewed --decision-receipt')
    decision=json.loads(Path(decision_receipt).read_text())
    if (decision.get('stage')!='timing' or decision.get('decision')!='proceed' or
        decision.get('approved') is not True or decision.get('reviewer_type')!='ai_agent' or
        decision.get('authorization_source')!=plan['decision_policy']['authorization_source'] or
        not str(decision.get('reviewed_by','')).strip() or not str(decision.get('rationale','')).strip() or
        decision.get('analysis_sha256')!=sha(gate_report)):
        raise ValueError('Incomplete timing decision receipt or different reviewed analysis')
    for field,value in fingerprints.items():
        if decision.get(field)!=value:
            raise ValueError('Timing decision provenance mismatch: '+field)


def device_snapshot():
    try:
        return subprocess.check_output(['nvidia-smi'],text=True,stderr=subprocess.STDOUT,timeout=10)
    except (OSError,subprocess.SubprocessError) as exc:
        return 'nvidia-smi unavailable: '+str(exc)


@contextmanager
def gpu_lock(device):
    import torch
    props=torch.cuda.get_device_properties(device)
    if not getattr(props,'uuid',None):
        raise RuntimeError('CUDA device UUID unavailable; cannot certify selected-device isolation')
    identity=str(props.uuid).replace('/','_')
    path=Path('/tmp')/('janus-v8-'+identity+'.lock')
    with path.open('a') as h:
        try:fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('Another v8 process is using this GPU')
        try:
            busy=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True,timeout=10)
        except (OSError,subprocess.SubprocessError) as exc:
            raise RuntimeError('Cannot verify isolated GPU; fix nvidia-smi before measurement') from exc
        for line in busy.splitlines():
            fields=[x.strip() for x in line.split(',')]
            if len(fields)!=2 or not fields[1].isdigit():
                raise RuntimeError('Malformed GPU compute-process inventory')
            if fields[0].lower().removeprefix('gpu-')==identity.lower().removeprefix('gpu-') and fields[1]!=str(os.getpid()):
                raise RuntimeError('Selected GPU has another compute process: '+line)
        yield {'lock_acquired': True, 'other_compute_pids': [],
               'checked_utc': utc_now(), 'gpu_uuid': normalize_gpu_uuid(props.uuid)}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--stage',required=True,choices=['smoke','trace','quality','timing_pilot','timing'])
    ap.add_argument('--model',required=True,choices=['qwen','mistral'])
    ap.add_argument('--session',type=int,default=0)
    ap.add_argument('--plan',type=Path,default=Path('plan.json'))
    ap.add_argument('--data',type=Path,default=Path('data'))
    ap.add_argument('--out',type=Path,default=Path('runs'))
    ap.add_argument('--label',default='')
    ap.add_argument('--device',default='cuda:0')
    ap.add_argument('--local-model',type=Path,help='Disabled: fixed model revision and its HF cache are required')
    ap.add_argument('--gate-report',type=Path,help='Prior complete stage analysis_status.json with matching provenance')
    ap.add_argument('--decision-receipt',type=Path,help='Independent AI technical review of exact pilot plus explicit user authorization')
    ap.add_argument('--shard-index',type=int)
    ap.add_argument('--shard-count',type=int)
    ap.add_argument('--wave-dir',type=Path,help='Required receipt/barrier directory created by launch_parallel')
    ap.add_argument('--worker-id',help='Exact worker identity in the launch receipt')
    a=ap.parse_args()
    if a.local_model is not None:
        raise ValueError('--local-model is disabled: use the fixed model revision and its verified HF cache snapshot')
    plan=json.loads(a.plan.read_text()); spec=plan['stages'][a.stage]
    if a.stage=='quality':
        verify_stage_gate(plan,a.stage,{})
    execution=execution_metadata(plan,a.stage,a.shard_index,a.shard_count)
    if a.model not in plan.get('models',['qwen','mistral']):raise ValueError('Model outside frozen plan')
    if not 0 <= a.session < spec['sessions']:raise ValueError('Session outside frozen plan')
    manifest=json.loads((a.data/'manifest.json').read_text())
    for filename,digest in manifest['files'].items():
        if sha(a.data/filename)!=digest:raise ValueError('Prepared data hash mismatch: '+filename)
    fingerprints={'plan_sha256':sha(a.plan),'source_hashes':code_hashes(),
                  'data_manifest_sha256':sha(a.data/'manifest.json')}
    verify_stage_gate(plan,a.stage,fingerprints,a.gate_report,a.decision_receipt)
    if a.wave_dir is None or not a.worker_id or Path(a.worker_id).name != a.worker_id or a.worker_id in {'.','..'}:
        raise ValueError('Run through launch_parallel: wave directory and worker ID are required')
    if not a.wave_dir.resolve().is_relative_to((a.out/'_parallel').resolve()):
        raise ValueError('Wave evidence must be inside the output _parallel directory')
    launch,worker=validate_worker_launch(a.wave_dir/'launch.json',a.worker_id,
        dict(stage=a.stage,model=a.model,session=a.session,shard_index=a.shard_index,
             shard_count=a.shard_count,device=a.device),fingerprints)
    if not hasattr(os,'sched_getaffinity') or not hasattr(os,'sched_setaffinity'):
        raise RuntimeError('Linux CPU affinity support is required for measured runs')
    if not set(worker['cpu_affinity']) <= os.sched_getaffinity(0):
        raise RuntimeError('Assigned worker CPU set is unavailable')
    os.sched_setaffinity(0,worker['cpu_affinity'])
    actual_affinity=sorted(os.sched_getaffinity(0))
    if actual_affinity != worker['cpu_affinity']:
        raise RuntimeError('Could not apply exact worker CPU affinity')
    if any(os.environ.get(key)!=value for key,value in THREAD_ENV.items()):
        raise RuntimeError('Thread/offline environment differs from frozen launcher settings')
    if os.environ.get('CUDA_VISIBLE_DEVICES')!=worker['gpu_uuid']:
        raise RuntimeError('CUDA visibility differs from assigned exclusive GPU')
    execution.update(gpu_uuid=worker['gpu_uuid'],cpu_affinity=actual_affinity)
    all_cases=select_cases(a.data,a.model,a.stage,spec['n_per_task'],plan['seed'])
    cases=select_shard(all_cases,a.shard_index,a.shard_count)
    protocol=json.loads((a.data/'protocol.json').read_text())
    model_spec=protocol['models'][a.model]
    import torch
    from transformers import AutoTokenizer,AutoModelForCausalLM
    from .engine import generate_one
    if not a.device.startswith('cuda') or not torch.cuda.is_available():
        raise RuntimeError('This CLI requires a CUDA GPU; CPU fixtures are tests only')
    # Output directory is exclusive. Partial sessions remain inspectable; never silently resume timing.
    label=('-'+a.label) if a.label else ''
    if a.label and (Path(a.label).name!=a.label or a.label in {'.','..'}):raise ValueError('Label must be a filename component')
    run_dir=a.out/f'{a.stage}-{a.model}-s{a.session}-shard{a.shard_index}{label}'
    if run_dir.resolve()!=Path(worker['run_dir']).resolve():
        raise ValueError('Worker output differs from the exclusive launch assignment')
    run_dir.mkdir(parents=True,exist_ok=False)
    tasks=[(i,p,r) for i in range(len(all_cases)) for p in spec['policies'] for r in range(spec['repeats'])]
    rng=random.Random(plan['seed']+a.session*1009+(0 if a.model=='qwen' else 1))
    rng.shuffle(tasks)
    # Preserve the original global random order, then restrict to whole-question shards.
    shard_ids={c['question_id'] for c in cases}
    tasks=[job for job in tasks if all_cases[job[0]]['question_id'] in shard_ids]
    meta=dict(status='prepared',started_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
              run_uuid=uuid.uuid4().hex,experiment_id=plan['experiment_id'],stage=a.stage,model=a.model,
              session=a.session,plan=plan,**fingerprints,**execution,
              launch_id=launch['launch_id'],worker_id=a.worker_id,
              wave_relative_path=str(a.wave_dir.resolve().relative_to(a.out.resolve())),
              launch_sha256=sha(a.wave_dir/'launch.json'),thread_environment={k:os.environ[k] for k in THREAD_ENV},
              gate_report_sha256=sha(a.gate_report) if a.gate_report else None,
              decision_receipt_sha256=sha(a.decision_receipt) if a.decision_receipt else None,
              model_spec=model_spec,local_snapshot_override=str(a.local_model) if a.local_model else None,
              expected_calls=len(tasks),selected_question_ids=[c['question_id'] for c in cases],
              global_selected_question_ids=[c['question_id'] for c in all_cases],
              job_order=[{'question_id':all_cases[i]['question_id'],'policy':p,'repeat':r} for i,p,r in tasks],
              python=platform.python_version(),platform=platform.platform(),
              packages={p:importlib.metadata.version(p) for p in ['torch','transformers','tokenizers','numpy','scipy','safetensors']},
              cuda=torch.version.cuda,device_before=device_snapshot())
    dump(run_dir/'meta.json',meta)
    try:
        with gpu_lock(a.device) as isolation:
            if isolation['gpu_uuid'] != execution['gpu_uuid']:
                raise RuntimeError('Loaded CUDA GPU differs from launch UUID')
            meta['isolation']=isolation
            torch.set_num_threads(plan['runtime']['torch_threads'])
            torch.set_num_interop_threads(plan['runtime']['torch_interop_threads'])
            torch.backends.cuda.matmul.allow_tf32=False
            torch.backends.cudnn.benchmark=False
            torch.manual_seed(plan['seed'])
            torch.cuda.set_device(a.device)
            if not torch.cuda.is_bf16_supported():raise RuntimeError('BF16 required by this plan; revise plan explicitly for other hardware')
            location=model_spec['id']
            kwargs={'revision':model_spec['revision'],'local_files_only':True}
            tok=AutoTokenizer.from_pretrained(location,trust_remote_code=False,**kwargs)
            model=AutoModelForCausalLM.from_pretrained(location,trust_remote_code=False,
                torch_dtype=torch.bfloat16,attn_implementation='sdpa',**kwargs).to(a.device).eval()
            meta.update(status='running',model_config=model.config.to_dict(),generation_config=model.generation_config.to_dict(),
                        actual_runtime={'torch_threads':torch.get_num_threads(),'torch_interop_threads':torch.get_num_interop_threads(),
                                        'dtype':str(next(model.parameters()).dtype),'attention':model.config._attn_implementation,
                                        'allow_tf32':torch.backends.cuda.matmul.allow_tf32,'cudnn_benchmark':torch.backends.cudnn.benchmark},
                        cuda_device=str(torch.cuda.get_device_properties(a.device)),device_after_load=device_snapshot())
            dump(run_dir/'meta.json',meta)
            def write_record(handle,r):
                handle.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
                handle.flush();os.fsync(handle.fileno())
            with (run_dir/'warmups.jsonl').open('x') as wh:
                for task in ['gsm8k','arc']:
                    cs=[c for c in cases if c['task']==task]
                    for policy in spec['policies']:
                        for i in range(spec['warmups_per_task_policy']):
                            c=cs[i%len(cs)]
                            r=generate_one(model,tok,c,policy,plan['cap'],plan['entropy'],a.device)
                            write_record(wh,dict(warmup=True,question_id=c['question_id'],stage=a.stage,model=a.model,
                                task=c['task'],kind=c['kind'],gold=c['gold'],choices=c['choices'],
                                session=a.session,run_uuid=meta['run_uuid'],warmup_index=i,**execution,**r))
            meta.update(status='waiting_barrier',warmups_sha256=sha(run_dir/'warmups.jsonl'),
                        ready_utc=utc_now())
            dump(run_dir/'meta.json',meta)
            release=wait_for_release(a.wave_dir,dict(launch_id=launch['launch_id'],worker_id=a.worker_id,
                run_uuid=meta['run_uuid'],stage=a.stage,model=a.model,session=a.session,ready_utc=meta['ready_utc'],
                warmups_sha256=meta['warmups_sha256'],warmup_calls=2*len(spec['policies'])*spec['warmups_per_task_policy'],
                **execution),timeout=launch['barrier_timeout_seconds'])
            meta.update(status='running',barrier_released_utc=release['released_utc'],
                        barrier_release_sha256=sha(a.wave_dir/'release.json'),scored_started_utc=utc_now())
            dump(run_dir/'meta.json',meta)
            count=0
            with (run_dir/'records.jsonl').open('x') as h:
                for order,(index,policy,repeat) in enumerate(tasks):
                    c=all_cases[index]
                    r=generate_one(model,tok,c,policy,plan['cap'],plan['entropy'],a.device)
                    write_record(h,dict(model=a.model,task=c['task'],kind=c['kind'],gold=c['gold'],choices=c['choices'],
                        question_id=c['question_id'],stage=a.stage,session=a.session,repeat=repeat,order=order,
                        run_uuid=meta['run_uuid'],**execution,**r))
                    count+=1
                    print(f'{a.stage} {a.model} session={a.session} shard={a.shard_index} {count}/{len(tasks)}',flush=True)
            meta.update(status='complete',completed_calls=count,finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                        records_sha256=sha(run_dir/'records.jsonl'),warmups_sha256=sha(run_dir/'warmups.jsonl'),
                        device_after=device_snapshot())
            dump(run_dir/'meta.json',meta)
    except BaseException:
        meta.update(status='failed',error=traceback.format_exc(),device_after_failure=device_snapshot())
        dump(run_dir/'meta.json',meta)
        raise


if __name__=='__main__':main()
