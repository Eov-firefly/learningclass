JANUS v8.3 三卡实验：结果解读与离线复现说明
日期：2026 年 10 月 24 日

一、现在到了哪一步

三卡 A800 的 timing_pilot 和正式 timing 已完成，并已完整备份、校验和收尾。
本轮新增 11,200 条计分记录（pilot 400 + 正式 10,800）及 480 次预热，合计
11,680 次生成。旧 smoke 56 条和 trace 240 条按 SHA 复用，不计入本轮新生成数量。

当前证据不支持“整体推理加速”。三个输出一致的监测对比，在两个模型、两个任务、
三个会话构成的 36 个对比中，额外端到端耗时及其描述性 95% 区间均为正。
Complete 相对 Uniform 的净对比中，Qwen 耗时增加，Mistral 的区间均跨零。
这不证明开销为零或等效，也不能据此宣称普遍的语义质量提升。

下一步主要是本地论文整合与真实人工核验，现在无需重新租用或开启服务器。
本目录是冻结结果的派生解读与英文补充稿，不是完整论文改稿，也不是新的实验发布版。

二、先看哪些文件

1. output/pdf/JANUS_v8_3_结果解读与下一步.pdf
   中文阅读版：结果、计时口径、与既有补充工作的重合、证据限制及下一步。

2. latex_supplement/main.tex
   英文 LaTeX 补充稿，可作为论文整合的素材；包括方法、限制、来源标签和全部正式
   会话对比。需结合论文其他章节统一术语、引用与论断，不能直接视为整篇论文已修订。

3. results_summary.json
   可供程序读取的派生汇总：正式对比、输出一致性、监测开销范围、trace 和契约结果。
   保留数值精度；打印稿的四舍五入不替代该文件或原始证据。

4. formal_contrasts.txt
   全部 48 个正式会话配对对比。差值为 policy − control，单位毫秒；正值表示更慢。
   区间来自冻结分析的 5,000 次题目簇 bootstrap，是未经多重比较校正的描述性区间。
   同一批题目在三会话重复使用，不能把会话或重复调用当成独立新题目来合并推断。

5. parser_provenance_note.txt / parser_provenance_audit.json
   评分器差异的阅读说明与可审计记录。两个历史 parser 对行首缩进后的答案标记处理
   不同，使一个 Qwen/GSM8K 题目在部分契约下的两策略绝对正确数同时相差 1。
   已核对的配对效应、wins/losses 及 114 个 strict 差异案例不受影响。引用绝对正确数
   时须同时注明 parser 来源，不能混用历史评分口径。此审计不改写原始结果。
   sources/parser_received_v8.py 与 sources/parser_local_v8_1.py 是只读来源快照。

6. source_manifest.json / sources/
   来源快照及其原绝对路径、SHA-256 和文件大小。用清单检查本报告引用的是哪个版本。
   sources 是精选证据，不包含本轮全部原始输出与日志；完整归档见第四节。

7. build_summary.py / build_report.py
   本地派生汇总与中文 PDF 构建脚本。它们不执行模型推理。离线使用方式见第五节。
   output/figures/ 为阅读版图形；tmp/ 为构建或检查辅助文件，不是实验原始结果。

三、补充稿来源标签与 sources 文件的对应关系

标签 D：sources/paired_contrasts.json
        正式阶段配对估计、题目簇数、bootstrap 参数与区间。
标签 I：sources/output_identity.json
        生成 token ID 与返回 token ID 的一致性核对。
标签 G：sources/gpu_stratified_timing.json
        按 GPU 分层的描述汇总与配对差值。
标签 N：sources/new_summaries.csv
        控制策略描述性时延与 token 汇总。
标签 P：sources/plan.json
        冻结实验计划。
标签 M：sources/meta_timing_mistral_s0_shard0.json
        sources/meta_timing_qwen_s0_shard0.json
        分别对应原 runs/timing-mistral-s0-shard0/meta.json 与
        runs/timing-qwen-s0-shard0/meta.json，记录模型版本与运行条件。
标签 A：sources/analyze.py
        配对、对比构造与分析程序。
标签 S：sources/stats.py
        题目簇 bootstrap 实现。
标签 E：sources/engine.py 与 sources/run.py
        策略执行路径、计时边界与运行记录。
标签 C：sources/closeout-independent-review.json
        独立 AI 技术收尾审阅、网格/退出回执核验与本地归档校验；不是人工语义评分。

此外，sources/trace_replay.csv 为旧 trace 的机制重放结果；
sources/case_audit_summary.json 与 sources/prefix_replay_verification.json 为回溯契约
和案例审计来源；sources/platform-off-user-confirmation.json 记录平台关机确认的依据。
具体原路径和 SHA 以 source_manifest.json 及 parser_provenance_audit.json 为准。

四、完整备份与冻结证据的边界

本轮三卡完整备份目录（请保留，不能用本报告包替代）：
/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/server_operations_20261023_v8_3/server_backup/1e57f53e927235e24888c6c07d51a7ead747379a41229cdbdc106c868477e26a

该目录中的主归档：
janus-v8_3-three-gpu-timing-1e57f53e927235e24888.tar.gz
SHA-256：fcbf85e0351c058cae11867eb30b847dddb5b2df45f883963471d8b524e72254
归档大小：9,317,414 字节；离线验证覆盖 258 个文件。
verified/ 是校验后的展开内容；同目录还保留校验回执、本地 ACK 与关机派发回执。

原始输出、冻结协议/源码、模型配置、日志和回执是审计基础。本目录只复制必要证据，
在其上生成可读报告、图表和汇总；没有改动冻结原件，也没有重新运行推理。
重建本目录的派生文件不等于从原始逐条数据重跑完整分析，更不等于重新完成实验。
旧 smoke/trace、旧主实验及人工核验材料仍需各自的原归档；本轮三卡备份不替代它们。

平台收尾：北京时间 10 月 24 日 03:15 已通过安全守卫发出关机请求；随后由用户明确
确认平台显示“已关机”。本地 platform_state_confirmed_off 和 billing_stop_verified
据此登记。该依据是用户的平台状态确认，不是代理直接读取控制台或核验账单；
记录时间不代表已独立核实的实际断电时间。巡检 janus-v8-2 已设为 PAUSED，控制器
已结束，无需恢复它。运维证据保存在：
/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/server_operations_20261023_v8_3/platform-off-user-confirmation.json
/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/server_operations_20261023_v8_3/automation-paused-receipt.json

五、离线复现本目录的汇总和中文 PDF

在终端执行：

cd '/Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/postrun_analysis_20261024_v8_3'
python3 build_summary.py --from-snapshots
python3 build_report.py

--from-snapshots 会检查本目录来源快照的 SHA，使用已保存的证据生成汇总，不要求
服务器、模型或网络连接。请使用这个选项；不带该选项会尝试从原绝对路径重采集来源。
如需保留当前派生文件版本，可先复制本报告目录后再重建。

汇总脚本依赖 Python 3 标准库。中文 PDF 构建还需要本地已安装的 reportlab、matplotlib，
默认字体为 macOS 的 /System/Library/Fonts/STHeiti Light.ttc。
其他环境可通过 JANUS_CJK_FONT 指定 ReportLab 可读取的中文字型，例如：

JANUS_CJK_FONT='/绝对路径/中文字型.ttf' python3 build_report.py

这些命令重建 JSON/TXT 汇总、图形和中文阅读版 PDF；不负责修改或编译英文 LaTeX。
LaTeX 源文件应在相应 TeX 环境中单独编译并检查排版。

六、还有哪些工作，应按什么顺序做

1. 先收窄论文主张与整合证据。
   区分停止策略净效果、输出一致时的监测开销、旧轨迹反事实重放和评分契约敏感性。
   三卡并行分摊实验任务，不表示单次推理三倍加速，也不是在线服务吞吐量基准。
   本轮没有新题目身份；三卡、五卡和旧单卡条件不混池。可选的新 GPU quality 扩展
   没有运行，不能把 10,800 个旧轨迹反事实输出写成新采集的质量实验。

2. 组织两名真实独立评审，各完成 600 条输出记录。
   当前两份表的评分仍为空；600 条记录覆盖 525 个模型×任务×题目身份。
   现有材料目录：
   /Users/cchang/Documents/patent/Janus_Joint_Token_Compute_Scheduling_LLM_Agents/peerj_revision_20261022_v6/output/postrun/human_audit
   按其中 rater_instructions_zh.md，分别向两位评审提供各自的 rater1_package.zip 和
   rater2_package.zip。不要同时提供另一人的评分、策略标签、自动分数或组织者私有映射。
   评审独立填写 semantic_correct、answer_complete（1/0/U）及理由，不能由生成式
   模型代填。先封存双方原始评分，再处理分歧与仲裁，保留 U 并报告其处理方法。
   完成后核对记录身份、原始一致率和交叉表，并按既有分层抽样设计计算加权估计；
   富集差异样本的原始平均值不能直接当作总体准确率。

3. 人工结果回来后，再完成相应结果与限制章节。
   AI 技术门控、token/文本前缀核对及 114 案例的结构/词法诊断，均不等于人工语义审核，
   也不能证明全部被截去内容语义无害。作者信息、许可、数据和代码可用性仍需作者核实。
   若后续确需支持未见题目泛化、跨硬件或语义质量的新主张，再另立实验方案评估服务器
   需求；无需为当前本地整合工作开机。

本报告包不收录个人密钥或组织者私有评审映射；人工材料只提供既有位置说明。
请分别保管完整实验归档、原始人工评分及派生报告，避免以摘要覆盖原始证据。
