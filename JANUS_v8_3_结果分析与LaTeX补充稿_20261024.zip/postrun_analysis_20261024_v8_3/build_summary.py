#!/usr/bin/env python3
"""Derived summaries only. Never modifies frozen data or performs model inference."""
from pathlib import Path
import argparse, csv, hashlib, json, shutil
from collections import defaultdict

OUT = Path(__file__).resolve().parent
P = OUT.parent
B = P/'server_operations_20261023_v8_3/server_backup/1e57f53e927235e24888c6c07d51a7ead747379a41229cdbdc106c868477e26a/verified/project'
A = B/'experiments/analysis/after_timing'
FILES = {
 'paired_contrasts.json': A/'paired_contrasts.json',
 'output_identity.json': A/'output_identity.json',
 'gpu_stratified_timing.json': A/'gpu_stratified_timing.json',
 'analysis_status.json': A/'analysis_status.json',
 'new_summaries.csv': A/'new_summaries.csv',
 'meta_timing_mistral_s0_shard0.json': B/'experiments/runs/timing-mistral-s0-shard0/meta.json',
 'meta_timing_qwen_s0_shard0.json': B/'experiments/runs/timing-qwen-s0-shard0/meta.json',
 'analyze.py': B/'experiments/janus_v8/analyze.py',
 'stats.py': B/'experiments/janus_v8/stats.py',
 'engine.py': B/'experiments/janus_v8/engine.py',
 'run.py': B/'experiments/janus_v8/run.py',
 'parser_received_v8.py': Path('/Users/cchang/Downloads/learningclass-main/research_outputs/experiments_v8/janus_v8/contracts.py'),
 'parser_local_v8_1.py': P/'peerj_followup_20261022_v8_1/experiments/janus_v8/contracts.py',
 'closeout-independent-review.json': P/'server_operations_20261023_v8_3/closeout-independent-review.json',
 'platform-off-user-confirmation.json': P/'server_operations_20261023_v8_3/platform-off-user-confirmation.json',
 'plan.json': P/'peerj_followup_20261023_v8_3_3gpu/experiments/plan.json',
 'case_audit_summary.json': P/'peerj_followup_20261022_v8_1/analysis/case_audit/summary.json',
 'prefix_replay_verification.json': P/'peerj_followup_20261022_v8_1/analysis/prefix_replay/verification_and_summary.json',
 'trace_replay.csv': P/'server_operations_20261023_v8_2/attempt2/server_backup/29b8f1aeb17820eef833b5ba965914a8a125798edc84cd887a1bdfdc19567a1c/verified/project/experiments/analysis/after_trace/trace_replay.csv',
}
MONITORS = [('entropy_observe','complete'), ('boundary_observe','uniform'), ('entropy_uniform','boundary_observe')]

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def build(use_snapshots=False):
    source=OUT/'sources'; source.mkdir(exist_ok=True)
    if not use_snapshots:
        provenance=[]
        for name,path in FILES.items():
            shutil.copyfile(path,source/name)
            provenance.append({'snapshot':f'sources/{name}','original_path':str(path),'sha256':digest(path),'bytes':path.stat().st_size})
        write_json(OUT/'source_manifest.json',provenance)
    else:
        for f in json.loads((OUT/'source_manifest.json').read_text()):
            assert digest(OUT/f['snapshot'])==f['sha256'], f['snapshot']
    data={k:json.loads((source/k).read_text()) for k in FILES if k.endswith('.json')}
    review=data['closeout-independent-review.json']; assert review['passed'] and not review['blocking_issues']
    rows=[dict(x) for x in data['paired_contrasts.json'] if x['stage']=='timing']
    identity={(x['model'],x['task'],x['session'],x['policy'],x['control']):x for x in data['output_identity.json'] if x['stage']=='timing'}
    gpu=data['gpu_stratified_timing.json']
    controls=defaultdict(list)
    for x in gpu['summaries']:
        if x['stage']=='timing':controls[(x['model'],x['task'],x['session'],x['policy'])].append(x)
    for r in rows:
        ctrl=controls[(r['model'],r['task'],r['session'],r['control'])]
        den=sum(x['n_calls'] for x in ctrl)
        ctrlmean=sum(x['mean_end_to_end_seconds']*x['n_calls'] for x in ctrl)/den
        r.update({k+'_ms':r[k]*1000 for k in ['mean','lo','hi']})
        r['relative_percent_of_control_mean']=100*r['mean']/ctrlmean
        r['control_mean_seconds']=ctrlmean
        ident=identity[(r['model'],r['task'],r['session'],r['policy'],r['control'])]
        assert r['output_matched']==ident['output_matched']
        r['identity_n_pairs']=ident['n_pairs']
    assert len(rows)==48
    monitor=[x for x in rows if (x['policy'],x['control']) in MONITORS]
    assert len(monitor)==36 and all(x['lo']>0 and x['output_matched'] and x['n']==60 for x in monitor)
    assert sum(x['identity_n_pairs'] for x in monitor)==6480
    ranges=[]
    for model in ['mistral','qwen']:
        for task in ['arc','gsm8k']:
            for pol,ctl in MONITORS:
                xs=[x for x in monitor if (x['model'],x['task'],x['policy'],x['control'])==(model,task,pol,ctl)]
                assert len(xs)==3
                ranges.append({'model':model,'task':task,'policy':pol,'control':ctl,'sessions':3,
                    'mean_difference_ms_min':min(x['mean_ms'] for x in xs),'mean_difference_ms_max':max(x['mean_ms'] for x in xs),
                    'relative_percent_min':min(x['relative_percent_of_control_mean'] for x in xs),'relative_percent_max':max(x['relative_percent_of_control_mean'] for x in xs)})
    strata=[x for x in gpu['paired_differences'] if x['stage']=='timing' and (x['policy'],x['control']) in MONITORS]
    assert len(strata)==108 and all(x['mean_paired_difference_seconds']>0 for x in strata)
    trace=list(csv.DictReader((source/'trace_replay.csv').open()))
    frozen=[x for x in trace if x['stage']=='trace' and float(x['threshold'])==0.01 and int(x['window'])==5 and int(x['min_steps'])==21]
    assert len(frozen)==240
    ts={'trajectories':len(frozen),'early_triggers':sum(x['triggered_before_uniform']=='True' for x in frozen),
        'overlap_opportunities':sum(int(x['overlap_opportunities']) for x in frozen),
        'stable_non_eos_steps':sum(int(x['stable_non_eos_steps']) for x in frozen),
        'threshold':.01,'window':5,'min_steps':21,'scope':'SHA-reused v8.2 traces; mechanism replay, not measured latency'}
    assert (ts['early_triggers'],ts['overlap_opportunities'],ts['stable_non_eos_steps'])==(0,0,3116)
    # Use one parser provenance for every derived count; preserve both source summaries.
    prefix=data['prefix_replay_verification.json']
    assert prefix['status']=='passed' and not prefix['failures']
    contracts=[]; reconciliations=[]
    for x in prefix['contrasts']:
        if (x['stage'],x['policy'],x['baseline'])!=('main','complete','uniform'): continue
        mt=f"{x['model']}/{x['task']}"; a=x['paired_accuracy']
        c={'model_task':mt,'contract':x['contract'],'n_pairs':x['n'],
           'wins':a['wins'],'losses':a['losses'],'complete_correct':x['correct'],
           'uniform_correct':x['baseline_correct'],'difference_percentage_points':100*a['mean']}
        assert c['n_pairs']==600
        old=data['case_audit_summary.json']['by_model_task'][mt]['contracts'][x['contract']]
        assert (c['wins'],c['losses'])==(old['wins'],old['losses'])
        assert abs(c['difference_percentage_points']-old['difference_percentage_points'])<1e-10
        if (c['complete_correct'],c['uniform_correct'])!=(old['complete_correct'],old['uniform_correct']):
            assert mt=='qwen/gsm8k' and x['contract'] in ('closure_tolerant','closure_balanced','last_marked')
            assert (old['complete_correct']-c['complete_correct'],old['uniform_correct']-c['uniform_correct'])==(1,1)
            reconciliations.append({'model_task':mt,'contract':x['contract'],
                'received_parser_counts':[old['complete_correct'],old['uniform_correct']],
                'local_parser_counts':[c['complete_correct'],c['uniform_correct']]})
        contracts.append(c)
    assert len(contracts)==20 and len(reconciliations)==3
    result={'schema':'janus-v8.3-derived-report-v1','scope':'Offline reporting of frozen results; no inference or new CI calculation.',
        'counts':review['counts'],'monitor_contrasts':MONITORS,'formal_contrasts':rows,'monitor_session_mean_ranges':ranges,
        'monitor_identity_comparison_pairs':6480,'monitor_positive_descriptive_intervals':36,
        'monitor_gpu_stratum_positive_means':len(strata),'trace_frozen_rule':ts,'contract_sensitivity':contracts,
        'contract_provenance':{'source':'sources/prefix_replay_verification.json',
          'parser_sha256':digest(source/'parser_local_v8_1.py'),
          'reconciliation_note':'parser_provenance_note.txt','reconciliation_audit':'parser_provenance_audit.json',
          'absolute_count_reconciliations':reconciliations},
        'warnings':['Intervals are copied from the frozen 5000-replicate question-cluster bootstrap, descriptive and unadjusted.',
          'Session ranges are ranges of three means, not confidence intervals.',
          'Same 60 questions/task recur across three sessions; no new holdout, no pooling of sessions or hardware regimes.',
          'Human semantic annotation remains incomplete; structural and lexical diagnostics are not human judgments.',
          'A passing analysis_status.json alone is not a full-experiment completion receipt. Counts are bound to the independent archive/grid/receipt review.',
          'Contract absolute counts use the local v8.1 prefix-replay parser. The received v8 parser accepts indentation before ####; one equal-outcome question increases both strategy counts by one under three contracts. All paired differences and the 114 strict-discordance cases are unaffected.']}
    write_json(OUT/'results_summary.json',result)
    # A readable, portable table; values remain available at full precision in JSON.
    lines=['JANUS v8.3 formal timing contrasts','Difference = policy minus control; milliseconds. Positive = slower.',
       '95% descriptive unadjusted question-cluster percentile bootstrap intervals; n=60 question clusters/session.',
       'No pooled inference across sessions. Same questions are repeated.\n',
       'model\ttask\tsession\tpolicy\tcontrol\tmean_ms\tlo_ms\thi_ms\toutput_matched']
    for r in rows:lines.append('\t'.join([str(r[k]) for k in ['model','task','session','policy','control']]+[f'{r[k]:.6f}' for k in ['mean_ms','lo_ms','hi_ms']]+[str(r['output_matched'])]))
    (OUT/'formal_contrasts.txt').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'formal_contrasts':len(rows),'output_matched_monitor_contrasts':len(monitor),'all_monitor_intervals_positive':True,'trace':ts},ensure_ascii=False))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--from-snapshots',action='store_true');args=ap.parse_args();build(args.from_snapshots)
