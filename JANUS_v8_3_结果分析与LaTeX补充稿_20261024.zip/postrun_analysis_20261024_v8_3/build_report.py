#!/usr/bin/env python3
"""Render a descriptive report from the frozen-result summary; no model inference."""
import json, os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/janus-v83-matplotlib')
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['axes.unicode_minus']=False
import matplotlib.pyplot as plt
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib.enums import TA_LEFT
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parent
S=json.loads((ROOT/'results_summary.json').read_text())
OUT=ROOT/'output'; (OUT/'pdf').mkdir(parents=True,exist_ok=True); (OUT/'figures').mkdir(exist_ok=True)
PAIRS=[tuple(x) for x in S['monitor_contrasts']]
GROUPS=[('mistral','arc'),('mistral','gsm8k'),('qwen','arc'),('qwen','gsm8k')]
LABELS={'mistral':'Mistral','qwen':'Qwen','arc':'ARC','gsm8k':'GSM8K'}

def draw_chart():
    titles=['Entropy on completion stopping','Boundary observation','Entropy on boundary observation']
    fig,axes=plt.subplots(1,3,figsize=(10.2,5.3),sharey=True,layout='constrained')
    labels=[]
    for m,t in GROUPS:
        for sess in range(3): labels.append(f'{LABELS[m]} / {LABELS[t]} / S{sess}')
    for ax,pair,title in zip(axes,PAIRS,titles):
        rr=[]
        for m,t in GROUPS:
            xx=sorted([r for r in S['formal_contrasts'] if (r['model'],r['task'])==(m,t) and (r['policy'],r['control'])==pair],key=lambda r:r['session'])
            rr.extend(xx)
        for y,r in enumerate(rr):
            ax.errorbar(r['mean_ms'],y,xerr=[[r['mean_ms']-r['lo_ms']],[r['hi_ms']-r['mean_ms']]],fmt='o',color='#1d5e8b' if y<6 else '#a64a24',markersize=4,capsize=2,lw=1.3)
        ax.axvline(0,color='#697a88',lw=.8,ls='--')
        for y in [2.5,5.5,8.5]:ax.axhline(y,color='#dbe1e5',lw=.7)
        ax.set_title(title,fontsize=10,pad=12)
        ax.set_xlabel('Added end-to-end latency (ms)',fontsize=9)
        ax.grid(axis='x',color='#eef1f3');ax.set_axisbelow(True)
        ax.spines[['top','right']].set_visible(False)
        ax.set_yticks(range(12),labels,fontsize=9)
        ax.tick_params(axis='x',labelsize=9)
        ax.set_xlim(left=-3)
    axes[0].invert_yaxis()
    fig.suptitle('JANUS v8.3 | Output-matched monitoring contrasts',fontsize=14,fontweight='bold')
    fig.savefig(OUT/'figures/monitor_overhead.png',dpi=220)
    fig.savefig(OUT/'figures/monitor_overhead.svg')
    plt.close(fig)

FONT_PATH = os.environ.get('JANUS_CJK_FONT', '/System/Library/Fonts/STHeiti Light.ttc')
pdfmetrics.registerFont(TTFont('JanusCJK', FONT_PATH, subfontIndex=0))
NAVY=colors.HexColor('#15354d'); BLUE=colors.HexColor('#28678b'); GRAY=colors.HexColor('#4e5c66'); PALE=colors.HexColor('#edf3f6')
styles={
 'title':ParagraphStyle('title',fontName='JanusCJK',fontSize=24,leading=32,textColor=NAVY,spaceAfter=17),
 'sub':ParagraphStyle('sub',fontName='JanusCJK',fontSize=11,leading=17,textColor=GRAY,spaceAfter=16),
 'h':ParagraphStyle('h',fontName='JanusCJK',fontSize=15,leading=22,textColor=NAVY,spaceBefore=9,spaceAfter=10),
 'body':ParagraphStyle('body',fontName='JanusCJK',fontSize=10.5,leading=17,textColor=colors.HexColor('#202e37'),spaceAfter=9,wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='JanusCJK',fontSize=8.5,leading=13,textColor=GRAY,spaceAfter=7,wordWrap='CJK'),
 'cell':ParagraphStyle('cell',fontName='JanusCJK',fontSize=9,leading=14,textColor=colors.HexColor('#202e37'),wordWrap='CJK'),
 'head':ParagraphStyle('head',fontName='JanusCJK',fontSize=9,leading=14,textColor=colors.white,wordWrap='CJK'),
}
def p(text,style='body'):
    return Paragraph(text.translate(str.maketrans({'–':'-','—':'-','−':'-'})),styles[style])
def table(rows,widths):
    data=[[p(str(c),'head' if i==0 else 'cell') for c in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LINEBELOW',(0,-1),(-1,-1),.6,colors.HexColor('#c7d3dc'))]))
    return t
def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#d6dfe5'));c.line(48,43,547,43)
    c.setFont('JanusCJK',8);c.setFillColor(GRAY)
    c.drawString(48,29,'JANUS v8.3 · 本地结果解读 · 2026-10-24')
    c.drawRightString(547,29,f'{doc.page}')

def build_pdf():
    story=[]
    def add(text,style='body'):story.append(p(text,style))
    add('JANUS v8.3 实验结果与下一步','title')
    add('三卡 A800 计时补充实验｜冻结结果的离线解读<br/>阅读版 · 2026 年 10 月 24 日','sub')
    add('实验已完成；当前进入论文整合与人工核验阶段','h')
    add('本轮新增 11,200 条计分记录和 480 次预热，共 11,680 次生成。完整实验网格、阶段退出码、屏障和备份校验均通过。主机已按安全流程请求关机，随后由你确认平台显示“已关机”；巡检已暂停。当前工作可在本地继续，无需立即再租服务器。')
    add('核心发现','h')
    add('三个输出保持一致的监测对比，在两个模型、两个任务、三个会话形成的 36 个对比中，额外端到端耗时均为正，描述性 95% 区间也均高于零。这支持“当前实现存在监测开销”，不能概括为“整体推理加速”。')
    add('Complete 相对 Uniform 的净变化与模型有关：Qwen 在本轮各任务、会话中耗时增加；Mistral 的区间跨零，未观察到明确净时延收益。停止策略往往改变输出，因此这一净对比需要与纯监测开销分开解释。')
    story.append(table([
      ['内容','完成数量','证据用途'],
      ['三卡 pilot','400 计分 + 120 预热','新运行条件下的技术门控'],
      ['三卡正式 timing','10,800 计分 + 360 预热','3 会话配对端到端计时'],
      ['原始文件及日志','258 个文件校验通过','可追溯归档；完整性独立复核'],
      ['旧 smoke / trace','56 / 240，按 SHA 复用','真实停止验证 / 机制重放'],
      ['人工语义审核','2 份各 600 行，尚未评分','仍需两名真实独立评审'],
    ],[136,161,202]))
    story.append(Spacer(1,10))
    add('结论边界：本轮重复使用既有题目，新增题目身份为 0；三会话不是三份独立题库。三卡并行用于分摊任务，不等于单次推理获得三倍加速，也不是在线服务吞吐量基准。','small')
    add('主要来源：closeout-independent-review.json、paired_contrasts.json、output_identity.json；归档定位见第 5 页。','small')
    story.append(PageBreak())

    add('1. 输出一致时，监测带来多少开销？','h')
    add('下图仅展示生成 token ID 与返回 token ID 均匹配的监测对比。正数表示耗时增加。每点对应一个模型、任务、会话；横线直接采用冻结分析的描述性 95% 区间，没有跨会话合并。')
    story.append(Image(str(OUT/'figures/monitor_overhead.png'),width=499,height=259.3))
    add('三个会话均值的范围（毫秒；括号为相对控制组均值的百分比）','h')
    rows=[['模型 / 任务','熵监测 + Complete','边界观察 + Uniform','熵监测 + 边界观察']]
    for m,t in GROUPS:
        cells=[f'{LABELS[m]} / {LABELS[t]}']
        for a,b in PAIRS:
            r=next(x for x in S['monitor_session_mean_ranges'] if (x['model'],x['task'],x['policy'],x['control'])==(m,t,a,b))
            cells.append(f"{r['mean_difference_ms_min']:.2f}–{r['mean_difference_ms_max']:.2f}<br/>({r['relative_percent_min']:.2f}–{r['relative_percent_max']:.2f}%)")
        rows.append(cells)
    story.append(table(rows,[112,129,129,129]))
    story.append(Spacer(1,8))
    add('表中范围是三个会话均值的最小值—最大值，不是置信区间。36 个监测对比共核对 6,480 个输出比较对；这些比较复用相应控制输出，不能当作 6,480 个独立题目。108 个 GPU 分层监测均值方向亦为正，但分层不是独立重复实验。','small')
    add('开销的含义','h')
    add('边界观察包含逐 token 的回调、ID 拷贝、全前缀解码、完成条件解析与记录。熵监测包含 float 运算、熵计算、GPU–CPU 同步及门控更新。这里测量的是这些实现路径的整体增量，不能拆称为单独“解析器耗时”或纯熵公式成本。')
    story.append(PageBreak())

    add('2. 提前停止，是否抵消了监测开销？','h')
    add('下表为 Complete − Uniform，单位毫秒；正数表示 Complete 更慢。格式为均值 [描述性 95% 区间]。该对比是停止策略的净效果，通常会改变生成或返回内容，不能当成输出固定的监测成本。')
    rows=[['模型 / 任务','会话 0','会话 1','会话 2']]
    for m,t in GROUPS:
        rr=sorted([x for x in S['formal_contrasts'] if (x['model'],x['task'],x['policy'],x['control'])==(m,t,'complete','uniform')],key=lambda x:x['session'])
        rows.append([f'{LABELS[m]} / {LABELS[t]}']+[f"{x['mean_ms']:.2f}<br/>[{x['lo_ms']:.2f}, {x['hi_ms']:.2f}]" for x in rr])
    story.append(table(rows,[112,129,129,129]));story.append(Spacer(1,12))
    add('Qwen：两个任务三个会话的区间均高于零，净耗时增加约 2.5%–2.9%。其中 ARC 的所有输出比较对匹配，GSM8K 则并非全部匹配。')
    add('Mistral：所有区间均跨零。本轮无法确认净时延减少，也不能据此宣称“开销为零”或“等效”。虽然平均生成 token 数减少，节省的生成时间并未形成明确的端到端收益。')
    add('统计与计时口径','h')
    add('正式网格为 2 模型 × 2 任务 × 60 题 × 5 策略 × 3 重复 × 3 会话 = 10,800 条计分。每会话先按题目对齐并核对 GPU UUID、运行 UUID 与分片，再平均该题的 3 次重复，获得 60 个题目簇均值。冻结分析以 5,000 次题目簇 bootstrap 给出百分位 95% 区间（固定种子 20261019）。')
    add('这些区间是探索性、描述性的，未作多重比较校正；不提供新计算的合并效应或确认性显著结论。同一批题目在三个会话反复测量，不能把 3 × 60 当作 180 个新题目。')
    add('端到端计时包含输入分词与传输、生成和回调同步、CPU token ID 处理及最终解码；不包含模型加载、预热、评分、日志写入及网络排队。提示词字符串已预先构建。')
    add('硬件运行条件','h')
    add('同一主机的三张 A800 80GB 并行运行配对分片，采用 bfloat16、SDPA、batch size 1、greedy decode 和 512 token 上限。每题的全部策略与重复保持在同一 GPU 分片。共享主机负载会随 worker 完成而变化，因此结果限定于 concurrent_three_gpu_paired 条件；不与旧版单卡隔离时延或五卡时延混池。')
    add('来源：paired_contrasts.json、gpu_stratified_timing.json、output_identity.json、plan.json，以及冻结 engine.py / stats.py 的计时与聚合定义。','small')
    story.append(PageBreak())

    add('3. 哪些补充建议已经覆盖？','h')
    story.append(table([
      ['建议 / 缺口','已获得证据','当前判断'],
      ['原实验完整性','原 25,200 条计分数据与离线核验','已覆盖，无需重跑'],
      ['停止策略与评分契约','3,600 条旧轨迹生成 10,800 个反事实输出；5 契约','重放完成；未跑新 GPU quality'],
      ['实际停止与重放一致性','56 条 smoke；8 个完整策略组通过','已覆盖当前验证范围'],
      ['熵 / 完成门控机制','240 条 trace × 12 规则 = 2,880 重放单元','机制分析完成，不是新计时'],
      ['多会话真实计时','三卡 pilot + 10,800 条正式计分','已完成；运行条件有边界'],
      ['114 差异案例','前缀与结构 / 词法检查完成','机械诊断，不替代人工语义判断'],
      ['独立语义 / 完整性审核','两份 600 行表目前评分均为空','仍缺，优先本地组织'],
    ],[124,229,146]));story.append(Spacer(1,9))
    add('机制结果应怎样写','h')
    add('冻结规则 threshold=0.01、window=5、min_steps=21，在 240 条轨迹中未观察到提前触发，也未观察到完成条件与稳定条件重合的机会；但存在 3,116 个稳定的非 EOS 步。准确解释是本样本中门条件没有重合，不能写成“模型没有稳定区间”。其他阈值只属于探索性敏感性分析，不能回头替换冻结规则。')
    add('评分契约会改变看起来的收益','h')
    rows=[['契约：Complete − Uniform','Qwen<br/>GSM8K','Qwen<br/>ARC','Mistral<br/>GSM8K','Mistral<br/>ARC']]
    contracts=['strict','closure_tolerant','wrapper_balanced_strict','closure_balanced','last_marked']
    for c in contracts:
        cells=[c]
        for mt in ['qwen/gsm8k','qwen/arc','mistral/gsm8k','mistral/arc']:
            r=next(x for x in S['contract_sensitivity'] if x['contract']==c and x['model_task']==mt)
            cells.append(f"{r['difference_percentage_points']:+.2f}")
        rows.append(cells)
    story.append(table(rows,[211,72,72,72,72]));story.append(Spacer(1,8))
    add('单位为百分点；旧 main 阶段每个模型×任务有 600 个配对。五种契约是同一批回溯数据的不同评分规则，不是五次独立质量实验。114 个 strict 差异案例中，闭合围栏 1、闭合 LaTeX 13、答案后文本 98、重复循环 2；114/114 为 token 与文本前缀，last_marked 值未变。这仍不足以证明全部被截去内容在语义上无害。','small')
    add('来源口径：契约表统一采用本地 v8.1 prefix replay。原案例审计使用接收版 v8 parser，允许 #### 前缩进；一个两策略同分案例使三种契约的绝对正确数各差 1，配对差值及 114 案例分类不变。详见 parser_provenance_note.txt。','small')
    story.append(PageBreak())

    add('4. 接下来做什么？','h')
    add('现在无需开启服务器。主要工作是把已有证据写清楚，并完成真实人工审核。若以后要主张未见题目泛化、跨硬件效果或语义质量提升，再另立方案评估是否需要新增 GPU 实验。')
    add('第一步：整合论文，保留不利与不确定结果','h')
    add('英文 LaTeX 补充稿可接入论文：明确三卡运行条件、配对统计口径与额外监测成本；将回溯契约敏感性、机制 trace 与真实时延分开呈现。旧稿中的“整体加速”“更强解题能力”“语义不变”等表述，须逐项收窄到实际证据。旧 Legacy 的精确修复对照也不能仅凭代码摘要视为已经验证。')
    add('第二步：组织两名真实独立评审','h')
    add('待审的是 600 条输出记录，覆盖 525 个不同的模型×任务×题目身份。分别给两名评审各自的 rater1_package.zip、rater2_package.zip；不要同时给出另一人的评分、策略标签、自动分数或组织者私有映射。原包位置见交付目录 README.txt。')
    add('按原说明独立填写 semantic_correct、answer_complete（1 / 0 / U）及理由，不由 LLM 代填。先保留并封存两份原始评分，再处理分歧和仲裁；U 不能悄悄转成 0。完成后需核对 600 个记录身份、报告原始一致率与完整交叉表，并按既有分层抽样概率计算设计加权估计。富集差异样本的原始平均值不能当作总体准确率。')
    add('第三步：完成投稿与发布信息','h')
    add('作者信息、数据 / 代码可用性及许可需要作者核实。人工审核、一致性、仲裁和设计加权结果尚未完成；应明确列为待办或限制，不能将 AI 技术门控、114 案例机械检查标为人工语义审核。')
    add('归档与可复核性','h')
    add('本交付包含中文报告、英文 LaTeX 源文件、监测开销图、48 个正式配对对比、汇总 JSON、选取的聚合证据与 SHA256 清单、离线重建脚本。它是结果分析包，不替代完整原始实验备份；未附人审盲审包与私有抽样映射。')
    add('完整备份 bundle ID：<br/>1e57f53e927235e24888c6c07d51a7ead747<br/>379a41229cdbdc106c868477e26a','small')
    add('正式计时运行时间：北京时间 10 月 23 日 22:16:55 至 10 月 24 日 03:12:43，约 4 小时 56 分。03:15 通过安全检查后发出关机请求；后续平台已关机依据是你的明确确认。没有独立查验账单，不能据此给出精确实际关机时刻或最终费用。','small')
    add('证据快照的原路径、字节数和 SHA256 见 source_manifest.json。完整正式阶段通过依据为归档 / 网格 / 回执的 closeout 独立复核，不仅是 analysis_status.json 的单一 passed 标记。','small')
    doc=SimpleDocTemplate(str(OUT/'pdf/JANUS_v8_3_结果解读与下一步.pdf'),pagesize=(595.276,841.89),rightMargin=48,leftMargin=48,topMargin=43,bottomMargin=58,title='JANUS v8.3 实验结果与下一步',author='JANUS project - AI-assisted technical analysis')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)

if __name__=='__main__':
    draw_chart();build_pdf();print(OUT/'pdf/JANUS_v8_3_结果解读与下一步.pdf')
