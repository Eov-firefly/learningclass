"""Build the active v8.4 Markdown with Pandoc and pdfLaTeX."""
from pathlib import Path
import subprocess
import re

root=Path(__file__).resolve().parent
md=(root/'manuscript.md').read_text()
title,body=md.split('\n',1)
subprocess.run(['pandoc','--from=markdown+tex_math_dollars','--to=latex','--standalone',
 '--shift-heading-level-by=-1','--metadata','title='+title.lstrip('# '),
 '--include-in-header=header.tex','--variable=documentclass:article',
 '--variable=fontsize:12pt','--variable=papersize:a4','--output=main.tex'],
 input=body,text=True,cwd=root,check=True)
tex=(root/'main.tex').read_text()
tex=re.sub(r'\\texttt\{([0-9a-f]{40,64})\}',lambda m:r'\texttt{\seqsplit{'+m[1]+'}}',tex)
(root/'main.tex').write_text(tex)
for i in range(2):
 with (root/f'compile-pass{i+1}.log').open('w') as log:
  subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
