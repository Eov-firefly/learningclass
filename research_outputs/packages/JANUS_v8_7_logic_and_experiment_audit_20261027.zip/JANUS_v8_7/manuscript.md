# Budget-viable commitment for contract-constrained LLM decoding: a framework proposal and empirical motivation

Ya Bai, GuoZhen Bian*, Cheng Chang, ZhengGuang Cui, HaiLong Qin, ZhiHui Huang, Yue Wang

China Telecom Cloud Network Operating System R&D Center, Beijing, China

\* Correspondence: biangz@chinatelecom.cn

Research draft v8.7, 27 October 2026. The proposed decoder has not been evaluated by the historical inference experiments; algorithmic priority is not established. Prototype checks establish implementation behavior only; task-level validation and novelty assessment remain open.

## Abstract

An answer-boundary stopping rule can return a locally complete value inside an unfinished document, whereas grammar-constrained generation can consume a fixed budget without reaching an accepting state. We propose a budget-viable commitment framework that separates drafting, binding, constrained repair and final submission. After selected fields are bound, a token-level viability mask retains only continuations that can reach a declared accepting state within the remaining budget. Submission requires a final contract certificate and preservation of the bound fields; unsupported or infeasible cases are explicit abstentions. We prove conditional non-emptiness of the viable support and budget-bounded completion after entry into a viable repair state, under exact transition, distance and scoring assumptions. A finite repair-language prototype integrates with Transformers generation and has passed controlled CPU tests, including masking, deadline handling, field preservation and abstention accounting. Historical two-model, two-task results motivate the design but do not validate it: 204 contract-validity repairs included 114 correct and 90 wrong answers, and prior output-matched monitoring incurred measurable costs. We also identify an important reduction: when the only remaining choices are equivalent formatting closures, deterministic shortest repair can provide the same acceptance and bound value without new model calls. The proposed framework must therefore be compared against that baseline and tested on contracts with meaningful remaining completion choices. No benchmark improvement, new-paradigm priority or GPU performance advantage is established here.

Keywords: constrained decoding; budget viability; transactional commitment; contract validation; selective output

## 1. Introduction

Generating text and submitting an accepted artifact are different operations. A model can emit a complete numeric field while a surrounding wrapper remains open, or reach a length limit before its structured output is complete. A stopping callback handles the return event but cannot repair the first problem; a structural prefix constraint alone need not handle the second. A decoder that changes content also invalidates shared-trajectory arguments used to analyze pure early stopping.

We investigate a possible extension: **budget-viable commitment**. The decoder first drafts without the proposed repair mask. When a candidate or partial structured object is identified, selected fields are bound. A constrained phase permits only completions that preserve those fields and remain feasible within the remaining token budget. A final validator commits the artifact, while failures return an explicit abstention rather than a malformed answer labeled as success. The boundary between tentative text and committed output is part of the protocol.

This is a candidate framework, not a demonstrated new decoding paradigm. Its mechanisms must be distinguished from existing grammar constraints, budget-aware search, caching and deterministic postprocessing. The proposed contribution to investigate is their explicit combination at a commitment boundary with a token-budget invariant and complete failure accounting. Whether that combination is substantively novel and practically useful requires direct literature and experimental comparisons.

Historical evidence explains the motivation. In the existing Complete-versus-Uniform records, all 204 shortened trajectories were contract-validity repairs, and 90 repaired outputs still had wrong reference answers. The strict contract also accepted incomplete wrappers. These facts motivate structural certification and an explicit separation of validity from truth, not a claim that the proposed controller improves correctness. Earlier monitoring experiments likewise motivate measuring the full new path rather than assuming constrained repair will be cheap.

The questions for the new method are: RQ1, can a repair-and-commit controller enforce contract and field-preservation conditions after entering a viable state; RQ2, does its budget mask improve completion coverage over a grammar-only controller; and RQ3, does it offer value beyond deterministic repair at an acceptable total cost? Section 3 summarizes precursor evidence and controlled software checks. Section 4 specifies the unexecuted task-level evaluation needed to answer RQ2 and RQ3. The historical protocols and all ten original tables are preserved in the separate historical supplement.

### 1.1. Related work and the novelty boundary

Lexically constrained generation and grammar-constrained decoding are established techniques (Hokamp and Liu, 2017; Geng et al., 2023). Native decoder stop strings already terminate at detected token boundaries (Hugging Face, Transformers 4.48.2), while systems such as XGrammar and Outlines provide practical structured generation. Budget-aware reasoning studies another dimension of inference allocation (Wang et al., 2024; Han et al., 2025; Muennighoff et al., 2025). These lines of work define the comparison boundary; a change of terminology does not establish a distinct algorithm.

The proposed framework constrains both legal continuations and return decisions, preserves an explicitly bound part of the draft, and conditions token support on remaining distance to acceptance. These ingredients must be compared to existing implementations of equivalent behavior. In particular, a grammar engine augmented with the same exact distance test may be algorithmically equivalent. We do not claim otherwise without evidence, and do not claim priority over all deadline-aware constrained search, constrained editing or verified-generation methods.

The prototype targets finite verified completion languages. A wrapper example tests format repair; a fixed-prefix typed-record example allows model choice of an unbound field while preserving an already bound identifier. These controlled examples do not establish a broad framework's advantage. On a pure closure task, the strongest comparator is deterministic repair using the same compiler and validator. General structured contracts still require a compiler and new task evaluation; neither is supplied by a manually listed completion set.

## 2. Proposed budget-viable commitment decoder

### 2.1. Contracts, binding and transactional output

Let $\mathcal C$ be a declared consumer contract, with a sound final validator $V_{\mathcal C}$ and extractor $g$. A draft is provisional and must not be published as accepted output. At a binding event, selected fields $b$ are fixed. Let $\mathcal L_{\mathcal C,b}$ denote accepted completions preserving those fields. Binding certifies neither their factual truth nor the correctness of the unbound fields.

The protocol has five observable states: DRAFT, BIND, REPAIR, COMMIT and ABSTAIN. DRAFT uses the base decoder. BIND compiles or queries a completion controller for the observed prefix and bound fields. REPAIR applies the mask defined below. COMMIT returns a certified artifact. ABSTAIN returns no accepted answer while retaining the generated trace and full cost for analysis. Already accepted drafts can go directly to COMMIT. Unsupported syntax, invalid natural EOS, a missed drafting deadline and an infeasible repair all remain visible as failures or abstentions.

The prototype uses a checkpoint to identify where repair starts, not KV-cache rollback. It does not discard and regenerate model work or claim an efficient speculative implementation. A broader transactional decoder could support rollback, but doing so would require additional semantics, cost accounting and experiments.

### 2.2. Token-level budget viability

Let $s$ be the state of a completion controller for the current token prefix, including any bound-field constraints. Let $\delta(s,v)$ be a partial transition on vocabulary token $v$, with undefined transitions forbidden. Its accepting set $F$ must be a subset of outputs certified by $V_{\mathcal C}$ and preserving $b$. Distances must be defined in **model tokens**, not characters or bytes. Here exactness is relative to the declared controller language. A finite trie containing selected tokenizations need not contain every token sequence accepted by the consumer contract, so its shortest path is not necessarily globally shortest among all valid outputs. EOS is legal only at an accepting state, or acceptance may trigger a return action without appending EOS.

Define the minimum token distance to acceptance:

$$d(s)=\min\{|z|:\delta^*(s,z)\in F\},$$

where an empty set gives infinity and $d(s)=0$ for accepting states. For $r>0$ remaining output tokens, retain

$$\mathcal A_r(s)=\{v:\delta(s,v)\text{ is defined and }d(\delta(s,v))\leq r-1\}.$$

If $s\in F$, the protocol commits immediately. Otherwise the next-token distribution is

$$q_r(v\mid y,s)=\frac{p_\theta(v\mid y)\mathbf 1\{v\in\mathcal A_r(s)\}}{\sum_u p_\theta(u\mid y)\mathbf 1\{u\in\mathcal A_r(s)\}}.$$

Greedy decoding uses the largest permitted score. This is a local constrained distribution, not a claim of sampling exactly from a globally conditioned model. The normalizer must be positive; the implementation fails closed on unsupported or non-finite scores.

### 2.3. Conditional guarantees

**Proposition 1 — nonempty viable support.** If $s\notin F$, $d(s)\leq r$, and $d$ is exact, then $\mathcal A_r(s)$ is nonempty.

**Proof.** A shortest accepting token path has positive length at most $r$. Its first token leads to a state with remaining distance at most $r-1$, and is therefore allowed.

**Proposition 2 — completion within the repair budget.** Suppose REPAIR starts at $s_0$ with $d(s_0)\leq r_0$, the transition and distance oracle is exact, at least one allowed token has positive model probability at every step, and only tokens in $\mathcal A_r$ are emitted. Then immediate commitment at $F$ occurs in at most $r_0$ new tokens.

**Proof.** Each emitted token decrements $r$ and preserves $d(s)\leq r$. Non-emptiness gives another allowed step while $s\notin F$. At $r=0$, the invariant implies $d(s)=0$, hence $s\in F$. Neither premature EOS nor a forbidden token can interrupt this induction because they are excluded from the viable support.

**Proposition 3 — certified commit and bound-field preservation.** If accepting controller states satisfy $V_{\mathcal C}$ and preserve $b$, every committed repair satisfies the same postconditions. The prototype also rechecks these conditions against the final decoded text. This is a syntactic and binding guarantee, not a truth or answer-correctness guarantee.

These results are conditional on entering REPAIR with a viable state. They do not guarantee that free drafting produces a candidate, that a tokenizer realizes the desired completion, that a compiler supports an arbitrary grammar, or that every request commits. Those outcomes must be reported as coverage and failure categories. A distance lower bound is insufficient for Proposition 2: underestimating the true distance may admit an impossible deadline. A conservative realizable completion bound can support a different sufficient invariant, but needs its own implementation and proof.

### 2.4. Reference algorithm and implemented scope

1. Draft with the unmodified model up to an explicit drafting deadline, accounting for all generated tokens.
2. If the current artifact already satisfies the target contract, commit it.
3. Otherwise, bind a locally complete candidate or declared subset of fields and construct a verified completion language. Reject unsupported or context-incompatible token paths.
4. Enter REPAIR only if its minimum token distance fits the remaining budget; otherwise abstain.
5. Mask to $\mathcal A_r$, generate a token, update controller state and budget, and repeat until acceptance.
6. Revalidate the final artifact and bound fields before committing. Retain all costs for abstentions and failures.

The implementation supplied with this draft has two limited interfaces. The draft-to-repair interface recognizes a complete marked numeric or choice candidate and proposes common wrapper-closing suffixes under the closure-balanced reference heuristic. The fixed-prefix interface accepts a finite set of structured completions plus independent acceptance and binding predicates; a JSON-record test preserves an identifier while the model selects an unbound label. Each completion is tokenized and checked in the actual decoded-prefix context. A trie provides exact minimum suffix lengths. These interfaces are not a general context-free-grammar compiler, a JSON Schema engine or a tokenizer-independent incremental parser. The fixed-prefix test does not include the cost or quality of generating its supplied prefix. Both interfaces are append-only: they preserve the already emitted prefix and cannot selectively revise earlier unbound text. Preserving declared fields in these tests is not evidence of a general field-level editing or rollback capability.

The controller and grammar need not be new inventions individually. The research hypothesis concerns whether selective binding, budget viability and explicit commitment are useful together. The present prototype establishes a testable instance, not that the hypothesis is true.

### 2.5. A necessary deterministic-repair reduction

**Proposition 4 — format-only special case.** If every accepted repair preserves the same complete task answer and differs only in formatting, and a verified completion compiler is available, deterministic shortest repair can achieve the same contract acceptance and bound answer with no additional model calls. Its inserted suffix has no more tokens than any completion in that compiled language.

**Proof.** Choose a shortest path from the same controller state to $F$ and serialize it. Acceptance and field preservation follow from the same compiler certificate. By the definition of $d$, its length is minimal. No probability-model query is required to choose this path.

This reduction is important for the current numeric/choice setting. It prevents attributing a formatting improvement to a new probabilistic decoding capability. The model-scored controller must be compared with this baseline. It could be motivated on richer completions whose unbound fields have task-dependent quality, but that extension needs a compiler, metrics and data absent here. No performance superiority follows from the framework's name or proofs. In particular, the shortest structurally valid path can contain a wrong answer; a budget mask can exclude a longer correct completion while retaining a shorter incorrect one. Structural coverage and correct-commit yield can therefore move in opposite directions.

### 2.6. Equivalence and inactive-mask cases

For the same state, transition language, distance oracle, remaining budget, scores and tie-breaking, a grammar engine applying the same distance filter produces the same permitted support as this controller. If all grammar-legal outgoing tokens already satisfy the distance bound, the budget filter is inactive. Until the first differing support or return decision, matched greedy decoders have no mechanism for producing different token choices. Different tokenizer paths, prompts, binding points or validators break this equivalence and cannot be attributed solely to budget viability.

This observation defines two required controls: an equivalent budget-aware grammar implementation, and an inactive-mask condition in which the proposed filter should make no additional intervention. The present distance invariant alone does not establish a new algorithm relative to an implementation of the same recurrence.

### 2.7. Cost and selective-output accounting

Record actual model-generated tokens, inserted deterministic tokens, returned tokens, forward calls, compiler/validator time and total request latency separately. An abstention is not a successful answer; report correct committed answers divided by **all** requests, commitment coverage, conditional correctness among committed outputs, invalid-commit rate and failure reasons. Conditional accuracy alone can be improved by abstaining on difficult cases and is not sufficient evidence of quality.

The prototype includes a forward-call counter and retains generated text for failed requests, but it is not optimized or validated as a latency benchmark. It scans decoded prefixes and compiles suffixes on the host. Historical callback overhead cannot be transferred to this decoder, and previously observed shared-prefix identities need not hold after a new mask changes generation.

## 3. Preliminary evidence and implementation checks

### 3.1. Historical motivation, with a different contract

The historical experiments evaluated stopping and monitoring, not the controller in Section 2. They used two models, Qwen2.5-7B-Instruct-1M and Mistral-7B-Instruct-v0.3, and two tasks, GSM8K and ARC-Challenge. The main cohort contained 600 questions per task, reused across models. Uniform ran to EOS or a 512-token cap; Complete returned the earliest certified terminal answer line. The complete 25,200-call initial protocol and the later 11,200 scored timing calls are described in historical Supplement A. Calls, model repetitions and sessions are not independent question samples.

The frozen primary contract required a terminal line-start `####` value with a newline or EOS certificate and no later non-whitespace text. It did not validate the surrounding document. This differs from the closure-balanced reference heuristic used in the repair prototype and from any future structured-record contract. Historical contract scores must not be carried across those changes as if they measured one endpoint.

Table 1. Historical Uniform-to-Complete validity transitions under the frozen terminal-line contract. Each row has 600 paired questions. These counts do not evaluate constrained repair.

| Model / task | Invalid to valid | Correct repairs | Wrong repairs |
| --- | ---: | ---: | ---: |
| Qwen / GSM8K | 28 | 14 | 14 |
| Qwen / ARC-C | 0 | 0 | 0 |
| Mistral / GSM8K | 129 | 81 | 48 |
| Mistral / ARC-C | 47 | 19 | 28 |

There were 204 validity repairs, including 114 correct and 90 wrong answers, across 2,400 model-question pairs. There were no observed validity losses, and the shortened-output set exactly equaled the validity-repair set. These are paired descriptive findings on reused questions, not independent pooled trials. They motivate separating validity from truth; they do not prove that a decoder changing token support preserves correctness.

Contract sensitivity is material: under last-marked-answer extraction, the Complete-minus-Uniform accuracy difference was zero in all four cells; under the closure-balanced heuristic it was negative for Qwen/GSM8K. Complete is therefore not uniformly preferable under a changed consumer interface. Historical Supplement B retains all alternative-contract results and unfavorable outcomes.

Historical output-matched timing also motivates measuring controller cost. The isolated Shadow-minus-Complete monitoring overhead was 16.46–51.18 ms across the four cells. Complete was not universally faster than Uniform. The later concurrent timing used different measurement boundaries and is not pooled with the isolated run. Its preserved summaries lack the per-call raw follow-up timing archive needed to reconstruct the reported intervals independently. None of these measurements estimates the latency of the new controller.

### 3.2. Controlled prototype verification

The reference controller passed 14 controlled CPU tests, including real Transformers generate calls with a small random GPT2 and scripted logits. Checks cover finite-trie distance pruning, the budget invariant, wrapper closure, candidate-value preservation, invalid EOS, unsupported syntax, tokenizer-context mismatch, explicit deadline abstention and deterministic repair. Fixed-prefix JSON examples verify preservation of an identifier while a model chooses an unbound label, and exclusion of a candidate that changes that identifier. A wrong complete answer can still commit, as expected from the absence of a semantic guarantee.

These are software checks, not pretrained-model task results, general-schema validation, GPU timing or evidence of improved accuracy. The examples use finite supplied completion languages. No experiment in this draft has yet measured task-level benefits of the budget mask or general end-to-end binding coverage.

## 4. Prospective evaluation design: not yet executed

### 4.1. Claims and evaluation units

The proposed evaluation separates three claims: conditional mechanism compliance after a viable binding point; improvement in valid and correct committed outputs at a fixed total budget; and acceptable total cost relative to strong alternatives. Only the first currently has controlled implementation checks. A claim about the latter two requires fresh model runs, an implemented compiler for the declared task language and an auditable request-level archive.

Use two tracks. A matched-prefix track gives relevant repair methods exactly the same prefix, bound fields, grammar and remaining budget. It isolates suffix control, excluding prefix-generation cost from that measurement explicitly. An end-to-end track begins at the user prompt and includes drafting, binding failures, compilation, repair, verification and abstention. Supplied prefixes in the first track cannot substantiate end-to-end latency or coverage claims in the second.

The historical cohorts are known data and may be reused for a declared matched re-evaluation, not presented as unseen holdouts. Freeze sample IDs, task contracts, primary contrasts, binding and reserve rules, model revisions and compiler capabilities before final evaluation. If new tasks or splits are unavailable, limit the generalization claim accordingly.

### 4.2. Task families and meaningful completion choices

First, retain a format-only numerical or choice task as a deliberate reduction control. Bind an already complete answer and allow only verified formatting closure. Proposition 4 predicts no inherent answer-quality advantage over deterministic shortest repair on the same compiled language. This task checks honest accounting rather than demonstrating a new semantic capability.

Second, evaluate structured question answering with task-relevant fields still unbound at activation. For example, bind a public instance identifier and require a typed answer field and valid JSON closure. ARC alternatives may be derived from all visible choices, without the gold label. A numeric task needs an explicitly bounded numeric grammar or another declared answer language independent of gold values; manually inserting the reference answer into a completion list is invalid. Score the unbound answer against the reference only after generation. The current wrapper interface cannot run this general evaluation; its compiler and runner still need implementation.

Use more than one task structure or clearly limit the claim to the selected domain. Prefer both categorical and numeric structured-answer settings for a broad claim. A label-only trie whose branches all fit every tested budget provides little evidence for budget pruning. Include controlled mixed-length accepting branches, ordinary inactive-mask cases and infeasible cases. Synthetic branch tests establish mechanism behavior, not broad task usefulness.

Variable-length answer encodings can favor short answers under a tight budget. Include a canonical short-label control and report answer-length strata, binding errors and whether the reference answer remains reachable in the declared language. Reference-reachability diagnostics are computed offline and must never guide inference, budget selection or exclusion of final requests. A structurally viable wrong answer is not a successful task result.

### 4.3. Baselines, attribution and equivalence

For a matched-prefix comparison, include deterministic shortest completion, grammar-only model-scored continuation, the full budget mask and an independent grammar implementation of the same budget recurrence. They must share the prefix, accepted token language, bound fields, remaining budget, return certificate and applicable score settings. The equivalent recurrence is a consistency and competitiveness control; better output is not expected merely from renaming it. For finite answer languages, also consider candidate-sequence likelihood scoring and a development-frozen prior-based deterministic choice, so a weak arbitrary-label baseline does not overstate the need for autoregressive repair.

For end-to-end comparison, include Uniform/EOS-or-cap, native stopping when it can enforce the declared contract, deterministic repair, selective grammar-only repair, the full controller and a practical grammar-constrained decoder active from the start. Use the same user-visible task, prompt content, total output cap and final validator. A native string stop that cannot enforce the target contract is an additional diagnostic, not the sole competitive baseline. From-start grammar and selective activation have different interventions, so their difference is a system comparison, not an isolated estimate of the budget mask.

Run legacy Complete with its historical terminal contract only as a historical diagnostic. If an early-return comparator enters the primary new-contract table, implement return on acceptance under that same new contract and name it separately. Scoring old Complete against its old contract while scoring the new controller against a richer contract is not a valid primary comparison.

Ablate budget pruning at the same binding point. Separately compare selective versus from-start constraints and binding rules that freeze a complete answer versus only public structural fields. Since the append-only prototype cannot edit earlier text, an ablation requiring field-level revision first needs a new implementation. Removing the final certificate is a controlled fault test, not a suitable main baseline presented as intentionally invalid competition.

### 4.4. Budgets, quality endpoints and failures

Choose several total token caps spanning tight, intermediate and relaxed regimes using development information, then freeze them. The old single cap512 cannot establish a budget-response curve. At a shared prefix, test repair budgets below, equal to and above the exact compiled minimum distance, as well as branches with unequal accepting lengths. Near-deadline examples should test whether pruning improves completion while changing or reducing answer quality. Report the rate of states at which the mask actually removes a grammar-legal token.

The primary endpoint is correct committed answers divided by all frozen eligible requests. Report commitment coverage, correct answers conditional on commitment, invalid commits, binding violations, budget overruns and failure categories alongside it. Unsupported compilation, context mismatch, no candidate, infeasible distance, invalid EOS and runtime errors remain in the denominator. Runtime errors and infrastructure failures need distinct labels and a prespecified rerun rule; they must not silently disappear. Supported-language and gold-reachable strata are secondary diagnostics, not replacements for all-request results.

Report all generated tokens, deterministic insertions, returned tokens and model forward calls separately. Include compiler, mask, validator and failed-request time in the total request measure. No rollback savings can be claimed by the current append-only implementation. If a later implementation retries or discards work, its costs remain included.

### 4.5. Runtime and statistical analysis

Benchmark trained models under matched precision, attention backend, batch size, sampling configuration and hardware. Preserve the two existing model families for continuity, without implying they represent all LLMs. Use isolated synchronized latency measurements, randomize or balance policy order within sessions, preserve worker and device IDs, and record cold compilation separately from any declared amortized cache regime. Report mean and P50/P95 request latency and paired uncertainty; higher concurrency or throughput claims require a distinct load experiment. Do not transfer historical callback times to this controller.

Choose a practically meaningful primary difference and sample size from development or pilot estimates of paired discordance and timing variability. No fixed call count here is claimed to guarantee power. Pair by question within model, task and budget, and resample question IDs across policies and repeated sessions. If several budgets and model/task cells support confirmatory claims, prespecify one primary setting or a multiplicity adjustment. Report intervals and unfavorable cells rather than only successful budgets. Repeated calls, fixed-prefix variants and the same question answered by multiple models are not independent new questions.

Preserve per-request token IDs, accepted text, status, errors, distances, mask activations, binding events, hashes and complete timing boundaries. Gold labels belong only in a separate scoring step. Raw records, frozen manifests and analysis code are necessary to reproduce task and timing conclusions; software test counts alone are insufficient.

### 4.6. Decision criteria for the proposed contribution

If gains occur only on formatting closures, position the result as verified repair or interface control. If the full method matches an equivalent grammar-plus-distance implementation, claim no distinct recurrence. If pruning improves valid completion but harms correct-commit yield, report that trade-off and do not call it reasoning improvement. If meaningful unbound-field tasks show a reproducible benefit over strong alternatives at acceptable full cost, that would support a useful method contribution, subject to literature comparison. Novelty and SCI acceptance cannot be guaranteed by these experiments or by terminology.

The next manuscript revision should replace this prospective section with the actual frozen protocol and new results, while keeping unsuccessful comparisons and historical provenance available. No placeholder result in this section should be read as an observation.

## 5. Discussion and validation requirements

### 5.1. What has changed in the proposed method

The proposal changes token support during REPAIR, rather than merely returning an earlier unmodified prefix. It also gates submission on final acceptance and preserves declared bound fields. These are real implementation changes. They invalidate an argument that old early-stop data already demonstrate the proposal's behavior. The historical results are motivation and comparator evidence only.

Budget viability provides a conditional deadline property beyond grammar-prefix legality, but standard constrained search can implement the same distance condition. This may be a useful controller design without constituting a new paradigm. The novelty question must be resolved against prior budget-aware constrained generation, constrained editing and verified-output systems, not against Marker alone.

### 5.2. Why the current prototype is insufficient as an algorithm contribution

In the implemented format-only repair language, all accepted paths preserve the complete candidate answer. The deterministic reduction in Proposition 4 is therefore directly applicable. A new model call that chooses between formatting-equivalent suffixes has no demonstrated answer-quality benefit. The supplied comparator prevents this easy baseline from being omitted.

For a broader contribution, meaningful alternatives could include partially filled typed records or bounded structured completions with unbound task-relevant fields. The controlled fixed-prefix JSON test shows the required distinction at the mechanism level, but its suffixes are manually listed and it has no task-accuracy or runtime benchmark. A scalable compiler, task-dependent quality criteria and independent data are still required. Simply calling these finite examples a new paradigm would overstate their capabilities.

### 5.3. From mechanism to evidence

Section 4 specifies the comparisons needed to connect the proposed mechanism to task usefulness. Historical Supplement A–B documents the earlier stopping studies, which remain valid evidence for their own contracts and implementations. Moving those tables out of the main text changes emphasis, not evidence or reporting obligations. Neither additional terminology nor more repeats of an unrelated policy can fill the missing new-method evaluation.

### 5.4. Current evidence limits

The two-model, two-task stopping experiments establish interface sensitivity and implementation-path cost, not the effectiveness of constrained repair. The three-GPU summary package lacks the new per-call raw timing archive, so the present revision still cannot independently reconstruct those intervals. The prototype uses a finite completion trie and a limited wrapper heuristic, not a general document grammar. Computational contract outcomes do not estimate semantic quality, and a frozen wrong candidate can remain wrong after perfect structural repair.

The proofs require exact token-level transitions, reachable accepting states and suitable model support. Character-level distances, unverified tokenizer concatenation, optimistic distance estimates and hidden failure filtering invalidate the guarantees or their empirical interpretation. All generated and inserted tokens and all failed-call costs must remain visible.

## 6. Conclusions

Budget-viable commitment is a proposed extension from stopping-only control to constrained completion and certified submission. Under explicit controller, tokenization, distance and scoring assumptions, it supports budget-bounded completion after entry into a viable repair state while preserving bound fields. It does not guarantee that drafting reaches such a state, that the bound answer is true or that the method is faster. A working finite-language prototype and a deterministic-repair comparator make the proposal testable. Historical experiments motivate its design, but new task-level comparisons are necessary before making performance or new-paradigm claims. The format-only reduction is a substantive limitation that the next experiment must resolve rather than conceal.

## Data and code availability

The revision includes the experimental controller, reference contract, deterministic-repair baseline and controlled CPU tests. These are new research artifacts, not a certified general grammar engine or a production GPU implementation. Historical manuscript and experiment archives remain unchanged. The historical supplement preserves all ten prior numerical tables, their executed protocols and limitations. The bundled historical_evidence directory retains transition-analysis code, inputs and source provenance. The original full raw experiment archive remains a separate prerequisite for rerunning that analysis. Complete raw follow-up timing and a portable end-to-end experiment archive remain necessary for independent statistical reproduction. No new trained-model or CUDA performance result is claimed.

## Declarations requiring author confirmation

**Funding.** Pending confirmation of actual support, grant identifiers and funders' roles. Absence of funding is not assumed.

**Competing interests.** Pending author confirmation, including employment and support relevant to this work. The supplied affiliation is retained and is not a verified disclosure.

**Author contributions.** Pending a factual account of contributions and final approval. Supplied author order and correspondence details are retained for confirmation.

**AI-assisted work.** AI assistance was used in manuscript revision, code inspection and modification, experiment operation, computational analysis and document preparation. Authors must verify the precise account against actual use and current journal disclosure fields. All reported evaluation endpoints are computational; no annotator-based result is claimed. Human authors remain responsible for methods, data, interpretations and final text.

## References

Clark P, Cowhey I, Etzioni O, Khot T, Sabharwal A, Schoenick C, Tafjord O. 2018. Think you have solved question answering? Try ARC, the AI2 Reasoning Challenge. arXiv:1803.05457. <https://arxiv.org/abs/1803.05457>

Cobbe K, Kosaraju V, Bavarian M, Chen M, Jun H, Kaiser L, Plappert M, Tworek J, Hilton J, Nakano R, Hesse C, Schulman J. 2021. Training verifiers to solve math word problems. arXiv:2110.14168. <https://arxiv.org/abs/2110.14168>

Han T, Wang Z, Fang C, Zhao S, Ma S, Chen Z. 2025. Token-budget-aware LLM reasoning. Findings of the Association for Computational Linguistics: ACL 2025, 24842-24855. DOI: 10.18653/v1/2025.findings-acl.1274. <https://aclanthology.org/2025.findings-acl.1274/>

Mistral AI. 2024. Mistral-7B-Instruct-v0.3 model card. <https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3>

Muennighoff N, Yang Z, Shi W, Li XL, Fei-Fei L, Hajishirzi H, Zettlemoyer L, Liang P, Candes E, Hashimoto T. 2025. s1: Simple test-time scaling. arXiv:2501.19393, version 3. <https://arxiv.org/abs/2501.19393v3>

Wang J, Jain S, Zhang D, Ray B, Kumar V, Athiwaratkun B. 2024. Reasoning in token economies: Budget-aware evaluation of LLM reasoning strategies. Proceedings of EMNLP 2024, 19916-19939. DOI: 10.18653/v1/2024.emnlp-main.1112. <https://aclanthology.org/2024.emnlp-main.1112/>

Yang A, Yu B, Li C, Liu D, Huang F, Huang H, Jiang J, Tu J, Zhang J, Zhou J, Lin J, et al. 2025. Qwen2.5-1M technical report. arXiv:2501.15383. <https://arxiv.org/abs/2501.15383>

Yu Q, Zheng Z, Song S, Li Z, Xiong F, Tang B, Chen D. 2025. xFinder: Large language models as automated evaluators for reliable evaluation. ICLR 2025; arXiv:2405.11874, version 3. <https://arxiv.org/abs/2405.11874>

XGrammar project. 2026. Official project documentation, README, commit `e085851aec8f417924be5f460d1e038cac0e3bd5`. <https://github.com/mlc-ai/xgrammar/blob/e085851aec8f417924be5f460d1e038cac0e3bd5/README.md> (accessed 26 October 2026).

Outlines project. 2026. Official project documentation, README, commit `c52af8472c6fe8a607a733ec11b709476af77a96`. <https://github.com/dottxt-ai/outlines/blob/c52af8472c6fe8a607a733ec11b709476af77a96/README.md> (accessed 26 October 2026).

Hokamp C, Liu Q. 2017. Lexically Constrained Decoding for Sequence Generation Using Grid Beam Search. Proceedings of ACL 2017 (Volume 1: Long Papers), 1535–1546. DOI: 10.18653/v1/P17-1141. <https://aclanthology.org/P17-1141/>.

Geng S, Josifoski M, Peyrard M, West R. 2023. Grammar-Constrained Decoding for Structured NLP Tasks without Finetuning. Proceedings of EMNLP 2023, 10932–10952. DOI: 10.18653/v1/2023.emnlp-main.674. <https://aclanthology.org/2023.emnlp-main.674/>.

Hugging Face. 2025. Transformers v4.48.2: generation stopping criteria, including StopStringCriteria. Versioned implementation documentation. <https://github.com/huggingface/transformers/blob/v4.48.2/src/transformers/generation/stopping_criteria.py> (accessed 26 October 2026).
