"""Fixed-prefix structured completion with immutable selected fields.

The caller supplies a finite completion language and independent acceptance and
binding checks. This is not a schema-to-grammar compiler. The prefix is supplied,
so no cost or quality claim about generating that prefix follows from this API.
"""
import torch
from transformers import GenerationConfig,LogitsProcessorList,StoppingCriteriaList
from .controller import RepairTrie,ConstraintFailure
from .hf_adapter import ViabilityMask,CommitStop


class FiniteRecordController:
    def __init__(self,tokenizer,prefix_ids,suffixes,budget,eos_ids,accept,preserve):
        if budget<1:raise ValueError('Positive completion budget required')
        self.tokenizer,self.prefix_ids=tokenizer,list(prefix_ids)
        self.checkpoint=len(prefix_ids);self.cap=self.checkpoint+budget
        self.accept,self.preserve=accept,preserve
        self.mode='REPAIR';self.last_ids=list(prefix_ids)
        prefix=self.text(prefix_ids);paths=[]
        for suffix in suffixes:
            ids=tokenizer.encode(suffix,add_special_tokens=False)
            text=self.text(prefix_ids+ids)
            if ids and not set(ids)&set(eos_ids) and text==prefix+suffix and accept(text) and preserve(text):paths.append(ids)
        self.trie=RepairTrie(paths)
        if self.trie.root.distance>budget:self.mode='ABSTAIN'

    def text(self,ids):return self.tokenizer.decode(ids,skip_special_tokens=True,clean_up_tokenization_spaces=False)

    def allowed_tokens(self,ids):
        self.last_ids=list(ids)
        if ids[:self.checkpoint]!=self.prefix_ids:raise ConstraintFailure('bound prefix changed')
        allowed=self.trie.allowed(ids[self.checkpoint:],self.cap-len(ids))
        if not allowed:raise ConstraintFailure('no budget-viable completion')
        return allowed

    def observe(self,ids):
        self.last_ids=list(ids)
        if self.trie.state(ids[self.checkpoint:]).accepting:
            text=self.text(ids)
            if not self.accept(text) or not self.preserve(text):raise ConstraintFailure('final record certificate failed')
            self.mode='COMMIT';return True
        return False


@torch.inference_mode()
def complete_finite_record(model,tokenizer,prompt,prefix,suffixes,budget,accept,preserve,device='cpu'):
    prompt_ids=tokenizer.encode(prompt,add_special_tokens=False)
    prefix_ids=tokenizer.encode(prefix,add_special_tokens=False)
    if tokenizer.decode(prompt_ids+prefix_ids,skip_special_tokens=True,clean_up_tokenization_spaces=False)!=prompt+prefix:
        raise ConstraintFailure('prompt-prefix tokenizer context mismatch')
    eos=model.generation_config.eos_token_id;eos=[eos] if isinstance(eos,int) else list(eos or [])
    c=FiniteRecordController(tokenizer,prefix_ids,suffixes,budget,eos,accept,preserve)
    if c.mode=='ABSTAIN':return dict(status='ABSTAIN',committed_text=None,actual_generated_tokens=0)
    inputs=torch.tensor([prompt_ids+prefix_ids],device=device)
    out=model.generate(input_ids=inputs,attention_mask=torch.ones_like(inputs),
        generation_config=GenerationConfig(max_new_tokens=budget,do_sample=False,num_beams=1,use_cache=True,
            eos_token_id=eos,pad_token_id=eos[0],forced_eos_token_id=None),
        logits_processor=LogitsProcessorList([ViabilityMask(c,len(prompt_ids))]),
        stopping_criteria=StoppingCriteriaList([CommitStop(c,len(prompt_ids))]))
    generated=out[0,len(prompt_ids)+len(prefix_ids):].tolist()
    return dict(status=c.mode,committed_text=c.text(prefix_ids+generated) if c.mode=='COMMIT' else None,
        actual_generated_tokens=len(generated),provided_prefix_tokens=len(prefix_ids),
        generated_ids=generated,prototype=True)
