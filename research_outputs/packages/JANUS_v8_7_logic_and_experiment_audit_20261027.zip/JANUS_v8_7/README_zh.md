# v8.7 主线与实验设计复核版

2026-10-27。候选方法研究稿，尚无新方法真实模型主实验；不是可保证SCI录用或新范式优先权的终稿。

本轮重排正文，明确精确距离的语言范围、append-only实现、等价grammar对照、预算与正确率冲突。十张旧表原样移入独立历史补充材料，正文只保留一张动机表。没有删除旧原始数据、不利结果或合同敏感性结果。

入口：

- manuscript.md / main.tex / main.pdf：主稿，Markdown为编辑源。
- historical_supplement.md / historical_supplement.tex / historical_supplement.pdf：旧完整协议及十张历史表，S1–S10。
- 逐项核查与旧实验取舍_zh.md：本次判断、逐项修改和旧实验保留安排。
- 实验验证方案_zh.md：新机制任务、两条运行轨道、强基线、预算/消融/统计/日志规格。
- prototype/、tests/、TEST_REPORT.json：沿用v8.6原型及已有14项CPU软件检查记录，算法代码未变。
- historical_evidence/：历史回顾性分析、数据来源及摘要。完整旧raw JSONL需另取原实验档案。
- revision_checks.json / SHA256SUMS：文档一致性、表体完整性、派生PDF构建及文件校验。

## 当前未完成的工作

一般结构任务的无gold编译器、同合同全基线runner、正式模型/GPU验证和新逐请求原始档案尚待完成。实验规格是后续开发依据，不代表现有prototype已支持全部实验。finite_record接口的手工后缀例子不能充当通用JSON/数值grammar。

不新增人工评审工作流；有明确参考答案的任务使用自动评分。

## 构建与代码检查

需要Pandoc和pdfLaTeX：`python build.py`构建主稿与历史补充PDF。此命令不运行模型。

原型检查方法与v8.6相同：在安装torch及requirements-prototype.txt后运行`python -m unittest discover -s tests -v`。已有14项通过记录只说明软件行为，不说明任务收益或GPU速度。本轮不修改算法，也不将文档修改说成新增实验。
