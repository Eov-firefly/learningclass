# Budget-viable commitment for finite-language LLM completion

Ya Bai, GuoZhen Bian\*, Cheng Chang, ZhengGuang Cui, HaiLong Qin, ZhiHui Huang, Yue Wang

China Telecom Cloud Network Operating System R&D Center, Beijing, China

\* Correspondence: biangz@chinatelecom.cn

Revision 2 November 2026. Raw-audited research draft. The two studies reuse a known cohort; independent evaluation, priority assessment and final author declarations remain outstanding.

## Abstract

Grammar legality does not ensure acceptance before an output token budget expires. We study budget-viable commitment for append-only completion over a declared finite token language. The controller preserves bound fields, removes tokens without a budget-feasible accepting continuation, and returns a validated artifact or abstention. Backward reachability yields conditional completion. With matched greedy scores and tie-breaking, every grammar-only trajectory already accepting within budget is preserved exactly. Neither property guarantees a correct answer. We audit two models on 96 known ARC-Challenge questions and a subsequent 64-question subset. At the original 24-token setting, pruning was inactive and correct-commit counts were unchanged. In the exploratory eight-token subset, full versus grammar-only completion among initially feasible requests was 57/57 versus 44/57 for Qwen and 45/45 versus 37/45 for Mistral. All successful grammar trajectories were preserved. However, all 13 additional Qwen completions and seven of eight Mistral completions had over-budget canonical reference paths; correct commitments increased by zero and one. Candidate scoring matched structural coverage, with correct counts differing by one per model. A weaker text-only certificate changes some comparisons, exposing sensitivity to terminal policy. The evidence establishes a declared-language control benefit and encoding-dependent semantic limits, rather than general accuracy or speed superiority. The formulation, preservation analysis and reproducible audit do not establish a new reachability algorithm or independent-task generalization.

Keywords: constrained decoding; finite languages; token budgets; verified completion; abstention

## 1. Introduction

Completing an answer field and delivering an accepted artifact are different events. A numerical answer may be locally complete while a surrounding wrapper remains open. Conversely, a structurally permitted continuation may still need more tokens than a request has available. Returning early, constraining legal prefixes and enforcing a completion deadline address related but distinct problems.

We study **budget-viable commitment** over a declared finite token language. A provisional draft is either accepted directly or used to bind values and compile verified suffixes. During completion, the controller excludes next tokens that leave no accepting path within the remaining budget. A final contract check determines commitment. Unsupported, infeasible and failed attempts remain observable abstentions; their work is not omitted from evaluation.

The current implementation is append-only. It can complete a supported prefix, but cannot undo an earlier answer, edit selected preceding fields or recover a missed binding event through rollback. The proposal therefore concerns a specific completion controller, rather than a general document-repair system. Binding preserves content selected by a rule; it does not establish that content is true.

Our contribution has three parts. First, we give a contract-explicit formulation separating structural acceptance, budget feasibility, bound-field preservation and task correctness. Second, we characterize viable support and prove a conditional successful-trajectory preservation property for matched greedy grammar decoding, alongside a counterexample to semantic guarantees. Third, a reference implementation and a reproducible raw-record audit connect these properties to two-model behavior, strong finite-choice baselines and reference-path reachability. The contribution is a specification and mechanism analysis; the backward-reachability recurrence is established machinery, and algorithmic priority over equivalent controllers is not asserted.

Three questions organize the study. RQ1 asks when budget filtering guarantees acceptance and preserves already successful grammar-only trajectories. RQ2 asks whether it prevents grammar-legal budget dead ends, and at what computational cost. RQ3 asks whether additional structural completions improve correct-commit yield relative to grammar-only, deterministic completion and candidate-sequence scoring. Section 3 gives conditional analyses; Section 6 reports the completed studies and their offline audit. Historical stopping results in Section 5 motivate the distinction between validity and correctness but do not evaluate the new controller.

## 2. Related work and comparison boundary

Lexically constrained decoding and grammar-constrained generation are established approaches (Hokamp and Liu, 2017; Geng et al., 2023). Practical libraries such as XGrammar and Outlines support structured generation (XGrammar project, 2026; Outlines project, 2026), and native Transformers stopping criteria support token-boundary return decisions (Hugging Face, 2025). These capabilities are relevant baselines, rather than evidence that the present controller is distinct.

Budget-aware reasoning addresses how much inference to allocate (Wang et al., 2024; Han et al., 2025; Muennighoff et al., 2025). Our stated budget is the number of additional output tokens before acceptance in a declared controller language. This differs from estimating reasoning sufficiency: the controller can ensure a permitted structural ending without ensuring that the answer is correct.

An implementation with the same token transitions, acceptance set, distance filter and scoring rule can be algorithmically equivalent to ours. Renaming that implementation or adding a submission certificate does not establish a new decoding paradigm. The verified XGrammar documentation also identifies its XGrammar-2 successor as dynamic structured generation; comparison cannot be restricted to old static-grammar examples. The documentation was checked, and Section 6 includes an XGrammar baseline for the declared finite-language study; that experiment is not a comparison with every capability of XGrammar-2, nor a completed full-paper survey.

The experimental distinction is narrower than a comparison with all structured-generation methods. Source inspection of the archived comparators shows that the grammar-only adapter permits trie-legal tokens and relies on the generation cap, whereas the full adapter additionally checks remaining distance before token selection. The XGrammar 0.1.21 adapter constrains a finite set of suffix strings without supplying a remaining-distance bound to its matcher. Candidate-sequence scoring first removes paths exceeding the cap and then maximizes summed teacher-forced log likelihood. Deterministic completion chooses a shortest feasible path without a model query. Thus the last two comparators also achieve structural completion when a canonical path fits; that property is not unique to the full controller.

These are source-level distinctions between the evaluated adapters, not claims that the corresponding libraries cannot express other controls. We do not establish priority over length-constrained search, deadline-aware decoding or equivalent finite-state reachability methods. A general new-paradigm claim would require a separate, comprehensive comparison with that literature. The present evidence instead addresses the conditional behavior and semantic limits of a declared, reproducible refinement.

## 3. Formal controller

### 3.1. Consumer contract, provisional prefix and binding

Let $x$ be the prompt and $y$ the generated output prefix. A declared contract $\mathcal C$ has a final acceptance predicate $V_{\mathcal C}(y)$ and a task extractor $g$. A binding rule identifies values $b$ to preserve. Define $P_b(y)$ as their preservation predicate. Neither $V_{\mathcal C}$ nor $P_b$ is a gold-answer oracle. Correctness, when a reference exists, is evaluated separately through $g$.

At an activation prefix, compilation constructs a token controller with partial transition $\delta(s,v)$ and accepting states $F$. An accepting path must decode to an artifact satisfying both $V_{\mathcal C}$ and $P_b$. This is a soundness requirement for the declared predicates, not a claim to implement all Markdown, LaTeX or JSON semantics. The current wrapper validator is a limited operational heuristic. An independent final call to the predicate rechecks each committed artifact; it is not an independently developed semantic oracle.

The protocol has four persistent states: DRAFT, REPAIR, COMMIT and ABSTAIN. BIND is a transition operation that fixes values and constructs the completion controller, rather than a separately persisted state in the supplied code. Already accepted prefixes commit directly. The current interfaces append tokens to the entire frozen prefix; they do not implement selective rewriting of earlier unbound text.

### 3.2. Budget and token language

Let $B$ be the total allowed number of generated output tokens and let $t$ have already been generated. The repair allowance is $r=B-t$. In a supplied-prefix experiment, the allowance instead refers only to new completion tokens, and the supplied prefix’s cost must be reported separately. Prompt tokens do not count toward this output cap, but their processing time remains part of a declared request measurement.

Each transition consumes one model token. Acceptance triggers an immediate return action without requiring an additional EOS token. EOS is forbidden inside a nonaccepting repair. Any emitted EOS during drafting still counts as a generated token. If a different implementation requires EOS to complete an artifact, that transition and its cost must be included in its controller.

For state $s$, define the distance within the declared controller language:

$$d(s)=\min\{|z|:\delta^*(s,z)\in F\},$$

with $d(s)=\infty$ for unreachable acceptance and $d(s)=0$ at an accepting state. For $s\notin F$ and $r>0$, define

$$\mathcal A_r(s)=\{v:\delta(s,v)\text{ is defined},\ d(\delta(s,v))\le r-1\}.$$

The distance is measured in model tokens, not characters or bytes. Exactness is relative to this controller: a finite suffix list with selected tokenizations can omit other valid strings and other tokenizations of the same string. Its distance is not a global minimum over all artifacts accepted by the consumer.

### 3.3. Model scores and viable support

For positive normalizer $Z$, the locally masked distribution is

$$q_r(v\mid x,y,s)=\frac{p_\theta(v\mid x,y)\mathbf 1\{v\in\mathcal A_r(s)\}}{Z},\qquad Z=\sum_u p_\theta(u\mid x,y)\mathbf 1\{u\in\mathcal A_r(s)\}.$$

The implementation uses greedy selection among permitted finite scores. Negative infinity may represent zero model support; it is harmless if another permitted token has a finite score. An all-negative-infinity support, NaN or positive infinity on permitted entries produces an explicit failure. No assertion is made that local masking samples from the model conditioned on eventual global acceptance.

### 3.4. Reachability characterization and conditional completion

**Proposition 1 — feasible first-token characterization.** For a nonaccepting state and remaining budget $r>0$, a legal token $v$ belongs to $\mathcal A_r(s)$ if and only if some accepting continuation of at most $r$ tokens begins with $v$.

**Proof.** If $v$ is retained, the next state has an accepting suffix of length at most $r-1$, which can follow $v$. Conversely, remove the first token from any accepting path of length at most $r$; its suffix witnesses $d(\delta(s,v))\le r-1$.

Thus $\mathcal A_r$ is maximally permissive with respect to existential structural feasibility in this language. This characterization is ordinary backward reachability; it is not a priority claim. Structural feasibility does not ensure that the retained path has positive model probability or a correct answer.

**Proposition 2 — nonempty support and budget-bounded acceptance.** Suppose repair begins at $s_0$ with $d(s_0)\le r_0$. Assume exact transitions and distances, a permitted token with positive model support at every nonaccepting step, selection restricted to the viable support, and successful execution without an external failure. Then structural acceptance occurs in at most $r_0$ new tokens.

**Proof.** A shortest path from any nonaccepting state with $d(s)\le r$ supplies an allowed first token, so the structural support is nonempty. After any allowed emission, decrementing $r$ preserves $d(s)\le r$. At zero remaining tokens, this inequality implies $d(s)=0$, hence acceptance. The model-support and execution assumptions ensure the process does not abort earlier. Immediate return at acceptance ends the process without another token.

**Proposition 3 — certified output.** If all reachable accepting states decode to artifacts satisfying $V_{\mathcal C}$ and $P_b$, and commitment revalidates those predicates, every committed artifact satisfies them. This is a contract-relative postcondition. It provides no factual or task-correctness guarantee and cannot establish soundness of the validator itself.

The statements are conditional on reaching a viable activation point. They do not guarantee a candidate, supported compilation or successful commitment for every request. An optimistic lower bound on $d$ is insufficient: it can retain a path that misses the deadline. These results also concern a token budget, not a bound on wall-clock latency.

### 3.5. Equivalence, deterministic reduction and a quality counterexample

Under the same state, language, distance oracle, scores, remaining budget, acceptance rule and tie-breaking, another grammar engine applying $\mathcal A_r$ has the same token support and greedy trajectory. If every grammar-legal next token already satisfies the bound, the distance mask is inactive. Such matched cases are consistency controls rather than opportunities for an output-quality advantage.

**Proposition 4 — format-only reduction.** Suppose a viable compiled repair language contains only formatting variants of the same bound complete answer. A deterministic shortest accepting path preserves that answer and satisfies the same contract without a new model call. Its inserted suffix uses no more tokens than any other accepting path in that language.

**Proof.** Select a shortest accepting path of length $d(s)$. The compiler’s postconditions establish acceptance and preservation. Selecting and serializing a path requires no probability-model query.

This reduction applies directly to the wrapper prototype. Deterministic insertions still have CPU and serialization costs, and the common prefix retains its model-generation cost. The result does not compare total latency without measurement, nor does it apply when choosing an unbound field changes task correctness.

A two-branch counterexample shows why structural feasibility cannot replace quality evaluation. Let one accepting path contain token $a$ and encode a wrong answer, while a correct answer requires tokens $b,c$. With one remaining token, the mask can retain the wrong one-token path and exclude the correct two-token path. Commitment remains structurally valid. Binding can likewise exclude a correct answer before repair begins. Therefore neither correct-commit improvement nor noninferiority follows from Propositions 1–3 or from historical zero-loss observations.

### 3.6. Conditional preservation of successful greedy trajectories

Let $G$ be grammar-only greedy completion and $F$ its distance-filtered refinement. Assume identical prompt, initial prefix, bound values, token language, accepting states and budget $R$. At an identical history, both use the same finite model scores and a fixed global tie-break. They return immediately at acceptance, use the same final certificate, and execute without external failure. The only difference is removal by $F$ of grammar-legal tokens with no accepting continuation within the remaining budget.

**Proposition 5 — successful-trajectory preservation.** If $G$ produces a certified trajectory $g_1,\ldots,g_T$ with $T\le R$, then $F$ produces exactly the same tokens and artifact.

**Proof.** Suppose their histories agree through step $j-1$. After $g_j$, the actual suffix $g_{j+1},\ldots,g_T$ is an accepting witness of length $T-j\le R-j$. Hence $g_j$ survives the distance filter. It is the grammar-only maximum under the common score and global tie-break, and remains the maximum after deleting other choices. Induction preserves every choice; both then accept and return the same artifact. The same argument includes an initially accepted prefix with $T=0$.

Let $A_G,A_F$ indicate certified commitments and $Q_G,Q_F$ correct certified commitments on one request. Under these assumptions, $$A_F-A_G=(1-A_G)A_F\ge0,\qquad
Q_F-Q_G=(1-A_G)Q_F\ge0.$$ The identities concern the matched greedy comparator, not an unconditional statistical noninferiority claim or a truth guarantee. Newly certified requests can be wrong, so conditional accuracy and application utility can decrease. The result does not compare candidate scoring, random sampling, different tokenizations or activation/binding rules. Different numeric model scores across devices or kernels also invalidate its premise. This preservation argument is a consequence of exact feasibility filtering and greedy subset selection, not a claim of algorithmic priority.

For a reference label $a^*$, define the offline diagnostic $H_R=\mathbf1\{\exists p\in L(a^*):|p|\le R\}$, where $L(a^*)$ contains declared accepting suffix paths encoding that answer. If $H_R=0$, no certified completion in this language can be correct within $R$, regardless of scoring policy. In our canonical finite-choice language, each visible option has one path. This diagnostic uses reference information only after inference; it is not a controller input or a basis for excluding requests from the main denominator.

## 4. Reference implementation and verification

### 4.1. Operational activation rule

The draft-to-wrapper interface uses a total cap $B$ and a fixed reserve $h$, with $0\le h<B$. After each draft token, it checks the following rules in order:

1.  If the current artifact satisfies the closure-balanced reference predicate, commit it.

2.  If natural EOS has occurred without acceptance, abstain.

3.  If the strict marker predicate identifies a complete candidate, bind that value and propose supported closing suffixes. Verify their decoded context, final acceptance and candidate preservation. Enter repair only when a compiled accepting suffix fits $B-t$; otherwise abstain.

4.  If no candidate was found and $t\ge B-h$, abstain; otherwise continue drafting.

Candidate recognition takes precedence over the no-candidate deadline at the same step, while the total cap still applies. The reserve is a drafting policy, not an oracle guaranteeing a candidate by the deadline. Unsupported candidate states currently abstain immediately rather than continuing to search for a later candidate. This behavior must be held fixed or explicitly ablated in experiments.

The supplied-prefix interface starts directly from a finite language and an acceptance/binding predicate pair. An already accepted prefix commits with zero new tokens and zero model calls, including at zero remaining budget. Other prefixes require a viable nonempty completion. The caller supplies the prefix and suffix language without a gold-answer argument. This API separation alone cannot certify that a caller’s predicates are gold-independent; benchmark construction must be audited separately.

### 4.2. Compilation, complexity and scope

Each proposed suffix is tokenized and decoded after the actual output prefix; paths failing exact context round-trip, final acceptance or preservation are rejected. The verified token paths form a trie. If their total length is $M$, the trie has at most $M+1$ nodes. Building it is $O(M)$; a postorder distance calculation uses $O(N+E)$ time and memory for $N$ nodes and $E$ edges. These bounds exclude tokenization, candidate enumeration and predicate execution. Enumeration may be impractical for a large compositional answer space.

The current implementation traverses the emitted repair prefix when retrieving a trie state and constructs a dense vocabulary mask. At repair step $j$, this adds prefix traversal and outgoing-edge inspection plus $O(|\mathcal V|)$ mask construction, before accounting for the model, decoding or validation. Python callbacks and score checks may synchronize host and device. No near-zero overhead claim follows from the linear distance preprocessing bound.

The implementation is batch-size-one greedy generation with no KV rollback, speculative path, arbitrary JSON Schema compiler or general document grammar. Two interfaces demonstrate wrapper closure and finite structured completion, respectively. The latter allows selection of an unbound field from supplied alternatives, but is not itself a dataset benchmark or a general grammar compiler.

### 4.3. Controlled software checks

The revised code passed 22 controlled CPU tests using PyTorch 2.6 and Transformers 4.48.2 with a small random GPT2 and scripted scores. Checks include finite-trie distance and pruning invariants; candidate and identifier preservation; choice of an unbound label; unsupported syntax and context mismatch; invalid EOS and drafting deadlines; deterministic repair; accepting and nonaccepting zero-budget cases; zero model support and invalid scores; and retention of trace and cost after final-certificate or runtime failure.

The new edge-case checks repair accounting and integration behavior rather than measuring answer quality. Both generation adapters return explicit constraint/runtime failure records when handled, retain available generated tokens and remove their model hooks. Forward counts record entered calls, including calls that raise an error; they do not count only successful returns. A benchmark wrapper must still capture configuration, tokenization, predicate, device and infrastructure exceptions outside these handled paths. These tests establish no pretrained-model accuracy, practical compilation coverage or CUDA speedup.

Four additional offline-audit tests check initial infeasibility versus newly entered dead ends, illegal prefixes, the archived historical scoring contract, and the greedy preservation property over 500 finite-language cases. They are software checks rather than pretrained-model or benchmark results.

## 5. Historical motivation and evidence limits

The historical stopping experiments used Qwen2.5-7B-Instruct-1M (Yang et al., 2025) and Mistral-7B-Instruct-v0.3 (Mistral AI, 2024) on GSM8K (Cobbe et al., 2021) and ARC-Challenge (Clark et al., 2018). There were 600 main questions per task, reused across models. Uniform ran to EOS or a 512-token cap. Complete returned the earliest certified terminal answer line. The full initial 25,200-call protocol and all ten historical table bodies remain in Supplement A–B; the later timing study added 11,200 scored calls and 480 warmups. Repeated calls and sessions are not independent new questions.

The frozen quality contract required a last line-start `####` value with a newline or EOS certificate and no later non-whitespace content. It did not validate the surrounding document. It differs from both the prototype’s closure-balanced heuristic and a future typed-record contract. All paired scores in Table 1 use the frozen historical contract.

Table 1. Historical Uniform-to-Complete validity repairs, not results of constrained completion. Each cell uses 600 paired questions. Counts are model–question outcomes.

| Model / task    | Invalid to valid | Correct repairs | Wrong repairs |
|:----------------|-----------------:|----------------:|--------------:|
| Qwen / GSM8K    |               28 |              14 |            14 |
| Qwen / ARC-C    |                0 |               0 |             0 |
| Mistral / GSM8K |              129 |              81 |            48 |
| Mistral / ARC-C |               47 |              19 |            28 |

Across 2,400 model–question pairs, 204 outputs changed from invalid to valid: 114 then matched the reference and 90 did not. There were no observed validity losses, and the shortened-output set exactly matched the validity-repair set. These are descriptive paired findings on reused questions, not 2,400 independent question identities. They locate savings in contract-breaking continuation, without showing improved reasoning.

The interpretation changes under alternative contracts. Last-marked-answer extraction gave zero Complete-minus-Uniform accuracy difference in all four cells, while the closure-balanced heuristic produced a negative difference for Qwen/GSM8K. These results and all unfavorable outcomes are retained in Supplement B. New comparisons must use the same final contract across policies rather than mixing these endpoints.

Historical isolated Shadow-minus-Complete monitoring overhead ranged from 16.46 to 51.18 ms. Complete was not universally faster than Uniform. Follow-up concurrent timing used different measurement boundaries and is not pooled with the isolated run. The newly supplied archive now includes its 11,200 scored records and 480 warmups. The offline audit reproduces all five archived scoring contracts; no concurrent timing interval is newly claimed here. These measurements motivate complete request accounting but do not measure the new controller’s cost.

## 6. Empirical evaluation and raw-record audit

### 6.1. Study design and data integrity

We conducted a limited known-cohort evaluation using Qwen2.5-7B-Instruct-1M and Mistral-7B-Instruct-v0.3 on two A800 80 GB GPUs. The matched-prefix task used 96 ARC-Challenge evaluation questions and 16 development questions from an already inspected cohort; these are not an independent unseen test set. The answer-label and option-text representations are two encodings of the same questions, not separate tasks. The supplied prefix and finite candidate language were held fixed within matched comparisons. The completion budget counts newly generated suffix tokens and excludes the supplied prefix. The measured request includes per-request language construction, prompt preparation and, when inference occurs, processing the supplied prompt and prefix; it does not include generating the supplied prefix upstream. The comparison covers the declared finite language and wrapper contract, not arbitrary grammars or full document semantics.

The frozen study contains 6,976 records across all tracks and repetitions, including 1,248 deterministic CPU records; this is not a count of independent questions or GPU inference calls. The two-model runs used Python 3.11.12, PyTorch 2.6.0+cu124, CUDA 12.4, Transformers 4.48.2 and XGrammar 0.1.21, with BF16, SDPA, greedy batch-size-one generation and per-request cold caches. Qwen revision and Mistral revision are recorded in the manifests. The follow-up mirror provenance records file hashes matching those manifests; this audit checks the recorded metadata and does not reread absent model weights. Offline checks found the expected complete grid with no duplicate or missing records, inference errors, invalid constrained commits, budget overruns or format-reduction mismatches. These are technical integrity checks, not independent human semantic annotation. The format-only reduction and a limited wrapper end-to-end track were also evaluated. On the wrapper track, the full controller certified 27 of 32 Qwen and 30 of 32 Mistral requests; no legal token was removed in that track. These observations do not isolate a binding or budget-pruning effect.

### 6.2. Primary matched-prefix results

For request $i$, let $D_i$ indicate a returned submission, $A_i=D_i\mathbf1\{V_{\mathcal C}(y_i)\land P_b(y_i)\}$ a certified submission, and $Q_i=A_i\mathbf1\{g(y_i)=g_i^*\}$ a correct certified submission. The canonical controllers accept completed token paths that include a terminal newline. The final text predicate permits trailing whitespace to be omitted; it is therefore weaker than native controller acceptance. A returned prefix can satisfy that text predicate while its controller still abstains. We retain the frozen declared-submission endpoints and separately audit this terminal-policy sensitivity in Section 6.6. The original 96-question study’s primary endpoint is $\sum_iQ_i/n$ at option-text cap24. The subsequent 64-question study separately fixes feasible-subset certified completion at cap8 as its within-study comparison, with all-request $A$ and $Q$ retained as guardrails. Its known-cohort, post-pilot status remains exploratory. These distinct endpoints are not retroactively pooled or relabeled as one preregistered confirmatory primary.

The designated primary family compared the full distance-filtered controller with grammar-only continuation using option-text encoding and a 24-token completion budget. Each model was assessed on the same 96 questions under both policies. The endpoint is correct certified commitments over all eligible questions; a certified output is not necessarily correct. The XGrammar and candidate-sequence-scoring baselines are retained as additional controls, not as interchangeable implementations of the primary comparison. The XGrammar finite-string language can permit tokenization paths that differ from the canonical token trie, so differences from that baseline cannot be attributed to the distance filter alone.

Table 2. Correct certified commitments in the primary matched-prefix setting.

| Model   | Full           | Grammar-only   | Full minus grammar     | Conservative paired 97.5% interval         |
|:--------|:---------------|:---------------|:-----------------------|:-------------------------------------------|
| Qwen    | 76/96 (79.17%) | 76/96 (79.17%) | 0.00 percentage points | $-$<!-- -->5.15 to +5.15 percentage points |
| Mistral | 66/96 (68.75%) | 66/96 (68.75%) | 0.00 percentage points | $-$<!-- -->5.15 to +5.15 percentage points |

There were no paired wins or losses in either cell, and the full controller removed no grammar-legal token in this setting. Thus this comparison checks an inactive-mask case; it does not establish performance when the budget filter changes the legal support. A zero observed difference and these intervals do not establish statistical equivalence. Candidate-sequence scoring produced 74/96 correct certified submissions for Qwen and 65/96 for Mistral. This method scores candidate sequences rather than performing the same autoregressive continuation; its scoring inputs and forward calls must be included when comparing cost.

### 6.3. Exploratory tight-budget and format results

At the 8-token option-text budget, certified coverage under full versus grammar-only was 84/96 versus 69/96 for Qwen and 65/96 versus 53/96 for Mistral. Correct certified submissions were 54/96 for both Qwen policies and 41/96 versus 39/96 for Mistral. In this setting the full filter removed grammar-legal tokens, with 50 and 42 removals respectively. These observations are exploratory: certification and correctness are different endpoints, and the small known cohort and multiple settings do not establish a general or statistically significant quality improvement. Infeasible requests under the full controller were recorded as abstentions, not invalid submissions.

In the finite format-only controls, deterministic shortest completion and the full controller matched the reported acceptance and bound-value checks when completion was feasible; both abstained below the compiled minimum. This is consistent with the reduction in Section 3.5, but does not extend the deterministic result to task-relevant unbound answers.

### 6.4. Single-GPU exploratory controllability study

A subsequent frozen control study ran Qwen and Mistral sequentially on one A800 80 GB GPU using the same recorded model specifications and inference stack. The archived single-GPU adapter launches each original worker with one shard, first Qwen and then Mistral; it changes orchestration rather than the inference policy. Its 64 ARC-Challenge questions were drawn from the already inspected cohort; the study is exploratory and does not supply an independent test set. Across two models, 64 questions, three budget conditions and five policies, it produced 1,920 records. Offline integrity checks found a complete grid, zero inference errors, invalid submissions or budget overruns, and no lost certified or correct commitments in the full-versus-grammar comparisons. The two model runs completed with zero exit codes. These are computational checks, not human semantic annotation.

The prespecified within-study comparison considered the eight-token cap only among requests initially feasible for the shared canonical token language. The full distance-filtered controller and grammar-only continuation shared this language and the same matched inputs. Table 3 also reports correct certified commitments over all 64 eligible requests: certified completion is a structural endpoint and does not imply a correct answer. The seven Qwen and 19 Mistral requests initially infeasible at this cap are excluded from the feasible-subset rate, but remain in the all-request correctness denominator.

Table 3. Eight-token exploratory control: structural completion among initially feasible requests and correct certified commitments among all 64 requests per model.

| Model   | Initially feasible | Full certified / feasible | Grammar certified / feasible | Full correct / all | Grammar correct / all |
|:--------|:-------------------|:--------------------------|:-----------------------------|:-------------------|:----------------------|
| Qwen    | 57/64              | 57/57                     | 44/57                        | 35/64              | 35/64                 |
| Mistral | 45/64              | 45/45                     | 37/45                        | 28/64              | 27/64                 |

The paired full-minus-grammar difference in feasible-subset certified completion was 22.81 percentage points for Qwen (conservative paired 97.5% interval: 2.16 to 39.39 points) and 17.78 points for Mistral (interval: $-$<!-- -->4.42 to 36.02 points). These per-model intervals use the study’s two-cell multiplicity adjustment; the reused known cohort and exploratory status limit inference. On this subset the grammar-only controller entered non-completable paths in 13 Qwen and eight Mistral cases. Successful grammar-only token trajectories were preserved by the full controller: 44/44 for Qwen and 37/37 for Mistral. The additional structural completions were not evidence of a corresponding general accuracy improvement: the all-request correct counts changed by zero and one, respectively. Incorrect certified submissions also increased from nine to 22 for Qwen and from 10 to 17 for Mistral, emphasizing that structural completion is not answer quality.

Two case-dependent boundary controls help interpret the mechanism. At each case’s compiled minimum canonical suffix length, full versus grammar-only certified 64/64 versus 24/64 for Qwen and 64/64 versus 26/64 for Mistral. At a wider cap defined by each case’s maximum canonical suffix length, both policies certified 64/64 for both models. These deliberately constructed caps are not a deployment-budget distribution, and the three conditions reuse the same questions. At the fixed eight-token cap, candidate-sequence scoring certified 57 and 45 requests and yielded 34 and 27 correct submissions for Qwen and Mistral, respectively; XGrammar certified 39 and 37 and yielded 31 and 27 correct submissions. XGrammar may allow tokenizations outside the canonical trie, so its difference cannot be attributed to distance pruning alone. Deterministic shortest completion also certified all initially feasible fixed-eight requests, with nine correct Qwen and 11 correct Mistral submissions; its completion guarantee is therefore another relevant structural comparator. The 1,920 records include 384 deterministic cases without model inference. The instrumentation serves correctness analysis and does not establish isolated latency or speed. Across all three conditions, all 259 grammar-certified model–question–condition trajectories were preserved exactly by the full controller; the count contains repeated questions, not 259 independent instances. At fixed8, the 13 and eight newly entered grammar dead ends were followed by 90 and 52 additional forward calls, respectively. Separately, the seven and 19 initially infeasible requests consumed 56 and 152 grammar calls; the full controller rejected these before model inference. Initial infeasibility is not counted as a newly entered dead end.

### 6.5. Reference reachability, strong baselines and costs

Table 4 partitions the fixed8 requests by the offline reference-path diagnostic from Section 3.6. It does not redefine eligibility or provide gold information to inference. In Qwen, the correct option was canonically reachable in 44/64 requests; full and grammar both certified those 44 and answered 35 correctly. Every one of the 13 structural rescues had an over-budget reference path. In Mistral, the correct option was reachable in 35/64 requests; full certified all 35 with 28 correct, while grammar certified 34 with 27 correct. Seven of its eight structural rescues had over-budget reference paths. The remaining rescue is the one additional correct commitment. These are verified paired transitions, not deductions from aggregate accuracy alone.

Table 4. Reference-path reachability at fixed8. Each completion/correct cell gives certified commitments followed by correct commitments; the two strata sum to all 64 requests per model.

| Model   | Reference fits | $n$ |  Full | Grammar | Sequence score |
|:--------|:---------------|----:|------:|--------:|---------------:|
| Qwen    | Yes            |  44 | 44/35 |   44/35 |          44/34 |
| Qwen    | No             |  20 |  13/0 |     0/0 |           13/0 |
| Mistral | Yes            |  35 | 35/28 |   34/27 |          35/27 |
| Mistral | No             |  29 |  10/0 |     3/0 |           10/0 |

The all-request denominator therefore matters. Raising coverage can replace an unreturned long answer with a certified short wrong answer when truth is unreachable under the chosen encoding and cap. This is a semantic feasibility limit, not evidence that prior successful grammar outputs were damaged. In the original 96-question label-encoding control at cap8, both full and grammar certified 96/96; correct counts were 85 for Qwen and 66 for Mistral, and budget pruning was inactive. The structural contrast is encoding- and budget-dependent, rather than a general property of ARC answer prediction. Different encodings also change model scores and are not an isolated distance-filter ablation.

Table 5 keeps all five fixed8 policies visible. Candidate scoring achieves the same structural coverage as full and differs in correct yield by only one request per model. The paired correct-outcome counts are two full wins and one loss for Qwen, and one win and zero losses for Mistral; the descriptive conservative 95% difference intervals are $[-9.30,12.08]$ and $[-6.60,9.56]$ percentage points. They do not establish a quality advantage. Deterministic completion exposes the low quality of arbitrary shortest-answer selection; model-guided selection improves on that comparator here, but candidate scoring also uses the model.

Table 5. Fixed8 all-request results and computation counts, $n=64$ per row. Fwd counts entered model calls. TF input counts candidate-scoring nonpadding input tokens, including repeated prompt/prefix tokens; zero denotes an inapplicable teacher-forcing metric, not zero autoregressive computation.

| Model   | Policy         | Cert. | Correct | Wrong | Fwd | TF input |
|:--------|:---------------|------:|--------:|------:|----:|---------:|
| Qwen    | Grammar        |    44 |      35 |     9 | 378 |        0 |
| Qwen    | Full           |    57 |      35 |    22 | 310 |        0 |
| Qwen    | XGrammar       |    39 |      31 |     8 | 417 |        0 |
| Qwen    | Sequence score |    57 |      34 |    23 |  57 |    28167 |
| Qwen    | Deterministic  |    57 |       9 |    48 |   0 |        0 |
| Mistral | Grammar        |    37 |      27 |    10 | 427 |        0 |
| Mistral | Full           |    45 |      28 |    17 | 273 |        0 |
| Mistral | XGrammar       |    37 |      27 |    10 | 427 |        0 |
| Mistral | Sequence score |    45 |      27 |    18 |  45 |    20038 |
| Mistral | Deterministic  |    45 |      11 |    34 |   0 |        0 |

Candidate scoring uses batched teacher forcing; its forward count is not a token-compute equivalent to one autoregressive step. Full emits 310/273 new tokens for Qwen/Mistral, while grammar emits 378/427. The deterministic comparator inserts 273/243 tokens, and candidate scoring inserts 308/274 while scoring 934/789 candidate suffix tokens. All these token categories remain separate in the audit tables. Frozen inputs, compilation and failed attempts remain in total request accounting. The single-GPU measurements include correctness instrumentation and are not a dedicated isolated performance benchmark. In particular, no speed superiority over candidate scoring follows from the grammar dead-end savings.

### 6.6. Sensitivity to terminal acceptance policy

The compiled canonical paths and the XGrammar string alternatives include a terminal newline, while the final text checker compares artifacts after stripping trailing whitespace. Native controller acceptance is consequently stricter than this downstream text predicate. Some cap-truncated outputs are valid under the latter but are still recorded as ABSTAIN. The distinction affects grammar-only as well as XGrammar and is not a property of the language model’s answer reasoning.

Table 6 retains the frozen controller-certified endpoint and reports a separate offline text-only diagnostic. No status is changed and no hypothetical earlier return is labeled a new run. At fixed8, Qwen’s XGrammar controller certified 39 outputs with 31 correct, but 44 final texts satisfy the weaker predicate, with 35 correct. For Mistral, grammar’s corresponding counts are 37/27 versus 43/30, and XGrammar’s are 37/27 versus 42/30. Thus full’s 28 correct native commitments do not dominate the 30 correct returned texts under either weaker comparator endpoint. At the Mistral minimum-length boundary, the same distinction gives 26/17 controller-certified/correct grammar outputs versus 42/28 text-valid/correct outputs, compared with full’s 64/18.

Table 6. Fixed8 terminal-policy sensitivity, all 64 requests per row. Cells give valid or certified count/correct count. Text-only scoring disregards the original declaration status and is a diagnostic endpoint, not additional committed outputs.

| Model   | Policy   | Controller-certified/correct | Text-valid/correct |
|:--------|:---------|-----------------------------:|-------------------:|
| Qwen    | Full     |                        57/35 |              57/35 |
| Qwen    | Grammar  |                        44/35 |              44/35 |
| Qwen    | XGrammar |                        39/31 |              44/35 |
| Mistral | Full     |                        45/28 |              45/28 |
| Mistral | Grammar  |                        37/27 |              43/30 |
| Mistral | XGrammar |                        37/27 |              42/30 |

The full-versus-grammar controller comparison still shares the same canonical token language and accepting states, so its conditional preservation analysis remains applicable to that endpoint. It does not imply nondecreasing correctness against a comparator returning earlier under the weaker predicate. Likewise, the canonical reference-reachability diagnostic does not show that the correct answer is impossible under every text predicate or tokenization. Native-acceptance differences from XGrammar cannot isolate distance pruning, and its lower declared coverage must not be described as evidence of inferior general grammar enforcement. A future common-consumer comparison must first freeze terminal-newline policy and align compiled paths, stopping rules and final scoring; retrospective text scoring does not replace such an execution.

### 6.7. Descriptive timing and limitations

Timing was collected with batch size one in two sequential waves. Each wave started one Qwen worker and one Mistral worker on separate A800 GPUs after a two-worker resident-model barrier. The workers could finish at different times; four workers did not execute concurrently. Model and GPU identity were coupled, and question shards were fixed to waves. Each model-wave-policy timing cell contains 24 requests on eight questions with three repetitions per question. Wave-level means below are descriptive; the two waves cannot estimate a wave random effect, and no across-wave confidence interval is asserted.

Table 7. Matched-prefix mean request time in milliseconds, by wave, model and policy; 24-token option-text setting.

| Wave | Model   | Full   | Grammar-only | Candidate-sequence scoring |
|:-----|:--------|:-------|:-------------|:---------------------------|
| 0    | Qwen    | 120.05 | 119.99       | 60.77                      |
| 0    | Mistral | 150.33 | 150.40       | 62.70                      |
| 1    | Qwen    | 164.49 | 163.66       | 62.21                      |
| 1    | Mistral | 220.49 | 221.53       | 62.67                      |

These are supplied-prefix request measurements, not complete end-to-end system costs. Candidate scoring uses a different computation from autoregressive generation. Differences between waves or policies cannot be attributed to hardware or generalized as a speed advantage. The prior three-GPU timing study used different boundaries and is not pooled with these measurements.

### 6.8. Reproducibility, statistical scope and remaining evidence

The 2 November bundle contains both complete newer raw archives, source snapshots, frozen inputs, model-file manifests, environment logs and the actual sequential single-GPU and two-wave schedulers. We verified all 443 listed file hashes and reproduced the 1,920- and 6,976-record grids, with no duplicate/missing jobs, inference errors, invalid constrained commitments or budget overruns. The original study’s deterministic format-reduction checks also reproduce. New-study token IDs, artifact certificates, budget distances and dead-entry steps were reconstructed against its archived canonical paths, independently of its stored distance events. This is exact path enumeration in that frozen language, not a newly loaded tokenizer or a distance oracle for XGrammar’s alternate tokenizations.

The archived inference Python files match the repository sources used by the audit. The recorded model specifications and weight-file hashes agree across study manifests; model weights themselves are not in the results bundle and were not reread during this offline verification. Archival hashes establish integrity of supplied artifacts, not proof that unobserved execution or every compiler predicate is correct. Verification results and per-request rescued-case IDs are released with the audit.

The two studies reuse data. Every fixed8 returned token sequence in the later 64-question subset matches its original-study counterpart for full, grammar, XGrammar and deterministic completion: 64/64 per policy and model. This provides execution consistency, not independent replication or additional question-level evidence. The original all-budget comparison also preserves all 1,082 already-certified grammar trajectories across its 12 model/encoding/cap cells; these again contain repeated questions. No cross-study pooling or effective sample-size increase is asserted.

The original two-model cap24 primary family uses conservative paired 97.5% intervals. The later study’s fixed8 feasible-subset family separately uses the same per-cell confidence level, adjusting for its two model cells only. Other strata, reference-reachability analyses and cost comparisons are exploratory descriptions. Zero observed loss is not, by itself, a statistical equivalence or noninferiority result; Proposition 5 states a different, conditional algorithmic property. Intervals do not repair prior data inspection or dependence across budgets, models and studies.

The completed experiments do not test general field editing, rollback, arbitrary numeric languages or rich document grammars. The wrapper track does not isolate binding benefits, and supplied-prefix costs exclude upstream prefix generation. A broad full-system or generalization claim would therefore require a genuinely separate evaluation with frozen contracts, a justified sample size, all five strong comparators and complete attempt costs. If such a study is pursued, a fixed global budget must be distinguished from constructed per-case minimum/maximum controls. Existing known-cohort results and the original inactive-mask outcome must remain reportable. No human-rating endpoint is required for these computational claims.

## 7. Discussion

The distance filter provides a useful control distinction: prefix legality asks whether a continuation is permitted, whereas viability asks whether acceptance remains reachable before the remaining token budget expires. Proposition 5 additionally specifies when this refinement makes no change at all: an already successful matched greedy grammar trajectory is preserved. The raw audit connects these statements to observed dead-end avoidance and retained token trajectories within the declared canonical language, while recording initial infeasibility separately from failures introduced during decoding. These canonical dead ends do not imply that every weaker consumer predicate is still unsatisfied.

Both semantic feasibility and terminal acceptance policy are measurable limitations. At fixed8, 13/13 Qwen and 7/8 Mistral rescues have no budget-feasible canonical reference answer. The method completes the structural task it was given but cannot make an excluded answer fit. The same effect helps explain the large completion gains at constructed minimum-length budgets. Moreover, a weaker downstream text predicate can accept some prefixes before native controller termination; Section 6.6 shows that this can reverse correct-yield comparisons. Correctness and conditional accuracy must therefore accompany coverage, and answer-length/reference-reachability diagnostics must accompany claims about hard-budget success. An application that penalizes wrong commitments more heavily than abstention may receive little or negative utility from extra structural returns; no universal utility gain is claimed.

Strong simple alternatives are decisive for interpreting novelty and value. Deterministic shortest completion can provide structural acceptance without model inference, and feasible-candidate scoring combines that structural coverage with model-informed answer selection. The latter is a competitive baseline in this small finite-choice task, not an inferior grammar surrogate. The full controller’s local preservation property concerns grammar-only greedy trajectories; it does not imply superiority over global candidate scoring. The experiments establish neither a general accuracy advantage nor a scalability or speed advantage over this alternative.

The scope of the implementation remains narrow. Canonical token paths omit some valid tokenizations; compiler coverage limits which contracts can be served; enumeration can be expensive as candidate spaces grow. Append-only binding cannot correct a wrongly frozen answer. The wrapper’s acceptance check is an operational heuristic. The more defensible contribution is the contract-explicit specification, conditional preservation analysis and auditable account of the structural–semantic trade-off. A claim of a new constrained-decoding paradigm remains unsupported without a substantive distinction from prior length-aware and reachability-based methods, and independent task or application evidence.

## 8. Conclusions

Budget-viable commitment refines finite-language constrained completion by retaining only next tokens with an accepting suffix inside the remaining budget. Exact reachability gives conditional structural completion; under matched greedy scores and tie-breaking, already successful grammar trajectories are preserved. Raw audits confirm this mechanism in the evaluated known cohort, including fewer budget dead ends and explicit initial-infeasibility rejection. They also identify its semantic boundary: most additional fixed8 completions occur where the canonical reference path cannot fit, correct-commit gains are minimal, and weaker text-only acceptance can change the comparison. Candidate scoring matches structural coverage and remains a strong alternative. These results support a reproducible mechanism and failure-boundary analysis, not a new reachability algorithm, universal quality improvement or deployment speed guarantee. Independent evaluation and a completed nearest-prior-method comparison remain necessary for stronger claims.

## Data and code availability

Code, the raw-result bundle and this audit are available in the public repository <https://github.com/Eov-firefly/learningclass>. The bundle dated 2 November 2026 contains the 1,920-record single-GPU study, the 6,976-record two-wave study, the 25,200-record historical main protocol, and the 11,200 scored concurrent-timing calls with 480 warmups. Duplicate aggregate/wave copies and derived scored files are not extra observations. The outer bundle SHA-256 is . The preserved single-GPU and two-wave ZIP hashes are, respectively, and .

The directory `research_outputs/raw_audit_20261102` contains the offline audit program, verification scope and derived tables. The original runtime source snapshots and schedulers remain in the bundle. A journal-specific permanent release/DOI is pending. Funding and other author declarations below require factual completion; neither absent funding nor absent conflicts is inferred.

## Declarations pending author verification

Funding, competing interests, author contributions and final author approval remain unconfirmed. The supplied author order, affiliation and correspondence address are retained for verification. These entries must be replaced with factual, journal-compliant declarations before submission; absence of funding or conflicts is not assumed.

AI assistance was used in preparing this revised text and developing/checking the supplied code. The authors must verify and complete the disclosure against the actual research workflow and the selected journal’s policy. All reported endpoints are computational; no human-rating result is claimed. Human authors remain responsible for all content and final approval.

## References

Clark P, Cowhey I, Etzioni O, Khot T, Sabharwal A, Schoenick C, Tafjord O. 2018. Think you have solved question answering? Try ARC, the AI2 Reasoning Challenge. arXiv:1803.05457. <https://arxiv.org/abs/1803.05457>

Cobbe K, Kosaraju V, Bavarian M, Chen M, Jun H, Kaiser L, Plappert M, Tworek J, Hilton J, Nakano R, Hesse C, Schulman J. 2021. Training verifiers to solve math word problems. arXiv:2110.14168. <https://arxiv.org/abs/2110.14168>

Geng S, Josifoski M, Peyrard M, West R. 2023. Grammar-Constrained Decoding for Structured NLP Tasks without Finetuning. Proceedings of EMNLP 2023, 10932–10952. DOI: 10.18653/v1/2023.emnlp-main.674. <https://aclanthology.org/2023.emnlp-main.674/>

Han T, Wang Z, Fang C, Zhao S, Ma S, Chen Z. 2025. Token-budget-aware LLM reasoning. Findings of ACL 2025, 24842–24855. DOI: 10.18653/v1/2025.findings-acl.1274. <https://aclanthology.org/2025.findings-acl.1274/>

Hokamp C, Liu Q. 2017. Lexically Constrained Decoding for Sequence Generation Using Grid Beam Search. Proceedings of ACL 2017 (Volume 1: Long Papers), 1535–1546. DOI: 10.18653/v1/P17-1141. <https://aclanthology.org/P17-1141/>

Hugging Face. 2025. Transformers v4.48.2: generation stopping criteria, including StopStringCriteria. Versioned implementation. <https://github.com/huggingface/transformers/blob/v4.48.2/src/transformers/generation/stopping_criteria.py> (accessed 26 October 2026).

Mistral AI. 2024. Mistral-7B-Instruct-v0.3 model card. <https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3>

Muennighoff N, Yang Z, Shi W, Li XL, Fei-Fei L, Hajishirzi H, Zettlemoyer L, Liang P, Candes E, Hashimoto T. 2025. s1: Simple test-time scaling. arXiv:2501.19393v3. <https://arxiv.org/abs/2501.19393v3>

Outlines project. 2026. Official project README, commit . <https://github.com/dottxt-ai/outlines/blob/c52af8472c6fe8a607a733ec11b709476af77a96/README.md> (accessed 27 October 2026).

Wang J, Jain S, Zhang D, Ray B, Kumar V, Athiwaratkun B. 2024. Reasoning in token economies: Budget-aware evaluation of LLM reasoning strategies. Proceedings of EMNLP 2024, 19916–19939. DOI: 10.18653/v1/2024.emnlp-main.1112. <https://aclanthology.org/2024.emnlp-main.1112/>

XGrammar project. 2026. Official project README, including the XGrammar-2 announcement, commit . <https://github.com/mlc-ai/xgrammar/blob/e085851aec8f417924be5f460d1e038cac0e3bd5/README.md> (accessed 27 October 2026).

Yang A, Yu B, Li C, Liu D, Huang F, Huang H, Jiang J, Tu J, Zhang J, Zhou J, Lin J, et al. 2025. Qwen2.5-1M technical report. arXiv:2501.15383. <https://arxiv.org/abs/2501.15383>
