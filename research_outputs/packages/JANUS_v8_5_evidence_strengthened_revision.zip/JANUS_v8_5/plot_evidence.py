"""Publication-style diagnostic figure from existing-data transition counts."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
d=json.loads((root/'analysis/new_analyses.json').read_text())
rs=sorted(d['validity_transitions'],key=lambda r:(r['model']!='qwen',r['task']!='gsm8k'))
labels=[('Qwen' if r['model']=='qwen' else 'Mistral')+'\n'+('GSM8K' if r['task']=='gsm8k' else 'ARC') for r in rs]
good=[r['newly_valid_correct'] for r in rs];wrong=[r['newly_valid_incorrect'] for r in rs]
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(7.2,4.5),layout='constrained')
x=list(range(4));ax.bar(x,good,color='#2878A8',label='Newly valid and gold-correct')
ax.bar(x,wrong,bottom=good,color='#D98B39',label='Newly valid but gold-incorrect')
for i,(a,b) in enumerate(zip(good,wrong)):
 ax.text(i,a+b+2,str(a+b),ha='center')
ax.set_xticks(x,labels);ax.set_ylim(0,155)
ax.set_ylabel('Model–question pairs (600 per cell)')
ax.set_title('Validity repair is distinct from answer correctness',loc='left',weight='bold')
ax.legend(frameon=False,loc='upper left')
fig.supxlabel('Retrospective strict-contract audit; descriptive counts, no new inference',fontsize=9)
(root/'figures').mkdir(exist_ok=True)
fig.savefig(root/'figures/validity_repairs.pdf')
fig.savefig(root/'figures/validity_repairs.png',dpi=250)
plt.close(fig)
