# Contract-aware termination for LLM inference: validity preservation and output-matched cost analysis

Ya Bai, GuoZhen Bian*, Cheng Chang, ZhengGuang Cui, HaiLong Qin, ZhiHui Huang, Yue Wang

China Telecom Cloud Network Operating System R&D Center, Beijing, China

\* Correspondence: biangz@chinatelecom.cn

Revision v8.5, 26 October 2026. Frozen experimental values are retained. Formalization, validity-transition analysis and algebraic cost decomposition are retrospective additions. Author declarations and complete access to the new raw timing archive remain to be finalized.

## Abstract

An answer prefix can satisfy a delivery contract and lose that validity when generation continues. We study contract-aware termination as a return-action constraint that leaves continuation-token scores unchanged. Under a sound online certificate and shared trajectories, stopping at the earliest certified boundary weakly preserves contract validity relative to EOS-or-cap termination, but does not guarantee reaching a valid answer or preserving answer correctness. An audit of 2,400 model–question pairs from two instruction-tuned models on GSM8K and ARC-Challenge found 204 invalid-to-valid transitions and no validity losses. Of these repaired outputs, 114 were correct and 90 remained wrong. Every shortened output belonged to this repair set; observed token reductions therefore reflected avoided contract-breaking continuation, not a general reduction in reasoning length. Five-contract rescoring changed or reversed the measured benefit, and last-marked-answer extraction eliminated every net correctness difference. A separate follow-up comprised 400 pilot and 10,800 formal scored timing calls under concurrent three-GPU execution. Output-matched boundary and entropy controls yielded positive descriptive monitoring intervals in all 36 model/task/session contrasts. An algebraic decomposition separates net stopping effects from boundary-path overhead, without treating derived contrasts as isolated generation costs. Completion increased Qwen latency by approximately 2.5%–2.9%; Mistral intervals included benefit and harm. These results provide an auditable evaluation of contract validity, answer correctness and implementation cost. They do not establish grammar enforcement, semantic improvement or universal acceleration.

Keywords: termination control; constrained generation; contract validity; output-matched evaluation; inference monitoring

## 1. Introduction

A stopping rule determines which generated prefix is delivered to a consumer. That decision is consequential when the consumer accepts a terminal answer field: a correct field can become invalid after further explanation, a second marker or a formatting closure. Another consumer may require the closure or tolerate later text. The relevant question is therefore not whether an early prefix is universally better, but which guarantee a stopping intervention provides under an explicit delivery contract and at what measured cost.

Constrained generation already offers tools for controlling output structure. Lexical constraints can require specified phrases, grammar constraints can restrict structural continuations, and ordinary stop-string mechanisms can terminate generation at detected boundaries. The contribution sought here is not the invention of stopping or constrained decoding. It is an explicit separation of three properties that an aggregate efficiency comparison can conflate: contract validity, extracted-answer correctness and elapsed runtime.

We call the tested intervention **contract-aware termination**. A certificate derived from the current output triggers return; if generation continues, the next-token scores are unchanged. Under shared trajectories and a sound certificate, this yields a pathwise validity-preservation property. It does not ensure a certificate will be reached, and a valid early answer can be wrong. This distinction makes a concrete empirical prediction: validity repairs must be reported separately from correct-answer gains, rather than presenting an increase in formatted correctness as improved reasoning.

Runtime requires another separation. Stopping may avoid continuation while detection and entropy observation add work. A five-arm design with Uniform, boundary-only observation, Complete, entropy observation at Complete's boundary, and entropy observation at Uniform's boundary identifies output-matched monitoring contrasts. A further algebraic comparison shows which net stopping effect accompanies the boundary-processing path, without assuming token count is a cost proxy.

The research questions are: RQ1, what validity and correctness guarantees follow from the stopping intervention; RQ2, which observed benefits survive changes to the consumer contract; and RQ3, which runtime effects remain after output matching? The contributions are (i) a conditional theoretical account distinguishing preservation from reachability and correctness, (ii) a transition-level empirical audit that identifies what is repaired and where token savings arise, and (iii) an output-matched cost analysis with implementation-specific interpretation. The resulting protocol is reusable even when the stopping rule is standard or its performance result is negative.

The case study uses two approximately 7B instruction-tuned models, two short-answer tasks and one token allowance. It began with an implementation audit of historical JANUS scheduling claims and was narrowed to implemented stopping behavior. Frozen experiments are preserved. The theory and the new analyses of existing data are retrospective, not preregistered hypotheses or new held-out experiments. No claim of priority over the general constrained-decoding literature or superiority over optimized structural-generation systems is made.

### 1.1. Related work and intervention boundaries

Hokamp and Liu (2017) introduce Grid Beam Search for phrase-level lexical constraints. Geng et al. (2023) study grammar-constrained decoding for structured NLP tasks and input-dependent grammars. These interventions constrain admissible content or output structures. By contrast, contract-aware termination leaves content generation unchanged until it returns a certified prefix. Our formalism describes that difference; it is not a substitute for the reachability and structural controls supplied by a grammar system. We distinguish these intervention targets without claiming a reproduced performance comparison.

Termination is also an existing decoder primitive. Transformers 4.48.2 provides EOS, length and stop-string criteria, including StopStringCriteria for strings intersecting token boundaries (Hugging Face, 2025). A native stopping implementation with the same complete-answer semantics is an equivalent engineering comparator, not a distinct algorithm to be defeated by renaming. The present Marker arm, which stops before an answer value is complete, is a negative control and does not establish competitiveness against usable stop mechanisms.

XGrammar and Outlines provide practical structured-generation systems (XGrammar project, 2026; Outlines project, 2026). Their optimized implementations are relevant neighbors, but the costs of our full-prefix Python callbacks do not estimate their overhead. We neither enforce their grammars nor measure their performance. Token-support constraints and return-time controls can be composed; that combination is not evaluated here.

Budget-aware reasoning studies different uses of inference computation (Wang et al., 2024; Han et al., 2025; Muennighoff et al., 2025). Automated answer extraction is another evaluation layer (Yu et al., 2025). Our scope is a fixed decoder's delivered prefix, not a new trained reasoning model, global budget allocator or semantic evaluator. GSM8K (Cobbe et al., 2021) and ARC (Clark et al., 2018) supply numeric and choice-answer cases with known reference answers. Direct optimized implementation comparisons are outside the present experiment, which consequently supports no competitive new-decoder claim.

## 2. Termination constraints: formalization and guarantees

### 2.1. Contract state and stopping action

Let $x$ be a prompt and $y_{1:t}$ a generated token prefix with decoded text $d_t$. The underlying decoder supplies next-token probabilities $p_\theta(v\mid x,y_{1:t})$ over vocabulary $V$, including natural EOS. Let $T_U$ be its EOS-or-cap stopping index, with cap $K$. In greedy generation the corresponding token action is an argmax; no sampling experiment is implied by the probability notation. Policy comparisons below use a common coupled baseline trajectory up to each return event. Actual token-prefix identity must be checked in the implementation rather than inferred from the word greedy.

A contract $\mathcal C$ specifies validity $A_{\mathcal C}(d,e)\in\{0,1\}$ and a value extractor $g_{\mathcal C}(d,e)$, where $e$ denotes observed EOS. The online certificate $B_{\mathcal C}(d_t)$ uses only the emitted prefix and must be sound: if $B_{\mathcal C}(d_t)=1$, returning this text without EOS satisfies $A_{\mathcal C}(d_t,0)=1$. In the tested contract, the newline after the final marked value supplies this certificate. Offline EOS certification is a distinct acceptance path.

At an active prefix, augment the token action space with $\mathrm{STOP}$, which returns the existing text without appending a token. For deterministic decision $\delta_t=B_{\mathcal C}(d_t)$, define

$$
q(\mathrm{STOP}\mid x,y_{1:t})=\delta_t,\qquad
q(v\mid x,y_{1:t})=(1-\delta_t)p_\theta(v\mid x,y_{1:t}),\quad v\in V.
$$

This is a normalized action distribution. If $\delta_t=0$, the original token distribution, including EOS, is retained. If $\delta_t=1$, return is forced. This descriptive stopping-action constraint does not mask content tokens or sample from $p_\theta(y\mid y\in\mathcal L_{\mathcal C})$. It is therefore not a new exact sampler for a constrained language. Natural EOS and the cap retain their fallback roles in the actual implementation.

For contrast, a token-support constraint can be written

$$
p_M(v\mid x,y)=
\frac{p_\theta(v\mid x,y)M(y,v)}{\sum_{u\in V}p_\theta(u\mid x,y)M(y,u)},
$$

where $M(y,v)\in\{0,1\}$ specifies allowed continuations and the denominator must be positive. Local masking alone is not asserted to implement exact global conditioning either. Contract-aware termination corresponds to a different intervention on this action space; replacing $p_\theta$ by $p_M$ would compose the two controls, but that untested combination is not an empirical contribution of this paper.

### 2.2. Conditional validity and the missing reachability guarantee

Define

$$
\tau_{\mathcal C}=\min\{t<T_U:B_{\mathcal C}(d_t)=1\},\qquad
T_C=\min(\tau_{\mathcal C},T_U),
$$

with the minimum of the empty set equal to infinity. Events at $T_U$ cannot reduce token consumption, and EOS priority is retained.

**Proposition 1 — validity at a certified return.** If $\tau_{\mathcal C}<T_U$, then the returned text is valid under $\mathcal C$. This follows directly from the soundness of $B_{\mathcal C}$. It is a conditional contract guarantee, not a guarantee that a certificate will occur.

Let $E=\{\tau_{\mathcal C}<T_U\}$. For a distribution of trajectories under the same decoder,

$$
\Pr(A_{\mathcal C}(d_{T_C},e_{T_C})=1)
=\Pr(E)+\Pr(E^c\cap\{A_{\mathcal C}(d_{T_U},e_{T_U})=1\}).
$$

Thus acceptance can fail when natural EOS or the cap is reached before a certificate and the fallback text is invalid. For example, immediate EOS with no answer remains possible. A universal structural guarantee would require additional controls on token support, EOS or fallback behavior. The existing method does not implement those controls.

**Corollary 1 — pathwise validity preservation.** Write $A_C$ and $A_U$ for validity of Complete and Uniform under the same contract. With $E$ as above,

$$A_C-A_U=\mathbf 1_E(1-A_U)\geq 0.$$

**Proof.** On $E$, the returned prefix is valid by certificate soundness, so its validity is one. Outside $E$, both policies return the same baseline text and EOS status. Subtracting gives the identity. This preserves validity relative to the baseline, not validity with probability one. It fails as a comparison theorem if the certificate and scorer use different contracts or the generated trajectories diverge.

For paired outputs, define validity repairs $R=\{A_C=1,A_U=0\}$. Their composition must be reported as

$$|R|=|R\cap\{Q_C=1\}|+|R\cap\{Q_C=0\}|,$$

where $Q_C$ is contract-valid correctness against the reference answer. A sound formatting certificate alone cannot eliminate the second term. Moreover, outside $R$, changed extracted values can cause correctness wins or losses even when both outputs are valid; zero such changes is an empirical finding, not part of the validity theorem.

### 2.3. Earliest-boundary minimality is not global optimality

**Proposition 2 — trajectory-relative length minimality.** On a fixed shared trajectory where $E$ occurs, Complete returns at the smallest token index among online certified prefixes before $T_U$. Hence it uses no more tokens than another rule restricted to those same certified prefixes on that trajectory.

**Proof.** Every admissible stopping index lies in the set defining $\tau_{\mathcal C}$; its minimum is no larger than any member. The result says nothing about a different trajectory, a more informative certificate, semantic correctness or wall-clock latency. Calling it globally optimal constrained decoding would be unjustified.

Acceptance need not persist under extension. The strict terminal contract accepts a newline-terminated marked answer but rejects a subsequent non-whitespace closure or explanation. By contrast, another contract may require those closing tokens. These are different consumer specifications, not interchangeable measures of quality.

For gold answer $z$, let $Q_C$ and $Q_U$ denote contract-valid correctness. With $W$ paired wins and $L$ paired losses over $n$ questions,

$$\widehat{\Delta Q}=(W-L)/n.$$

An early prefix ending in a wrong marked value may be followed by a corrected final answer; Complete then loses a correct outcome. Therefore earliest-valid stopping does not imply $Q_C\geq Q_U$. The observed zero losses are an empirical property of the evaluated cohort, not a consequence of Proposition 2. Structural validity does not certify answer truth.

### 2.4. An additional gate requires temporal overlap

Let $G_t$ represent entropy stability and minimum-step conditions. A non-latched conjunction returns at

$$
T_E=\min\bigl(\{t<T_U:B_{\mathcal C}(d_t)G_t=1\}\cup\{T_U\}\bigr).
$$

**Proposition 3 — subset ordering and overlap.** On a shared trajectory, $T_C\leq T_E\leq T_U$, and $T_E<T_U$ if and only if a certified completion and all additional gates coincide before $T_U$.

**Proof.** Eligible conjunction indices form a subset of eligible completion indices. Taking their minima with a common fallback gives both the ordering and the overlap condition. Stable entropy at other steps is insufficient. This explains what the trace experiment must inspect, but it does not establish which threshold is best or how entropy relates to truth. A latched alternative must specify whether it returns the current text or an earlier buffered prefix and count computation performed after that prefix.

### 2.5. Token savings and runtime break-even

For a paired trajectory, write elapsed time as $L_P=\sum_{t=1}^{N_P}b_t+M_P+r_P$, where $b_t$ is a reference generation-step cost, $M_P$ is policy-specific processing, and $r_P$ represents departures from the reference. This is an explanatory decomposition, not a separately identified measurement of each component.

**Proposition 4 — break-even identity.** If $N_C\leq N_U$, subtraction gives

$$
L_C-L_U=-\sum_{t=N_C+1}^{N_U}b_t+(M_C-M_U)+(r_C-r_U).
$$

Lower token consumption alone is insufficient for a negative latency difference. With exact output matching, the saved-step term vanishes and monitoring contrasts measure an added implementation path subject to runtime variation. They do not identify an implementation-independent cost of constrained decoding. In particular, full-prefix host transfer, repeated decoding and vocabulary-wide entropy computation are choices of the tested callbacks, not requirements of every constrained generator.

The measured five-arm design also permits an exact decomposition of mean contrasts within one model/task/session. Let

$$D=\overline L_C-\overline L_U,\quad B=\overline L_{BO}-\overline L_U,\quad R_L=\overline L_{BO}-\overline L_C.$$

Then $D=B-R_L$. Here $B$ is an output-matched boundary-path contrast, $D$ is the net stopping effect, and $R_L$ is the remaining boundary-arm contrast. It includes effects of different stopping lengths, callback execution and runtime noise; it is not an isolated estimate of GPU generation work. Its uncertainty cannot be recovered from the two marginal intervals without their paired covariance or underlying records. We therefore report derived point estimates only. This decomposition is an accounting device, not a new causal identification theorem or a transferable speedup threshold.

### 2.6. Evidence obligations

The evaluation sequence is: (1) specify the accepted artifact, value extractor and online certificate independently of gold labels; (2) verify shared-prefix and output-invariant assumptions on paired records; (3) report invalid-to-valid and valid-to-invalid transitions separately from correctness wins and losses; (4) rescore the same returned outputs under declared alternative contracts; and (5) measure boundary-only and entropy-observation arms before interpreting net speed. A claimed guarantee must identify its certificate assumptions, while a claimed efficiency gain must survive the corresponding runtime contrast. The existing experiment supports this protocol in its narrow tested setting; it does not validate grammar masking, a constrained sampler or a cheaper incremental implementation.

## 3. Materials and methods

### 3.1. Frozen design and sampling

The executed specification was `janus-prospective-v5.1-cap512-reduced`, with seed 20261019 and one output allowance, 512 tokens. Input preparation, an independent implementation pilot, development diagnostics, the main evaluation and isolated timing were separate stages. The pilot checked implementation and provenance gates, rather than a significance threshold or minimum improvement. The execution chain, gate receipts and formal analyses completed successfully. The archived protocol's pre-execution wording is preserved as provenance; dated execution receipts and raw records establish the completed work.

GSM8K used `openai/gsm8k`, configuration `main`, revision `740312add88f781978c0658806c59bc2815b9866`. ARC-Challenge used `allenai/ai2_arc`, configuration `ARC-Challenge`, revision `210d026faf9955653af8916fad021475a3f00453`. Development contained 300 training questions per task; the held-out evaluation contained 600 test questions per task. Exact prompt duplicates and development/test overlap were checked. The 582 GSM8K test questions touched by historical JANUS work were excluded before drawing the new cohort from the remaining 737 eligible questions. ARC sampling used 1,172 eligible test questions. Deterministic manifests record the resulting membership.

The pilot used the first 20 development questions per task. Timing used the first 60 main questions per task, with three repetitions per policy. Thus pilot and timing are nested diagnostic subsets, not independent accuracy replications. Both models answered the same cohorts. There are 1,200 distinct main question identities, 600 per task; the 14,400 main calls arise from two models and six policies. Calls and repetitions do not substitute for independent questions in uncertainty estimates.

Table 1. Executed scored-call counts. Main and pilot evaluate six policies; development evaluates Uniform, Complete and three conjunction thresholds. Warmup calls are outside these counts.

| Stage | Questions per task/model | Settings | Repeats | Scored calls |
| --- | --- | --- | --- | --- |
| Implementation pilot | 20 | 6 | 1 | 480 |
| Development diagnostic | 300 | 5 | 1 | 6,000 |
| Main evaluation | 600 | 6 | 1 | 14,400 |
| Isolated timing | 60 | 6 | 3 | 4,320 |
| Total | - | - | - | 25,200 |

Development thresholds were 0.005, 0.01 and 0.05. The frozen rule selected 0.01 a priori for the prospective conjunction; development did not optimize the reported main threshold. The selection record and guard verify this choice. The legacy threshold remained 0.05. No prospective budget sweep, fitted allocation curve, transfer study or scheduling experiment was executed in this reduced design.

### 3.2. Models, prompts and generation

The models were Qwen2.5-7B-Instruct-1M (Yang et al., 2025), revision `e28526f7bb80e2a9c8af03b831a9af3812f18fba`, and Mistral-7B-Instruct-v0.3 (Mistral AI, 2024), revision `c170c708c41dac9275d15a8fff4eca08d52bab71`. We used each tokenizer's native chat template with a generation prompt and one user message, without in-context examples. For the initial experiment, model revision pins were recorded but weight bytes were not independently rehashed. The follow-up verified model and tokenizer files against its frozen SHA-256 manifest.

The numeric instruction ended: Solve the problem step by step. End with a final line exactly "#### <number>" using a signed integer or decimal, no units or commas. Put a newline after the final line. ARC used the analogous instruction with the instance's allowed choice letters. The exact prompts, question text and choices are reconstructible from input manifests and the runner. Prompts and generation settings were identical across policies for a question.

Generation used BF16, Transformers SDPA, batch size one, greedy decoding, one beam, cache enabled, repetition penalty 1.0, no forced EOS token and no minimum new-token requirement. Every policy in the initial experiment and the new timing experiment performed real inference. The separate retrospective analysis reconstructed stopping outcomes from saved baseline sequences and is explicitly identified as replay in Section 3.7. Each inference call recorded generated token IDs, text, token count, stop reason, parser outcomes, timing and provenance. Token counts include an emitted EOS token. Deterministic algorithms were not enabled, so observed identity checks describe these runs rather than a guarantee across kernels or hardware.

### 3.3. Terminal-answer contract and diagnostic extraction

The prespecified primary quality endpoint is boundary-certified terminal-marker contract accuracy, shortened below to contract accuracy. The parser locates the last line-start `####` marker. Numeric values must be signed integers or decimals; commas, units and scientific notation are excluded. ARC values must be an allowed choice letter. After that value, the suffix may contain whitespace only. Online completion requires a newline after the value. Offline validity additionally requires either EOS termination or a newline-terminated terminal answer in the returned text. The scorer recomputes this boundary from the returned text rather than reading a stored completion event. A numeric fragment at the cap without either certificate is not credited.

A valid answer is correct if its value, compared as a decimal or choice letter, equals the gold answer. Validity is reported separately from correctness. The same parser scores every main policy, including Uniform. This endpoint measures compliance with a specific terminal interface, not correctness under arbitrary extraction conventions.

The parser does not validate document syntax before the marker. A marked line inside an unclosed LaTeX display or code fence can satisfy the contract when stopped after its newline. Later closing that wrapper can invalidate the terminal suffix. This behavior is central to interpreting the results: terminal-line validity and complete-document validity are different requirements. Section 3.7 retrospectively evaluates several explicit alternatives without changing the frozen primary contract.

A legacy-style extractor supplies diagnostic sensitivity scores. GSM8K extraction prioritizes a marked number, then a boxed answer, answer-like phrases or equalities, and finally a trailing number. The ARC diagnostic uses the last standalone A-E letter without filtering to the instance's allowed choices; it is not a historical JANUS parser. These scores describe extraction outcomes and do not establish that incomplete or contradictory text is semantically acceptable.

### 3.4. Implemented stopping policies

Uniform (U) runs to model EOS or the 512-token cap without entropy monitoring. Marker (M) stops at the first observed `####` substring without requiring a value or newline. Marker is a deliberately incomplete negative control, not a proposed usable efficiency method.

Complete (C) stops at the earliest online boundary satisfying the marked answer-line contract. It does not calculate entropy. Shadow (S; code identifier `entropy_observe`) computes entropy diagnostics but uses the Complete stopping rule. Its runtime contrast with Complete isolates the tested monitoring path only if generated token IDs match. A mechanism audit checks that condition.

Legacy entropy (L) calculates full-vocabulary next-token entropy, H = -sum(p log(p + 10^-12)), from pre-token logits. Successive entropy differences are smoothed with coefficient 2/11. After the minimum-step gate, it requires five consecutive stable steps with absolute smoothed difference below 0.05, five identical nonempty legacy answer candidates, and an observed marked or boxed answer. The retained legacy candidate prefix includes the final prompt token. Trigger decisions are applied after the subsequent generated token. The code and traces preserve this timing detail; it is not a completed-answer guarantee.

Conjunction (E; `entropy_complete`) requires at least 21 generated steps, five stable entropy steps at threshold 0.01, and a complete answer boundary at the current step. Completion is not latched: an earlier acceptable line is insufficient if later text changes the suffix. The tested mechanism therefore requires simultaneous completion and stability. Entropy callbacks return the logits unchanged. EOS has priority in stop-reason classification. Exact gates, indexing and special-token handling are executable in `core.py` and `engine.py`.

### 3.5. Hardware and timing

Quality stages in the initial experiment used two NVIDIA A800 80 GB PCIe GPUs, one model per GPU. Its latency analysis uses only the separate isolated timing stage. Models ran sequentially on the same physical GPU without other GPU inference jobs. Each model had 24 warmup calls, two per task/policy, for 48 timing warmups. Jobs were shuffled by the frozen seed within each model session; the saved order was independently reconstructed. Qwen ran on 21 October 2026 from 14:07 to 16:26 UTC, followed by Mistral from 16:29 to 19:17 UTC. Model-session order was not counterbalanced. The later concurrent three-GPU experiment is described separately in Section 3.7 and is not pooled with these measurements.

The runtime used Python 3.11.12, PyTorch 2.6.0+cu124, CUDA 12.4, driver 570.211.01, Transformers 4.48.2, Datasets 3.2.0, NumPy 1.26.4 and SciPy 1.14.1. Timing used two PyTorch CPU threads and 64 interop threads. TF32 matrix multiplication and cuDNN benchmarking were disabled; Flash, memory-efficient and mathematical SDPA backends were enabled. Environment snapshots are archived.

Generation time starts after input preparation and a CUDA synchronization and ends after generation and final synchronization. End-to-end time starts before chat templating, tokenization and device transfer, and ends after generation, synchronization, token-ID transfer and decoding. It excludes model loading, warmup, scoring, logging, network transport and queues. It is a local request interval, not deployed service latency or throughput. Full-vocabulary entropy and scalar transfers introduce GPU/CPU synchronization; measured overhead includes these implementation choices and Python callbacks. It is not a hardware lower bound on entropy estimation.

### 3.6. Analysis and computational verification

Analyses pair policies by question within model and task. The four primary Complete-minus-Uniform accuracy comparisons form one family. Each uses a conservative 98.75% interval, giving at least 95% family coverage by Bonferroni adjustment. The paired binary interval bounds win and loss probabilities using simultaneous one-sided Clopper-Pearson bounds. The frozen practical noninferiority margin is two percentage points. Sensitivity compares the same interval against zero-, one-, two- and five-point margins; changing a margin does not add evidence.

Other main binary contrasts use conservative paired 95% intervals. Continuous metrics use paired question-level bootstrap intervals with 5,000 replicates and seed 20261019. Timing repetitions are first averaged within question before paired resampling, giving 60 clusters per task/model rather than 180. Timing accuracy intervals are descriptive, not a second confirmatory accuracy family. Timing P95 values use nearest-rank individual-call summaries. Secondary intervals are not adjusted for the full set of exploratory comparisons.

Tokens per credited answer equal total output tokens divided by contract-correct calls, and are undefined when no answer is credited. This descriptive ratio does not imply semantic correctness or a deployment price. Relative savings use a no-monitor baseline, never the configured cap, as denominator.

Offline validation checked all 25,200 records, complete job grids, input/protocol provenance, stage separation, threshold selection and mechanism identities. All observed policy outputs were prefixes of their paired Uniform outputs; Complete and Shadow token IDs matched; Conjunction never ended before Complete. Local reanalysis reproduced summaries and mechanisms exactly and intervals within 10^-12 numerical tolerance across Python/SciPy versions. Original server results remain unchanged. This is computational reproduction of an archived experiment, not independent experimental replication.

### 3.7. Frozen follow-up and retrospective sensitivity analyses

The follow-up separates reanalysis from newly executed inference. Retrospective reconstruction used 3,600 saved Uniform trajectories (1,200 development and 2,400 main model/question pairs) to form 10,800 reconstructed policy records. Those records are not additional inference calls or independent observations. Reconstruction matched the recorded token sequences, text, stopping outcomes and scores in the audited comparisons. Main-cohort contract sensitivity uses the same 600 questions per model/task cell as the initial experiment. A mechanism audit inspected all 114 strict-contract Complete-over-Uniform wins. These are computational checks of saved outputs; they establish operational parser outcomes only.

Five operational contracts were applied to the saved main outputs: the frozen strict terminal rule; a closure-tolerant rule allowing recognized closing wrappers; a wrapper-balanced strict rule; a closure-balanced rule combining closure tolerance with wrapper balance; and a last-marked-answer rule that permits later text. These finite rules do not implement a general Markdown or LaTeX parser, and numeric comparison remains exact. The source snapshot used for the reported sensitivity counts requires a line-start marker. A received alternative implementation also accepts indentation before the marker. Their sole affected main-cohort question changes both policies' absolute correct counts in three Qwen/GSM8K contract cells by one, while all 20 paired accuracy differences and win/loss counts remain unchanged. The preserved parser provenance audit documents both implementations; none of these alternatives replaces the frozen primary endpoint.

A separate trace audit reused 240 SHA-verified trajectories and evaluated 12 parameter combinations (2,880 replay evaluations). The frozen entropy conjunction used threshold 0.01, five stable steps and a minimum of 21 steps. More permissive combinations were exploratory and were not used to replace the deployed rule or select new accuracy results. The previously completed 56-call smoke check and 240-call trace set were reused by hash; five-GPU timing observations were excluded from the three-GPU analysis. No additional quality extension was executed.

The v8.3 protocol first ran a three-GPU timing pilot with 400 scored calls and 120 warmups, using six workers in two waves. Its complete grid, exit codes, barriers, token identity checks and analysis underwent independent AI-agent technical review before a hash-bound decision released formal timing. This was an operational implementation review, not a semantic-quality endpoint. Formal timing comprised 10,800 scored calls: two models, two tasks, 60 questions per task, five policies, three within-session repetitions and three sessions. Eighteen workers ran in six waves with 360 additional warmups. Thus, new generation comprised 11,200 scored calls and 480 warmups. The formal 120 distinct questions are a reused subset of the original main cohort; the three sessions do not add new questions.

Each of three A800 80 GB GPUs ran one independent batch-size-one worker. Models, revisions, allowance of 512 tokens, BF16 precision and SDPA attention were retained. Workers used four assigned CPU cores and two intra-operation and two inter-operation threads. Model order was Qwen then Mistral in sessions 0 and 2 and Mistral then Qwen in session 1. This partly varies order but does not fully counterbalance it. The five follow-up policies were Uniform (U); boundary_observe (BO), which processes the token prefix and parses the boundary without stopping early; Complete (C), which stops at that boundary; entropy_observe (EO), which adds entropy observation to Complete without gating it; and entropy_uniform (EU), which adds entropy observation to BO without early stopping. These five controls differ from the six-policy initial accuracy experiment.

Four prespecified operational contrasts were evaluated: EO-C for added entropy monitoring on the completion path, BO-U for boundary processing without truncation, EU-BO for added entropy monitoring on the full-output path, and C-U for the net effect of completion stopping. Calls were paired by model, task, session, question, repetition and recorded worker/GPU provenance. Within each contrast and session, three repetitions were averaged per question before a paired question-cluster percentile bootstrap (5,000 replicates; seed 20261019; n = 60). All 48 resulting 95% intervals are descriptive and unadjusted for multiple comparisons. The same questions recur across sessions and models; neither repeated calls nor GPU shards are treated as independent questions. Ranges across the three session means are descriptive ranges, not confidence intervals.

The new end-to-end timer starts before tokenization of an already constructed prompt and includes transfer, synchronized generation, token-ID transfer to CPU and decoding. It excludes chat-template construction, model loading, warmups, scoring, logging and network or queue latency. The original end-to-end timer also included chat-template construction and used different CPU thread settings. Hardware sharing, model order and timing boundaries therefore preclude pooling the old isolated, old five-GPU and new three-GPU results or attributing their differences solely to GPU count. The experiment measures paired request latency under concurrent deployment, not aggregate service throughput or a threefold speedup.

### 3.8. Additional retrospective transition and contrast analysis

For this revision, the original main JSONL records were joined by model, task and question ID for Uniform and Complete. Token-prefix identity, 600-pair grids, validity transitions and correctness outcomes were checked directly. We compared the exact set of shortened trajectories with the set of invalid-to-valid transitions. This analysis uses stored frozen scores already checked against an independent parser; it is not a new model experiment or semantic annotation. For formal timing, B, D and R_L were calculated from the preserved session-level contrasts. The new raw per-call timing archive was not available to this revision, so derived covariance and intervals were not estimated. Original numerical tables and frozen endpoints are unchanged. Analysis code, input hashes and machine-readable outputs accompany the revision.

## 4. Results

### 4.1. Main contract accuracy and actual consumption

Table 2 reports all policies. Marker never delivered a contract-valid answer; its apparent token savings are not useful savings for this interface. Complete and Shadow had identical quality and token counts in all 2,400 main question/model pairs. Permissive diagnostic results appear in the supplementary metrics.

Table 2. Main results at cap 512, with 600 questions per row. Correct and valid are terminal-contract percentages. Tok/correct is total tokens per contract-correct call; a dash indicates a zero denominator. U: Uniform; M: Marker; L: Legacy entropy; C: Complete; S: Shadow; E: Conjunction.

| Model / task | Policy | Correct % | Valid % | Mean tokens | Tok/correct |
| --- | --- | --- | --- | --- | --- |
| Qwen / GSM8K | U | 67.83 | 92.50 | 181.05 | 266.90 |
| Qwen / GSM8K | M | 0.00 | 0.00 | 176.45 | - |
| Qwen / GSM8K | L | 53.83 | 74.50 | 180.27 | 334.87 |
| Qwen / GSM8K | C | 70.17 | 97.17 | 180.91 | 257.83 |
| Qwen / GSM8K | S | 70.17 | 97.17 | 180.91 | 257.83 |
| Qwen / GSM8K | E | 67.83 | 92.50 | 181.05 | 266.90 |
| Qwen / ARC-C | U | 87.67 | 96.50 | 191.55 | 218.50 |
| Qwen / ARC-C | M | 0.00 | 0.00 | 189.60 | - |
| Qwen / ARC-C | L | 62.67 | 71.00 | 191.29 | 305.26 |
| Qwen / ARC-C | C | 87.67 | 96.50 | 191.55 | 218.50 |
| Qwen / ARC-C | S | 87.67 | 96.50 | 191.55 | 218.50 |
| Qwen / ARC-C | E | 87.67 | 96.50 | 191.55 | 218.50 |
| Mistral / GSM8K | U | 44.00 | 74.17 | 229.03 | 520.53 |
| Mistral / GSM8K | M | 0.00 | 0.00 | 219.04 | - |
| Mistral / GSM8K | L | 32.00 | 54.17 | 227.42 | 710.70 |
| Mistral / GSM8K | C | 57.50 | 95.67 | 223.75 | 389.13 |
| Mistral / GSM8K | S | 57.50 | 95.67 | 223.75 | 389.13 |
| Mistral / GSM8K | E | 44.00 | 74.17 | 229.03 | 520.53 |
| Mistral / ARC-C | U | 50.83 | 68.50 | 183.58 | 361.14 |
| Mistral / ARC-C | M | 0.00 | 0.00 | 173.45 | - |
| Mistral / ARC-C | L | 34.17 | 46.67 | 180.05 | 526.97 |
| Mistral / ARC-C | C | 54.00 | 76.33 | 178.83 | 331.16 |
| Mistral / ARC-C | S | 54.00 | 76.33 | 178.83 | 331.16 |
| Mistral / ARC-C | E | 51.00 | 68.67 | 182.90 | 358.63 |

Table 3. Main Complete-minus-Uniform contrasts. Accuracy changes are percentage points with family-adjusted 98.75% intervals. Token changes are tokens per call with paired bootstrap 95% intervals. Wins and losses concern paired contract correctness.

| Model / task | Win / loss | Accuracy change [CI] | Token change [CI] |
| --- | --- | --- | --- |
| Qwen / GSM8K | 14 / 0 | +2.33 [0.03, 4.57] | -0.137 [-0.188, -0.088] |
| Qwen / ARC-C | 0 / 0 | +0.00 [-0.96, 0.96] | +0.000 [0.000, 0.000] |
| Mistral / GSM8K | 81 / 0 | +13.50 [8.98, 17.72] | -5.285 [-6.227, -4.388] |
| Mistral / ARC-C | 19 / 0 | +3.17 [0.59, 5.66] | -4.750 [-7.508, -2.623] |

Complete met the frozen two-point noninferiority criterion in all four cells. Three accuracy intervals excluded zero positively. Qwen ARC-C had no discordant correctness pairs, with an interval of -0.96 to 0.96 points; this supports a two-point tolerance but does not prove zero loss probability. Token savings were 0.08% for Qwen GSM8K, 0.00% for Qwen ARC-C, 2.31% for Mistral GSM8K and 2.59% for Mistral ARC-C. Contract-accuracy differences can therefore be much larger than consumption differences.

Complete gained 114 credited answers and lost none relative to Uniform. Every gain had a missing terminal-contract prediction under Uniform rather than a different extracted valid prediction. This supports contract preservation, not better mathematical or multiple-choice reasoning. Qwen GSM8K's 14 gains comprised 13 responses with a later LaTeX display closure and one with a later code-fence closure. An accepted prefix can thus be syntactically incomplete under a richer document validator while satisfying the frozen terminal-marker contract.

### 4.2. Entropy conditions and completion opportunities

Legacy entropy reduced contract accuracy relative to Uniform by 14.00 points for Qwen GSM8K, 25.00 for Qwen ARC-C, 12.00 for Mistral GSM8K and 16.67 for Mistral ARC-C. The respective 95% intervals were [-17.48, -10.25], [-29.19, -20.39], [-15.30, -8.46] and [-20.54, -12.48] points. Mean token reductions were only 0.43%, 0.13%, 0.70% and 1.92%. These findings concern the retained rule and its parser gates, not entropy stopping generally.

Conjunction matched Uniform token IDs in 2,399 of 2,400 main pairs. Relative to Complete it lost 113 credited answers, gained none, and always consumed at least as many tokens. One Mistral ARC-C trajectory stopped before Uniform, explaining their near rather than complete identity. The observed issue is a gate mismatch: entropy stability and the current acceptable suffix often fail to coincide. When continuation changes the suffix, the rule cannot recover the earlier boundary without a latched-completion design. The follow-up included only an execution-consistency smoke check of this design; its prospective quality and latency efficacy were not evaluated.

Permissive extraction makes some policy outcomes appear similar. Mistral GSM8K's diagnostic accuracy was 57.83% under Uniform, Complete and Conjunction, while their contract accuracies were 44.00%, 57.50% and 44.00%. These answer different questions about delivered text. These computational endpoints do not establish whether a reader would accept an incomplete or contradictory response.

### 4.3. Isolated latency and shadow monitoring

Table 4 reports isolated mean end-to-end intervals. Each cell contains 60 questions with three repetitions per policy. Complete was not universally faster than Uniform. Its paired difference was +32.96 ms [22.47, 44.43] for Qwen GSM8K and +36.99 ms [27.30, 46.86] for Qwen ARC-C, approximately 0.9% in both. Mistral GSM8K's signed difference was -98.23 ms [-191.99, -19.47], or -1.96%. Mistral ARC-C's signed difference was -43.07 ms [-130.72, 27.16], crossing zero. Parsing and callback costs can offset very small output reductions.

Table 4. Mean local end-to-end interval, seconds, from isolated timing. Concurrent main-stage times are not used for latency claims. Generation-time, median, P95 and quality summaries are in the timing supplement.

| Model / task | U | C | S | E | L |
| --- | --- | --- | --- | --- | --- |
| Qwen / GSM8K | 3.603 | 3.636 | 3.679 | 3.681 | 3.693 |
| Qwen / ARC-C | 4.075 | 4.112 | 4.164 | 4.160 | 4.185 |
| Mistral / GSM8K | 5.005 | 4.907 | 4.936 | 5.077 | 5.063 |
| Mistral / ARC-C | 4.384 | 4.341 | 4.358 | 4.445 | 4.452 |

Shadow matched Complete token IDs in all 720 paired timing calls. Its additional runtime thus measures the monitoring path while holding observed output fixed. Mean overhead ranged from 16.46 to 51.18 ms (Table 5), with positive unadjusted 95% intervals in all four cells. Relative overhead was 0.38%-1.24%. These values are implementation-specific; token counts alone cannot reveal them.

Table 5. Shadow minus Complete end-to-end overhead. Intervals are paired question-cluster bootstrap 95% intervals. Relative overhead divides by the Complete mean.

| Model / task | Added ms [95% CI] | Relative |
| --- | --- | --- |
| Qwen / GSM8K | 43.76 [35.45, 53.03] | 1.20% |
| Qwen / ARC-C | 51.18 [40.33, 62.81] | 1.24% |
| Mistral / GSM8K | 28.45 [17.54, 38.21] | 0.58% |
| Mistral / ARC-C | 16.46 [5.77, 27.89] | 0.38% |

Legacy entropy reduced timing output by only 0.22-2.12 tokens per call but increased mean end-to-end latency by 1.15%-2.69% relative to Uniform. Conjunction matched Uniform IDs in all 720 timing calls and never terminated through its policy gate. Timing repeats showed no within-question output variation. These observations validate the shadow comparison while limiting any claim that fewer tokens necessarily imply shorter elapsed time.

### 4.4. Contract sensitivity and trace evidence

The apparent accuracy benefit depends on which output representation a consumer accepts (Table 6). Closure tolerance eliminates the 14 Qwen/GSM8K strict-contract wins; adding a wrapper-balance requirement reverses the Qwen/GSM8K difference under the closure-balanced rule. Last-marked-answer extraction gives zero Complete-Uniform difference in all four model/task cells. These are paired rescoring results on existing outputs and do not show that continuation is semantically harmless.

Table 6. Retrospective Complete-Uniform contract-accuracy differences, in percentage points, on 600 main questions per model/task cell. The columns use the same paired outputs under each operational parser. These alternative endpoints are sensitivity analyses, not new primary tests.

| Contract | Qwen/GSM8K | Qwen/ARC | Mistral/GSM8K | Mistral/ARC |
| --- | --- | --- | --- | --- |
| Strict terminal | 2.33 | 0.00 | 13.50 | 3.17 |
| Closure-tolerant | 0.00 | 0.00 | 13.50 | 3.17 |
| Wrapper-balanced strict | 0.00 | 0.00 | 13.50 | 3.17 |
| Closure-balanced | -2.33 | 0.00 | 13.50 | 3.17 |
| Last marked answer | 0.00 | 0.00 | 0.00 | 0.00 |

The 114 strict-contract wins were mechanically categorized as 13 LaTeX-wrapper cases, one code-fence case, 98 post-answer continuations and two loop cases. The generated prefix and last marked answer value were unchanged in the audited pairs. Two lexical disavowal or placeholder flags overlap these categories; they are lexical flags, not semantic judgments. Under the frozen conjunction settings, the trace audit found 3,116 stable non-EOS steps but no simultaneous answer-boundary opportunity and no early trigger across 240 trajectories. A more permissive exploratory combination produced 16 triggers, which does not validate a revised stopping policy or its accuracy.

### 4.5. Repeated concurrent three-GPU timing

The formal run completed the full 10,800-call scored grid across 18 workers and six waves after the separately reviewed pilot. All three output-invariant monitoring contrasts preserved both generated and returned token IDs. Their 36 model/task/session contrasts yielded 6,480 matched output-pair checks; outputs are reused across contrasts, so this is not a count of independent observations. The pilot had 240 additional matched pair checks. Each formal inference comparison still has 60 question clusters. All 36 descriptive monitoring intervals were above zero, and all 108 corresponding GPU-stratum mean differences were positive. The latter are descriptive point estimates, not 108 independent significance tests or causal GPU effects.

Table 7. Ranges of the three session-specific mean latency differences in the formal concurrent experiment. Each cell is the minimum and maximum of three point estimates, not an interval estimate. EO-C adds entropy monitoring to completion; BO-U adds boundary processing without truncation; EU-BO adds entropy monitoring without truncation. Full session estimates and descriptive bootstrap intervals are retained in the supplement.

| Model/task | Entropy EO-C (ms) | Boundary BO-U (ms) | Entropy EU-BO (ms) |
| --- | --- | --- | --- |
| Qwen/GSM8K | 43.42-48.02 | 90.74-95.89 | 41.98-44.87 |
| Qwen/ARC | 49.49-58.57 | 115.76-121.43 | 48.35-51.48 |
| Mistral/GSM8K | 22.33-25.27 | 150.46-154.96 | 20.48-25.15 |
| Mistral/ARC | 12.79-25.07 | 107.42-115.32 | 23.02-31.60 |

Boundary processing without early stopping added approximately 91-155 ms per call across the model/task/session cells. Added entropy monitoring ranged from approximately 13-59 ms on the completion path and 20-52 ms on the full-output path. The consistency of the matched-output contrasts isolates overhead from output truncation within this runtime; it does not imply an implementation-independent monitoring cost.

Table 8. Complete-Uniform mean latency differences in milliseconds, with descriptive, unadjusted 95% paired question-cluster bootstrap intervals. Negative values favor completion stopping. Every cell uses 60 questions with three within-session repetitions averaged per question; sessions reuse the same questions.

| Model/task | Session 0 | Session 1 | Session 2 |
| --- | --- | --- | --- |
| Qwen/GSM8K | 90.87 [68.19, 117.65] | 92.13 [72.34, 116.03] | 90.72 [72.06, 112.54] |
| Qwen/ARC | 110.49 [91.31, 131.74] | 114.50 [97.00, 132.79] | 118.62 [99.21, 140.28] |
| Mistral/GSM8K | 0.29 [-97.67, 88.08] | -0.10 [-98.14, 86.27] | -2.34 [-98.14, 83.51] |
| Mistral/ARC | 21.60 [-58.03, 91.23] | 26.22 [-53.36, 94.76] | 19.66 [-58.51, 86.43] |

Completion stopping did not produce a stable overall latency improvement. All Qwen session intervals were above zero, corresponding to approximately 2.5%-2.9% more elapsed time despite unchanged or slightly shortened output. Mistral point differences were near zero or positive and every interval spanned zero; these intervals permit both benefit and harm and do not establish equivalence. Mistral's shorter output therefore did not establish a net latency gain in this concurrent setting. The Complete-Uniform contrast includes output differences and is not an output-invariant overhead control. These findings complement, but are not pooled with, the earlier isolated measurements in Tables 4 and 5.

### 4.6. Validity repair and the location of token savings

A new retrospective transition audit of the original main records distinguishes interface repair from solving additional questions (Table 9). Complete produced 204 invalid-to-valid transitions and no valid-to-invalid transitions across 2,400 model–question pairs. Of the newly valid outputs, 114 matched the gold answer and 90 did not. The latter are valid deliveries of wrong answers, demonstrating why interface validity and answer correctness must be separate endpoints.

Table 9. Retrospective validity transitions, with 600 paired questions in each model/task cell. Counts refer to the frozen strict contract. They are model–question outcomes, not additional inference calls.

| Model/task | Validity gains | Validity losses | Correct repairs | Wrong repairs | Shortened |
| --- | ---: | ---: | ---: | ---: | ---: |
| Qwen / GSM8K | 28 | 0 | 14 | 14 | 28 |
| Qwen / ARC | 0 | 0 | 0 | 0 | 0 |
| Mistral / GSM8K | 129 | 0 | 81 | 48 | 129 |
| Mistral / ARC | 47 | 0 | 19 | 28 | 47 |

An exact pairwise set check found that the 204 shortened outputs were precisely the 204 validity repairs. There was no observed shortening of an already valid Uniform output. On this cohort, token savings were therefore concentrated in contract-breaking continuation rather than broad compression of the reasoning preceding an acceptable answer. This equality is an empirical property of these traces, not a general consequence of earliest-boundary stopping. Zero observed validity losses is consistent with Corollary 1 after checking the prefix and scorer assumptions; zero correctness losses remains a sample-specific observation. No pooled population significance claim is made from these model–question totals.

### 4.7. Boundary-path and net stopping effects

Table 10 applies the exact contrast decomposition from Section 2.5 to the existing formal timing means. It does not create new timing observations or confidence intervals. In Qwen, the net slowdown is close to the output-matched boundary-path cost. For Mistral, the boundary-arm contrast offsets much of that cost, yet the original net-effect intervals still span benefit and harm. A near-zero net effect therefore does not by itself show that detecting an earlier boundary saved no work.

Table 10. Ranges across the three session point estimates, in milliseconds. B = BO-U; D = C-U; R_L = BO-C = B-D. Ranges are not uncertainty intervals; no interval is assigned to the derived R_L.

| Model/task | Boundary path B | Net completion D | Boundary-arm difference R_L |
| --- | ---: | ---: | ---: |
| Qwen / GSM8K | 90.74 to 95.89 | 90.72 to 92.13 | -0.14 to 5.17 |
| Qwen / ARC | 115.76 to 121.43 | 110.49 to 118.62 | 2.81 to 5.27 |
| Mistral / GSM8K | 150.46 to 154.96 | -2.34 to 0.29 | 152.03 to 155.05 |
| Mistral / ARC | 107.42 to 115.32 | 19.66 to 26.22 | 81.20 to 93.72 |

The small negative R_L estimate in one Qwen/GSM8K session illustrates why this residual must not be labeled isolated saved GPU time. Output-path differences and timing noise remain. These descriptive values motivate optimizing the detection path, but do not predict the performance of an unmeasured native or incremental implementation. New raw timing records would be required to estimate paired uncertainty for R_L.

## 5. Discussion

### 5.1. Meaning of the quality differences

The main accuracy differences arise because the interface accepts a marked final line and rejects later non-whitespace continuation. Stopping preserves an accepted representation; it does not demonstrate additional solved problems. The retrospective contracts make this dependence explicit: closure handling removes the Qwen/GSM8K strict-contract gain, whereas last-marked-answer extraction removes every net difference. Wrapper-balance requirements can instead penalize a truncated response. These operational alternatives are finite parser rules rather than semantic or document-validity oracles. A richer structured-output interface could change the observed benefit, while a tolerant consumer may accept continuation; neither possibility establishes that the continuations are correct or harmless.

The result nevertheless matters to systems enforcing a terminal field, parser or protocol. A monitor intended to improve reliability can harm delivery if it waits past the accepted boundary. It should be evaluated jointly with the consumer's parser, including cases where completion becomes true and subsequently false. Our evidence supports this implementation check, without establishing that the tested contract is optimal for deployment.

### 5.2. What the constrained-decoding perspective contributes

The formalization distinguishes modifying allowed content from controlling return time. Complete can enforce validity when its online certificate fires, while leaving continuation probabilities unchanged; it cannot force the decoder to reach that certificate. Its empirical benefit must therefore be conditioned on the contract and accompanied by fallback failures and premature-commitment risks. This is a limited termination-control mechanism, not grammar enforcement or semantic verification.

The stronger empirical distinction is between preserving a delivery contract and improving its content. The transition audit supplies the missing denominator: 204 validity repairs include 114 gold-correct and 90 gold-incorrect returns. The shared set of repairs and shortened trajectories also localizes the token benefit to continuation after an accepted field. These observations make the interpretation testable rather than relying only on a formal stopping description. They are bounded findings of the studied models, tasks and contract, not universal properties of constrained decoding.

The contribution is a reproducible evaluation discipline combining these transitions with contract sensitivity and matched-output runtime controls. Its value is exposing endpoint and cost confounding that an aggregate accuracy/token summary would conceal. Establishing a distinct new decoding algorithm would additionally require a new mechanism and direct comparisons with practical alternatives. The present data do not supply that comparison.

### 5.3. Interpreting monitoring cost

The shadow arm separates two otherwise confounded effects: changing generation length and paying to observe generation. Entropy monitoring here adds a small measurable latency cost without changing a token. Legacy entropy combines that cost with very small token savings and substantially lower contract accuracy. This configuration offers no efficiency advantage for the measured endpoint. The result does not rule out fused monitors, asynchronous estimates, less frequent checks or different stopping conditions.

A useful evaluation sequence is to verify a shadow arm's token-path identity, measure its overhead in the intended execution mode, and compare the stopping arm against both shadow and no-monitor controls. This diagnoses cost in the tested system; it is not a physical scheduling algorithm. A token allowance specifies neither GPU allocation nor FLOPs, energy, monetary cost or throughput. Peak allocated memory includes model and cache storage and cannot supply these missing measurements.

The boundary callback transfers generated IDs to the host and decodes the full prefix at each step. Under an approximately linear per-prefix processing cost, this entails quadratic cumulative prefix work in output length, in addition to synchronization. Entropy observation adds another vocabulary-wide and synchronization path. The measured overhead is therefore not a lower bound for native stop sequences, incremental detection or optimized grammar engines. A practical low-overhead implementation comparison remains an important extension if performance superiority is claimed.

The concurrent follow-up further separates the cost of processing a boundary from the incremental cost of entropy. BO-U changes the callback path without shortening the output, whereas C-U combines that overhead with any token savings. Their different results explain why fewer tokens need not reduce elapsed time. The three repeated sessions show consistent positive monitor costs under this implementation, while the net completion effect remains model- and condition-dependent. Positive descriptive intervals across the 36 monitor contrasts should not be read as multiplicity-adjusted confirmatory tests, and ranges of session means should not be read as confidence bounds.

### 5.4. Generalization limits and further validation

The study contains two approximately 7B instruction-tuned models, two tasks, one allowance, one question-sampling/order seed, greedy decoding and batch size one on A800 hardware. The models share questions, and all timing cohorts reuse subsets of the accuracy cohort. Three follow-up sessions add repeated measurements under a concurrent deployment condition, not independent datasets or a budget sweep. The benchmarks do not represent long-horizon agents, tool calls, concurrent service queues, speculative decoding or reasoning-model budget forcing. Model order was fixed in the original experiment and only partly varied in the follow-up. Session-level drift, host contention and different timer boundaries prevent direct attribution of cross-experiment differences to concurrency. Small effects may differ under another runtime.

Evaluation is limited to explicitly specified parser contracts and measured runtime. No annotator-based endpoint is part of this study. The reported accuracy changes must therefore be interpreted as changes in contract-valid correctness, not estimates of general semantic answer quality.

The record now includes retrospective richer-contract and trace sensitivity analyses and an executed control for boundary processing, but it contains no prospective quality evaluation of latched completion, revised stopping thresholds or a cheaper monitoring implementation. The exploratory trace triggers do not authorize a new accuracy claim. The single-allowance design cannot estimate a budget-response function or validate dynamic allocation. Public release and an independent rerun would strengthen external reproducibility beyond the local computational checks.

### 5.5. Historical JANUS evidence

Historical JANUS results motivated these controls and are not pooled with the prospective cohort. The earlier audit found TCJS/TokOnly identity in 3,000 paired records and identical CompRoute results across nominal allowances 64, 128 and 256. A separate offline tokenizer-based reconstruction indicated that all three allowances were clamped to an effective cap of 64. Historical logs did not record every effective cap directly, and the reconstruction used a different tokenizer patch version, as documented in the archived audit. Those findings diagnose implementation naming and cap transformations, not scheduling efficacy. Historical prompts, scoring and sampling differ. Preserving those artifacts supports accountability; counting them as prospective replications would be inappropriate.

## 6. Conclusions

Contract-aware termination preserves validity relative to an EOS-or-cap baseline when its certificate is sound and the generated prefix is shared; it does not guarantee reaching a valid answer or preserving correctness. The existing main records show 204 validity repairs, comprising 114 correct and 90 wrong answers, with all shortened outputs confined to that repair set. Alternative contracts change or eliminate the measured advantage. Output-matched follow-up controls identify positive implementation-path costs, while an algebraic decomposition shows why monitoring overhead and net stopping effects need separate interpretation. The empirical contribution is the joint audit of validity transitions, endpoint sensitivity and runtime costs. It is an interface-specific case study, not evidence of a new grammar decoder, reasoning improvement or universal acceleration. Complete access to the new raw timing archive remains necessary for independent statistical reproduction.

## Data and code availability

Complete local archives contain frozen protocols, revision pins, input manifests, raw outputs, attempt/completion receipts, environment snapshots and analysis scripts. Downloaded bundles were verified before the rental instances were shut down. The 24 October revision adds contract sensitivity, parser provenance, repeated three-GPU timing results, dated offline checks and editable manuscript sources while preserving the frozen experimental files. The supplement includes all 48 formal timing contrasts and the 20 contract-sensitivity cells. A public repository/archive URL and, if obtained, DOI must be inserted after authors approve release and verify redistribution permissions. No public deposit is claimed. Release material must exclude credentials and private operational or personal information.

## Declarations requiring author confirmation

**Funding.** Pending confirmation of actual support, grant identifiers and funders' roles. Absence of funding is not assumed.

**Competing interests.** Pending author confirmation, including employment and support relevant to this work. The supplied affiliation is retained and is not a verified disclosure.

**Author contributions.** Pending a factual account of contributions and final approval. Supplied author order and correspondence details are retained for confirmation.

**AI-assisted work.** AI assistance was used in manuscript revision, code inspection and modification, experiment operation, computational analysis and document preparation. Authors must verify the precise account against actual use and current journal disclosure fields. All reported evaluation endpoints are computational; no annotator-based result is claimed. Human authors remain responsible for methods, data, interpretations and final text.

## References

Clark P, Cowhey I, Etzioni O, Khot T, Sabharwal A, Schoenick C, Tafjord O. 2018. Think you have solved question answering? Try ARC, the AI2 Reasoning Challenge. arXiv:1803.05457. <https://arxiv.org/abs/1803.05457>

Cobbe K, Kosaraju V, Bavarian M, Chen M, Jun H, Kaiser L, Plappert M, Tworek J, Hilton J, Nakano R, Hesse C, Schulman J. 2021. Training verifiers to solve math word problems. arXiv:2110.14168. <https://arxiv.org/abs/2110.14168>

Han T, Wang Z, Fang C, Zhao S, Ma S, Chen Z. 2025. Token-budget-aware LLM reasoning. Findings of the Association for Computational Linguistics: ACL 2025, 24842-24855. DOI: 10.18653/v1/2025.findings-acl.1274. <https://aclanthology.org/2025.findings-acl.1274/>

Mistral AI. 2024. Mistral-7B-Instruct-v0.3 model card. <https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3>

Muennighoff N, Yang Z, Shi W, Li XL, Fei-Fei L, Hajishirzi H, Zettlemoyer L, Liang P, Candes E, Hashimoto T. 2025. s1: Simple test-time scaling. arXiv:2501.19393, version 3. <https://arxiv.org/abs/2501.19393v3>

Wang J, Jain S, Zhang D, Ray B, Kumar V, Athiwaratkun B. 2024. Reasoning in token economies: Budget-aware evaluation of LLM reasoning strategies. Proceedings of EMNLP 2024, 19916-19939. DOI: 10.18653/v1/2024.emnlp-main.1112. <https://aclanthology.org/2024.emnlp-main.1112/>

Yang A, Yu B, Li C, Liu D, Huang F, Huang H, Jiang J, Tu J, Zhang J, Zhou J, Lin J, et al. 2025. Qwen2.5-1M technical report. arXiv:2501.15383. <https://arxiv.org/abs/2501.15383>

Yu Q, Zheng Z, Song S, Li Z, Xiong F, Tang B, Chen D. 2025. xFinder: Large language models as automated evaluators for reliable evaluation. ICLR 2025; arXiv:2405.11874, version 3. <https://arxiv.org/abs/2405.11874>

XGrammar project. 2026. Official project documentation, README, commit `e085851aec8f417924be5f460d1e038cac0e3bd5`. <https://github.com/mlc-ai/xgrammar/blob/e085851aec8f417924be5f460d1e038cac0e3bd5/README.md> (accessed 26 October 2026).

Outlines project. 2026. Official project documentation, README, commit `c52af8472c6fe8a607a733ec11b709476af77a96`. <https://github.com/dottxt-ai/outlines/blob/c52af8472c6fe8a607a733ec11b709476af77a96/README.md> (accessed 26 October 2026).

Hokamp C, Liu Q. 2017. Lexically Constrained Decoding for Sequence Generation Using Grid Beam Search. Proceedings of ACL 2017 (Volume 1: Long Papers), 1535–1546. DOI: 10.18653/v1/P17-1141. <https://aclanthology.org/P17-1141/>.

Geng S, Josifoski M, Peyrard M, West R. 2023. Grammar-Constrained Decoding for Structured NLP Tasks without Finetuning. Proceedings of EMNLP 2023, 10932–10952. DOI: 10.18653/v1/2023.emnlp-main.674. <https://aclanthology.org/2023.emnlp-main.674/>.

Hugging Face. 2025. Transformers v4.48.2: generation stopping criteria, including StopStringCriteria. Versioned implementation documentation. <https://github.com/huggingface/transformers/blob/v4.48.2/src/transformers/generation/stopping_criteria.py> (accessed 26 October 2026).
