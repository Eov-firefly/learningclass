# v8.6 新机制研究稿与有限语言原型

这是一版研究方案及可测试原型，不是已证明“新范式优先权”或已完成真实模型实验的投稿终稿。v8.5已有实证稿保留为独立版本。

## 文件入口

- manuscript.md / main.tex / main.pdf：新机制研究稿；原十张数据表明确标为历史动机。
- 修改判断_zh.md：实质改动、退化情形与创新性判断。
- 实验验证方案_zh.md：必要对照、消融、指标及完整失败记录要求。
- prototype/controller.py：预算可行token语言、绑定及提交状态机。
- prototype/hf_adapter.py：真实Transformers generate集成的draft-to-wrapper原型。
- prototype/finite_record.py：固定结构前缀、选定字段绑定、未绑定字段由模型选择的有限完成接口。
- prototype/reference_contracts.py：原v8有限wrapper规则，**不是完整Markdown/LaTeX语法**。
- tests/、TEST_REPORT.json：受控CPU验证与范围说明。
- historical_evidence/：旧数据回顾性分析及输入来源，不能当作新方法结果。

## 复现控制测试

可复用此前torch2.6/Transformers4.48.2环境。新建CPU环境时：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements-prototype.txt
python -m unittest discover -s tests -v
```

测试不下载权重。小型随机GPT2加受控logits验证的是状态/掩码行为，没有提供真实任务准确率或加速证据。

## 集成实际模型

`prototype.hf_adapter.run_one(model, tokenizer, prompt, kind, choices, cap, reserve, device)` 接收已载入模型。它不接收gold答案。返回COMMIT或ABSTAIN，保留生成文本、实际token、forward次数、绑定值、模式切换及原型耗时。只有COMMIT才有committed_text。

`prototype.finite_record.complete_finite_record(...)` 接收调用方提供的前缀、有限候选后缀、接受谓词和绑定保持谓词。手工后缀集合不是通用grammar编译器；前缀生成不在此接口的测量范围内。集成失败可能抛出ConstraintFailure，不能静默当成有效输出。

不要直接将原型计时与旧稿的正式计时混合。真实比较前应统一基线、编译时间、评分边界、失败处理和隔离环境，并保留所有请求。GPU专属路径、生产性能和通用编译器未在本机验证。

## 不能省略的基线

controller.shortest_verified_repair使用相同有限修复语言、不调用新模型。只要剩余任务是格式闭合，它可能提供相同答案与接受性，并使用更短后缀。这正是区分“实质算法价值”与“复杂化修复”的必要比较。

## 文档构建

安装Pandoc、pdfLaTeX后，在本目录运行 `python build.py`。Markdown为编辑源，TeX/PDF为派生输出。当前新方法研究稿不包含未开展的人工评审材料。
