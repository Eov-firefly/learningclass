# JANUS v5.1 main results read-only audit (2026-10-22)

Evidence paths below are relative to the v6 package root. Frozen source: `results/revision_v5_1`, `experiments/revision_v3/protocol.json`, and `experiments/revision_v3/core.py`; provenance is recorded in `output/postrun/source_provenance.json`. The preserved original backup remains unchanged.

Human semantic annotation is **not completed**; prepared blank forms and separate rater packages are in `output/postrun/human_audit`, with organizer instructions in `output/revision/semantic_audit_instructions_zh.md`.

## Verification

- Main rows: 14,400, exactly 600 questions × 6 strategies × 2 tasks × 2 models at cap 512; 14,400 unique job IDs.
- Recomputed every frozen `score_output` field using the actual input ARC `allowed_choices`: 0 differences. This qualification matters: one ARC item has no E choice; its five terminal E outputs must remain invalid.
- Recomputed all 24 summary records (all metrics): exact equality to `main-analysis.json`.
- Recomputed all four mechanism audit records: exact equality; all 2,400 matched model-question blocks pass uniform-token-prefix, Complete/shadow token equality and conjunction-length ordering.
- Independently inverted binomial CDFs to check all 20 paired binary accuracy confidence intervals: maximum absolute difference 1.67e-15 from stored JSON. This check does not depend on SciPy.
- Paired continuous intervals quoted below are the frozen JSON results. `analyze.paired_contrasts` defaults to 5,000 bootstrap replicates and passes this argument to `core.paired_ci`, overriding that lower-level function’s 2,000 default. Both formal main/timing summarization use this entry point.

## All main cells

Accuracy and valid are **terminal-contract endpoints**, not human semantic accuracy. Legacy is a diagnostic parser endpoint. All percentages use 600 as denominator. Mean tokens counts generated output tokens.

|Model|Task|Policy|Contract accuracy %|Valid %|Legacy accuracy %|Mean tokens|Tokens / credited correct|
|---|---|---|---:|---:|---:|---:|---:|
|mistral|arc|complete|54.0000|76.3333|68.0000|178.828333|331.16358024691357|
|mistral|arc|entropy_complete|51.0000|68.6667|68.1667|182.903333|358.63398692810455|
|mistral|arc|entropy_observe|54.0000|76.3333|68.0000|178.828333|331.16358024691357|
|mistral|arc|legacy_entropy|34.1667|46.6667|68.1667|180.048333|526.9707317073171|
|mistral|arc|marker|0.0000|0.0000|50.1667|173.448333|undefined|
|mistral|arc|uniform|50.8333|68.5000|68.1667|183.578333|361.1377049180328|
|mistral|gsm8k|complete|57.5000|95.6667|57.8333|223.748333|389.12753623188405|
|mistral|gsm8k|entropy_complete|44.0000|74.1667|57.8333|229.033333|520.530303030303|
|mistral|gsm8k|entropy_observe|57.5000|95.6667|57.8333|223.748333|389.12753623188405|
|mistral|gsm8k|legacy_entropy|32.0000|54.1667|46.0000|227.423333|710.6979166666666|
|mistral|gsm8k|marker|0.0000|0.0000|3.6667|219.038333|undefined|
|mistral|gsm8k|uniform|44.0000|74.1667|57.8333|229.033333|520.530303030303|
|qwen|arc|complete|87.6667|96.5000|90.5000|191.548333|218.49619771863118|
|qwen|arc|entropy_complete|87.6667|96.5000|90.5000|191.548333|218.49619771863118|
|qwen|arc|entropy_observe|87.6667|96.5000|90.5000|191.548333|218.49619771863118|
|qwen|arc|legacy_entropy|62.6667|71.0000|90.5000|191.293333|305.25531914893617|
|qwen|arc|marker|0.0000|0.0000|71.6667|189.595000|undefined|
|qwen|arc|uniform|87.6667|96.5000|90.5000|191.548333|218.49619771863118|
|qwen|gsm8k|complete|70.1667|97.1667|71.0000|180.910000|257.8289786223278|
|qwen|gsm8k|entropy_complete|67.8333|92.5000|71.0000|181.046667|266.8992628992629|
|qwen|gsm8k|entropy_observe|70.1667|97.1667|71.0000|180.910000|257.8289786223278|
|qwen|gsm8k|legacy_entropy|53.8333|74.5000|58.3333|180.270000|334.86687306501545|
|qwen|gsm8k|marker|0.0000|0.0000|6.0000|176.446667|undefined|
|qwen|gsm8k|uniform|67.8333|92.5000|71.0000|181.046667|266.8992628992629|

## Primary Complete − Uniform paired contrasts

Accuracy intervals: conservative simultaneous Clopper–Pearson paired marginals; alpha=0.0125 in each of 4 prespecified cells, hence per-cell 98.75% intervals and ≥95% family coverage by Bonferroni. The null discordance cell correctly retains uncertainty. Token intervals: unadjusted 95% paired question bootstrap, 5,000 replicates, seed 20261019.

|Model|Task|Accuracy difference pp [adjusted interval]|Wins / losses|Mean token difference [95% CI]|Relative tokens %|
|---|---|---:|---:|---:|---:|
|mistral|arc|+3.166667 [0.590719, 5.657314]|19 / 0|-4.750000 [-7.508333, -2.623333]|-2.587451|
|mistral|gsm8k|+13.500000 [8.983427, 17.723075]|81 / 0|-5.285000 [-6.226667, -4.388333]|-2.307524|
|qwen|arc|+0.000000 [-0.956780, 0.956780]|0 / 0|+0.000000 [0.000000, 0.000000]|+0.000000|
|qwen|gsm8k|+2.333333 [0.031956, 4.571111]|14 / 0|-0.136667 [-0.188333, -0.088333]|-0.075487|

The prespecified 2 pp noninferiority criterion is supported in all four cells. Observed equality for Qwen ARC is not zero population uncertainty: its primary interval is ±0.956780 pp. At margin 0, that interval does not establish noninferiority. Do not label a no-loss point estimate as universal equality.

## Secondary entropy_complete − entropy_observe (= Complete output)

The following accuracy intervals are ordinary unadjusted 95% intervals; do not mix them with the adjusted primary family.

|Model|Task|Contract accuracy difference pp [95% CI]|Wins / losses|Mean token difference [95% CI]|
|---|---|---:|---:|---:|
|mistral|arc|-3.000000 [-4.962460, -0.924449]|0 / 18|+4.075000 [2.396667, 6.356667]|
|mistral|gsm8k|-13.500000 [-16.937813, -9.797043]|0 / 81|+5.285000 [4.390000, 6.228333]|
|qwen|arc|+0.000000 [-0.727677, 0.727677]|0 / 0|+0.000000 [0.000000, 0.000000]|
|qwen|gsm8k|-2.333333 [-4.125836, -0.441188]|0 / 14|+0.136667 [0.088333, 0.188333]|

## Secondary legacy_entropy − Uniform

|Model|Task|Contract accuracy difference pp [unadjusted 95% CI]|Wins / losses|Relative tokens %|
|---|---|---:|---:|---:|
|mistral|arc|-16.666667 [-20.542274, -12.482649]|1 / 101|-1.922885|
|mistral|gsm8k|-12.000000 [-15.295375, -8.459308]|0 / 72|-0.702954|
|qwen|arc|-25.000000 [-29.194176, -20.392728]|0 / 150|-0.133126|
|qwen|gsm8k|-14.000000 [-17.482379, -10.245912]|0 / 84|-0.428987|

## Mechanism

|Model|Task|All prefix/shadow/order failures|EC = Uniform (of 600)|Complete = Uniform|EC longer than Complete|Complete correct / EC incorrect|Complete valid / EC invalid|
|---|---|---:|---:|---:|---:|---:|---:|
|mistral|arc|0 / 0 / 0|599|553|47|18|46|
|mistral|gsm8k|0 / 0 / 0|600|471|129|81|129|
|qwen|arc|0 / 0 / 0|600|600|0|0|0|
|qwen|gsm8k|0 / 0 / 0|600|572|28|14|28|

- All outputs from every tested policy are prefixes of the corresponding Uniform token sequence; Complete and entropy_observe token sequences are equal on all 2,400 matched cases. EC stops no earlier than Complete on all 2,400 cases.
- EC is token-for-token equal to Uniform on 2,399/2,400 cases. There is exactly one EC policy-trigger stop (Mistral ARC); all remaining EC records end at EOS or cap. This is empirical evidence about this frozen greedy, cap-512, threshold-0.01 conjunction; it is not a general impossibility claim about entropy stopping.
- Complete has 114 wins and 0 losses versus Uniform across the four cells (19+81+0+14). Every one of the 114 winning Uniform records has `prediction=None` under the terminal contract. Thus the observed credited-accuracy gains are delivery/formatting gains, not a demonstration that reasoning or semantic task correctness improved. The same underlying greedy path was used.
- Complete versus EC has 113 wins and 0 losses. There are 203 Complete-valid/EC-invalid pairs (46+129+0+28); the reverse count is zero. Some Complete prefixes contain a wrong value, explaining why validity improvements exceed credited-accuracy improvements.
- In Qwen GSM8K all 14 Complete wins versus Uniform are 13 closing LaTeX `\]` suffixes and one closing code-fence suffix; the correct number remains visible in the full Uniform output. Never present this as 14 extra semantic successes.
- Contract limitation: `answer()` constrains the suffix after the last line-start `####`; it does not check whether preceding code fences or LaTeX delimiters are closed. Complete prefixes inside an unclosed `\[` or code fence can therefore be contract-valid, while a normal closing delimiter makes the later full output invalid. State this endpoint explicitly as the terminal-marker contract; do not equate it with complete formatting, semantic correctness or production usability.
- The one EC policy stop is Mistral ARC `arc:dfbd30efcc47025d4d382000`: Complete ends at token 57, EC at 107, Uniform cap at 512. Complete and EC both credit D; Uniform repeats `(Newline)` and `#### D` and ends after `(Newline)`, so its terminal parser fails. This explains the 19 vs 18 difference between Mistral ARC primary wins and EC losses.

## Trace examples (not human annotations)

### mistral / gsm8k / gsm8k:2fb0b11479f531465fb16099

Gold: 30. Complete: tokens=225, prediction=30, valid=True, correct=True. EC: tokens=242, prediction=None, valid=False, correct=False. Uniform tokens=242.
Raw JSONL lines Complete 2371; EC 5729; Uniform 2323, in `results/revision_v5_1/mistral.main.s0-of-1.jsonl`.

Complete tail:

````text
 building is occupied. So, the number of occupied units is:
   Occupied Units = Total Units * (3/4)
   Occupied Units = 120 * (3/4) = 90

3. To find the number of unoccupied units, we subtract the number of occupied units from the total number of units:
   Unoccupied Units = Total Units - Occupied Units
   Unoccupied Units = 120 - 90 = 30

#### 30

````

EC continuation after Complete text:

````text

So, there are 30 unoccupied units in the building.
````

### mistral / arc / arc:ec049177a2838797ca3dd2a4

Gold: A. Complete: tokens=144, prediction=A, valid=True, correct=True. EC: tokens=211, prediction=None, valid=False, correct=False. Uniform tokens=211.
Raw JSONL lines Complete 1874; EC 339; Uniform 6387, in `results/revision_v5_1/mistral.main.s0-of-1.jsonl`.

Complete tail:

````text
 the egg cell. This requires a tail for swimming, as well as a head containing the genetic material.

On the other hand, an egg cell (not any of the other options) is not designed for movement. Instead, it is large and non-motile, providing a store of nutrients for the developing embryo. It also contains a large amount of genetic material.

#### A

````

EC continuation after Complete text:

````text

(Note: The other options are incorrect because B is not accurate as an egg cell does not divide into sperm cells; C is not accurate as the sperm cell moves towards the egg, not the other way around; and D is not accurate as a sperm cell combines with one egg cell, not many.)
````

### qwen / gsm8k / gsm8k:1f010f3feb941016966fe351

Gold: 57500. Complete: tokens=255, prediction=57500, valid=True, correct=True. EC: tokens=258, prediction=None, valid=False, correct=False. Uniform tokens=258.
Raw JSONL lines Complete 159; EC 2616; Uniform 353, in `results/revision_v5_1/qwen.main.s0-of-1.jsonl`.

Complete tail:

````text
weekly salary:
\[ 700 \, \text{dollars/week} + 450 \, \text{dollars/week} = 1150 \, \text{dollars/week} \]

Now, calculate her annual salary by multiplying her weekly salary by the number of weeks she works in a year:
\[ 1150 \, \text{dollars/week} \times 50 \, \text{weeks/year} = 57500 \, \text{dollars/year} \]

The final answer is:
\[
#### 57500

````

EC continuation after Complete text:

````text
\]
````

### qwen / gsm8k / gsm8k:14b1791a3989555b3c4ae222

Gold: 10. Complete: tokens=182, prediction=10, valid=True, correct=True. EC: tokens=184, prediction=None, valid=False, correct=False. Uniform tokens=184.
Raw JSONL lines Complete 546; EC 5826; Uniform 4871, in `results/revision_v5_1/qwen.main.s0-of-1.jsonl`.

Complete tail:

````text
is:
\[ 40 - 20 = 20 \]

Next, we know that 20 of the 50 floral shirts have buttons. Therefore, the number of floral shirts with no buttons is:
\[ 50 - 20 = 30 \]

We need to find how many more floral shirts with no buttons there are than white shirts with no collars. This is calculated as:
\[ 30 - 20 = 10 \]

Thus, the final answer is:
```
#### 10

````

EC continuation after Complete text:

````text
```
````

### mistral / arc / arc:dfbd30efcc47025d4d382000

Gold: D. Complete: tokens=57, prediction=D, valid=True, correct=True. EC: tokens=107, prediction=D, valid=True, correct=True. Uniform tokens=512.
Raw JSONL lines Complete 5159; EC 4064; Uniform 3366, in `results/revision_v5_1/mistral.main.s0-of-1.jsonl`.

Complete tail:

````text
Alicia could use a thermometer to measure the change in temperature (D) to get a more accurate conclusion. This would provide quantitative data about the heat produced during the reaction, which would support her conclusion that a reaction occurred and gave off heat.

#### D

````

EC continuation after Complete text:

````text

(Newline)

#### D

(Newline)

#### D

(Newline)

#### D

(Newline)

#### D

(Newline)

#### D

````

## Recommended result narrative

“On the frozen 512-token greedy evaluation, Complete reduced mean output length by 0–2.59% relative to EOS/cap while preserving the prespecified 2 pp noninferiority margin for terminal-contract accuracy in all four model–task cells. Credited accuracy increased in three cells because stopping at a completed answer line prevented subsequent text from violating the terminal contract. These endpoint improvements do not establish higher semantic answer accuracy. The entropy conjunction was identical to EOS/cap in 2,399 of 2,400 matched cases and used more tokens than Complete in the other affected traces; the shadow control matched Complete output in every case, permitting a separate overhead comparison in the isolated timing experiment.”

Use the shadow timing results from the separate timing audit, not main-stage wall times, to quantify monitoring overhead. Do not claim output-token savings automatically establish GPU, energy or billed-cost savings.

## Claims to avoid

- Any universal conclusion that entropy stopping is useless, Complete is semantically superior, or the experiment improves reasoning.
- “Validated agent scheduling/framework” or DAG/physical GPU scheduling claims. This is answer-contract stopping evaluation of single-model generations under specified tasks.
- Treating legacy numeric or ARC letter-parser accuracy as independent semantic validation. ARC diagnostic parser simply takes the last standalone A–E and can choose a letter in appended explanatory text.
- Treating 14,400 calls as 14,400 independent questions, or timing repeats as new question samples. The main unit is the matched question within a model–task cell. Models share the task cohort.
- Claiming human semantic audit, DAG/allocation/transfer experiments or held-out budget scaling results are completed.
