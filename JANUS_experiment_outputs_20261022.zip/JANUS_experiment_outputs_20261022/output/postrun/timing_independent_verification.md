# JANUS v5.1 timing results independently verified for v6

Read-only verification of the frozen, locally verified completed server backup. No inference, protocol changes, or edits to frozen files. Independently recomputed 24 summary cells, all 80 saved paired estimates and percentile-bootstrap intervals, unique job IDs, the full 4,320-call timing grid, repeat invariance, output-prefix paths, shadow equality, and Complete/conjunction length ordering; all matched to numerical tolerance 1e-12. Supplemental direct conjunction–Complete contrasts below are computed outside the frozen analysis and labelled accordingly.

## Sampling, inference and units

Each model × dataset cell contains 60 held-out questions, 3 repeated hardware runs per question and policy, and 6 policies (180 measured calls per policy; 4,320 total). The timing questions are the first 60 questions of the already fixed test cohort, overlapping the main-stage cohort; they are not an independent accuracy-validation cohort. All calls use cap 512 generated tokens, batch size 1, greedy decoding, the fixed entropy threshold 0.01 (legacy entropy threshold 0.05). Output token paths are identical across the 3 repeats in all 24 cells. Accuracy here is descriptive and contract-aware, with the main stage supplying primary accuracy evidence.

Time values in the following summary table are seconds; tokens are generated output tokens. P95 is the nearest-rank empirical 95th percentile over 180 individual calls (rank 171), not a CI or a percentile of per-question means. Mean generation latency was recomputed from JSONL; the frozen summary exports generation P50/P95 but not its mean. All 3 repeats are averaged within each question before paired inference (60 independent sampling clusters per cell). Saved intervals use 5,000 paired question-cluster bootstrap resamples, seed 20261019, percentile 95% CI; timing contrasts are not multiplicity-adjusted. These CIs describe this question subset and hardware session; they do not provide 180 independent accuracy observations.

## Full timing table

| Model | Task | Policy | Accuracy % | Valid % | Tokens | Gen mean s | Gen P50 s | Gen P95 s | E2E mean s | E2E P95 s | Output tokens/correct |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| qwen | gsm8k | uniform | 65.00 | 95.00 | 172.300 | 3.600871 | 3.318313 | 7.634782 | 3.602546 | 7.637252 | 265.077 |
| qwen | gsm8k | marker | 0.00 | 0.00 | 167.717 | 3.529281 | 3.260882 | 7.610464 | 3.530802 | 7.612742 | undefined (0 correct) |
| qwen | gsm8k | complete | 65.00 | 98.33 | 172.200 | 3.633973 | 3.351358 | 7.735253 | 3.635511 | 7.737738 | 264.923 |
| qwen | gsm8k | legacy_entropy | 51.67 | 81.67 | 171.867 | 3.691410 | 3.430993 | 7.728127 | 3.692955 | 7.730492 | 332.645 |
| qwen | gsm8k | entropy_observe | 65.00 | 98.33 | 172.200 | 3.677728 | 3.400212 | 7.892507 | 3.679266 | 7.894814 | 264.923 |
| qwen | gsm8k | entropy_complete | 65.00 | 95.00 | 172.300 | 3.679446 | 3.416302 | 7.865087 | 3.680990 | 7.867367 | 265.077 |
| qwen | arc | uniform | 83.33 | 95.00 | 194.850 | 4.073715 | 4.191358 | 6.459914 | 4.075486 | 6.462363 | 233.820 |
| qwen | arc | marker | 0.00 | 0.00 | 192.950 | 4.063997 | 4.203170 | 6.555380 | 4.065598 | 6.557589 | undefined (0 correct) |
| qwen | arc | complete | 83.33 | 95.00 | 194.850 | 4.110867 | 4.186054 | 6.595748 | 4.112475 | 6.598028 | 233.820 |
| qwen | arc | legacy_entropy | 61.67 | 73.33 | 194.633 | 4.183425 | 4.336147 | 6.780193 | 4.185027 | 6.782254 | 315.622 |
| qwen | arc | entropy_observe | 83.33 | 95.00 | 194.850 | 4.162047 | 4.284020 | 6.668163 | 4.163658 | 6.670377 | 233.820 |
| qwen | arc | entropy_complete | 83.33 | 95.00 | 194.850 | 4.158869 | 4.296307 | 6.757527 | 4.160475 | 6.759602 | 233.820 |
| mistral | gsm8k | uniform | 45.00 | 68.33 | 223.700 | 5.003352 | 4.496202 | 9.576334 | 5.005330 | 9.579246 | 497.111 |
| mistral | gsm8k | marker | 0.00 | 0.00 | 212.383 | 4.793088 | 4.093244 | 9.368294 | 4.794830 | 9.370758 | undefined (0 correct) |
| mistral | gsm8k | complete | 61.67 | 93.33 | 217.167 | 4.905317 | 4.173444 | 9.523953 | 4.907100 | 9.526458 | 352.162 |
| mistral | gsm8k | legacy_entropy | 33.33 | 50.00 | 221.583 | 5.061089 | 4.491418 | 9.800194 | 5.062879 | 9.802803 | 664.750 |
| mistral | gsm8k | entropy_observe | 61.67 | 93.33 | 217.167 | 4.933795 | 4.213262 | 9.613469 | 4.935554 | 9.616128 | 352.162 |
| mistral | gsm8k | entropy_complete | 45.00 | 68.33 | 223.700 | 5.075126 | 4.580109 | 9.687660 | 5.076903 | 9.690392 | 497.111 |
| mistral | arc | uniform | 51.67 | 68.33 | 196.000 | 4.382609 | 4.485871 | 6.859417 | 4.384489 | 6.861870 | 379.355 |
| mistral | arc | marker | 0.00 | 0.00 | 188.617 | 4.247958 | 4.273863 | 6.839602 | 4.249618 | 6.841772 | undefined (0 correct) |
| mistral | arc | complete | 56.67 | 76.67 | 192.017 | 4.339736 | 4.317481 | 6.939448 | 4.341417 | 6.941696 | 338.853 |
| mistral | arc | legacy_entropy | 35.00 | 40.00 | 195.150 | 4.450279 | 4.548629 | 6.985684 | 4.451950 | 6.987776 | 557.571 |
| mistral | arc | entropy_observe | 56.67 | 76.67 | 192.017 | 4.356199 | 4.416564 | 7.000102 | 4.357875 | 7.002607 | 338.853 |
| mistral | arc | entropy_complete | 51.67 | 68.33 | 196.000 | 4.443588 | 4.567528 | 6.965484 | 4.445265 | 6.967702 | 379.355 |

## Prespecified paired shadow-monitor overhead

entropy_observe minus complete: the stopping rule and exact generated token IDs are shared, while entropy_observe additionally computes full-vocabulary entropy each decoding step. Every one of the 720 matched question-repeat pairs passes shadow equality and greedy-prefix validation. This permits the narrow interpretation of an incremental monitor cost on this implementation. E2E and generation measurements include the monitor’s per-token GPU operations and host scalar extraction.

| Model/task | E2E mean delta ms [95% CI] | Relative mean change % | Generation mean delta ms [95% CI] | Accuracy delta / token delta |
|---|---:|---:|---:|---|
| qwen/gsm8k | 43.755 [35.451, 53.029] | 1.204 | 43.755 [35.449, 53.029] | 0 / 0 |
| qwen/arc | 51.183 [40.331, 62.806] | 1.245 | 51.180 [40.330, 62.798] | 0 / 0 |
| mistral/gsm8k | 28.454 [17.544, 38.212] | 0.580 | 28.477 [17.536, 38.247] | 0 / 0 |
| mistral/arc | 16.458 [5.770, 27.890] | 0.379 | 16.463 [5.777, 27.890] | 0 / 0 |

## Prespecified conjunction versus shadow comparison

entropy_complete minus entropy_observe isolates the additional entropy condition with the monitoring machinery shared. For all 720 paired question-repeat records, conjunction never ends earlier than Complete (0 ordering failures). The conjunction can wait past the complete final-line stopping point; it therefore cannot be described as an earlier-stop token-saving method on these shared greedy paths.

| Model/task | E2E delta ms [95% CI] | Relative E2E % | Output-token delta [95% CI] | Contract accuracy delta pp [95% CI], descriptive |
|---|---:|---:|---:|---:|
| qwen/gsm8k | 1.724 [-9.401, 12.759] | 0.047 | 0.100 [0.000, 0.250] | 0.00 [0.00, 0.00] |
| qwen/arc | -3.183 [-12.780, 7.061] | -0.076 | 0.000 [0.000, 0.000] | 0.00 [0.00, 0.00] |
| mistral/gsm8k | 141.349 [61.836, 238.972] | 2.864 | 6.533 [3.117, 10.767] | -16.67 [-26.67, -8.33] |
| mistral/arc | 87.390 [18.119, 175.124] | 2.005 | 3.983 [0.883, 7.817] | -5.00 [-11.67, 0.00] |

## Supplemental direct conjunction versus Complete

This direct comparison is a post-run descriptive calculation, not one of the five prespecified contrasts in the frozen analyzer. It uses exactly the same paired question means, bootstrap algorithm and seed. It includes both monitoring cost and the entropy condition; do not label it the pure monitor cost.

| Model/task | E2E delta ms [95% CI] | Relative mean change % | Gen delta ms [95% CI] | Output-token delta | Accuracy delta pp |
|---|---:|---:|---:|---:|---:|
| qwen/gsm8k | 45.480 [35.693, 55.251] | 1.251 | 45.473 [35.704, 55.233] | 0.100 | 0.00 |
| qwen/arc | 48.000 [36.664, 60.457] | 1.167 | 48.002 [36.658, 60.459] | 0.000 | 0.00 |
| mistral/gsm8k | 169.803 [90.956, 266.292] | 3.460 | 169.808 [90.964, 266.275] | 6.533 | -16.67 |
| mistral/arc | 103.847 [32.046, 195.304] | 2.392 | 103.852 [32.052, 195.282] | 3.983 | -5.00 |

## Other practical contrasts

| Model/task | Complete − Uniform E2E ms [95% CI] | Relative % | Legacy entropy − Uniform E2E ms [95% CI] | Relative % | Legacy − Uniform token delta | Marker − Uniform E2E % |
|---|---:|---:|---:|---:|---:|---:|
| qwen/gsm8k | 32.964 [22.468, 44.427] | 0.915 | 90.408 [71.550, 111.871] | 2.510 | -0.433 | -1.991 |
| qwen/arc | 36.989 [27.302, 46.861] | 0.908 | 109.541 [90.704, 128.217] | 2.688 | -0.217 | -0.243 |
| mistral/gsm8k | -98.229 [-191.989, -19.468] | -1.962 | 57.550 [23.935, 88.590] | 1.150 | -2.117 | -4.206 |
| mistral/arc | -43.072 [-130.720, 27.156] | -0.982 | 67.461 [43.872, 88.747] | 1.539 | -0.850 | -3.076 |

## Stop-reason counts (180 measured calls per row)

| Model | Task | Policy | Stop-reason counts |
|---|---|---|---|
| qwen | gsm8k | uniform | eos: 180 |
| qwen | gsm8k | marker | policy: 180 |
| qwen | gsm8k | complete | eos: 174, policy: 6 |
| qwen | gsm8k | legacy_entropy | eos: 156, policy: 24 |
| qwen | gsm8k | entropy_observe | eos: 174, policy: 6 |
| qwen | gsm8k | entropy_complete | eos: 180 |
| qwen | arc | uniform | eos: 180 |
| qwen | arc | marker | eos: 9, policy: 171 |
| qwen | arc | complete | eos: 180 |
| qwen | arc | legacy_entropy | eos: 141, policy: 39 |
| qwen | arc | entropy_observe | eos: 180 |
| qwen | arc | entropy_complete | eos: 180 |
| mistral | gsm8k | uniform | cap: 3, eos: 177 |
| mistral | gsm8k | marker | cap: 3, policy: 177 |
| mistral | gsm8k | complete | cap: 3, eos: 132, policy: 45 |
| mistral | gsm8k | legacy_entropy | cap: 3, eos: 123, policy: 54 |
| mistral | gsm8k | entropy_observe | cap: 3, eos: 132, policy: 45 |
| mistral | gsm8k | entropy_complete | cap: 3, eos: 177 |
| mistral | arc | uniform | eos: 180 |
| mistral | arc | marker | eos: 3, policy: 177 |
| mistral | arc | complete | eos: 165, policy: 15 |
| mistral | arc | legacy_entropy | eos: 117, policy: 63 |
| mistral | arc | entropy_observe | eos: 165, policy: 15 |
| mistral | arc | entropy_complete | eos: 180 |

## Timing boundaries, environment and execution controls

- Both models ran sequentially on the same physical NVIDIA A800 80GB PCIe (UUID GPU-6e609e4f-e47e-5afe-2352-6478e5f2930a, PCI 35:00.0, 85,095,874,560 reported bytes). Although the server had two A800s, isolated timing uses only the first device. Driver 570.211.01; Python 3.11.12; PyTorch 2.6.0+cu124; CUDA 12.4; cuDNN 90100; Transformers 4.48.2; tokenizers 0.21.4. Backend transformers-sdpa-bf16; batch size 1; Torch CPU threads 2; interop threads 64. All records share environment fingerprint e0ed29c5b9119c06e1ddf5df380bc967dc336f744399af70e0c09a2dc6b0ded3.
- Qwen model: Qwen/Qwen2.5-7B-Instruct-1M, immutable revision e28526f7bb80e2a9c8af03b831a9af3812f18fba. Mistral: mistralai/Mistral-7B-Instruct-v0.3, immutable revision c170c708c41dac9275d15a8fff4eca08d52bab71. Model loaded bf16, SDPA, evaluation mode; greedy do_sample=False, num_beams=1, use_cache=True. TF32 matmul disabled; strict deterministic algorithms disabled. Repeat agreement was empirically verified, not guaranteed by a strict deterministic-kernel setting.
- Every model-worker attempt executed 2 warmup calls for each policy × task before measured calls: 24 warmups per model, 48 total for timing, excluded from the 4,320 measured calls. The warmup question was the first development question of each task. There was exactly one completed timing attempt per model; each completion receipt reports 2,160 measured jobs. Qwen measured run 2026-10-21 14:07:07–16:26:54 UTC; Mistral 16:29:03–19:17:07 UTC. Model loading (5.694 s / 5.352 s) is outside per-call timing.
- All question × repeat × policy jobs across both tasks are jointly shuffled before execution with seed 20261019. This is random call order, rather than fixed contiguous policy blocks; matched question policies share the same device. The frozen launch script enforces isolated timing and sequential model workers. Reconstructing make_jobs with frozen inputs/spec/selection reproduced the actual 2,160-record job order exactly for each model. Warmups are per policy/task before the randomized measured stream.
- E2E timing begins after CUDA synchronization and before chat templating, tokenization, host-to-device copy, and stopping-state setup; it ends after generation, final CUDA synchronization, output-ID conversion and final decoding. Generation timing begins after prompt/setup and a CUDA sync/reset_peak_memory_stats, wraps model.generate and a final CUDA sync. E2E excludes model loading, disk logging, remote network/API latency and queuing. Time-to-first-token is deliberately unmeasured (null). Entropy evaluation performs full-vocabulary softmax/log entropy and .item() each decoding step; nonuniform stopping criteria also decode the generated prefix each step. Thus the monitor cost is implementation-specific and includes host/device interaction.
- Max observed peak allocated memory is about 15.33 GB (Qwen) and 14.61 GB (Mistral), including resident parameters/cache. It is an allocation high-water mark, not FLOPs, energy, hardware scheduling, or physical compute allocation. No billing meter, dollar cost, power or energy measurement is present.

## Results wording suitable for the paper

On a warmed, isolated A800 with batch size one, computing token entropy without changing the stopping decisions or generated token path increased mean end-to-end latency by 16.5–51.2 ms per call (0.38–1.24% across the four model–task cells); all four question-cluster 95% intervals excluded zero. Therefore token-count equality does not imply equal serving time. The complete-answer controller was not universally faster than the uniform cap: the Qwen cells incurred approximately 0.91% additional end-to-end time, whereas Mistral GSM8K saved approximately 1.96%; the Mistral ARC interval included zero. The legacy entropy implementation saved only 0.22–2.12 output tokens per call on average while increasing mean end-to-end latency by 1.15–2.69%, with positive intervals in every cell. The marker controller produced zero contract-correct outputs, making its shorter latency unusable as evidence of successful-task cost savings. Adding an entropy condition to Complete never reduced generated-token length on verified shared greedy paths; none of its 720 timing calls ended through the policy trigger (717 EOS and 3 cap endings), and its exact output token IDs always matched Uniform. In this timing subset it therefore added monitoring without ever exercising an earlier stop, while incurring a substantial loss of descriptive contract-aware accuracy relative to Complete on Mistral. These observations support measuring successful outputs and wall-clock time together rather than treating output-token counts as a proxy for practical efficiency.

Do not generalize these results to arbitrary stopping implementations, API pricing, fleet-wide latency, high-throughput batching, concurrent requests, other devices, or GPU compute allocation. The repeated timing subset is small (60 questions/cell), model order is sequential, and kernel/thermal/clock/OS drift is not independently controlled across multiple hardware sessions. Randomized call order and identical shadow paths reduce certain confounds but do not remove all temporal hardware effects. P95 values are descriptive empirical quantiles without uncertainty intervals. The primary main-stage accuracy comparison is separate; timing accuracy must not replace it.

## Evidence locations

Paths below are relative to the V6 package root (`peerj_revision_20261022_v6/`). The frozen server backup is a sibling directory of V6. The companion `output/postrun/supplementary_timing_metrics.csv` is reconstructed directly from the raw JSONL; time columns are seconds, quality columns are fractions, and `NA_zero_correct` denotes an undefined token-per-correct ratio.

- Frozen project root: `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/`
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/results/revision_v5_1/timing-analysis.json`: saved summaries, prespecified paired contrasts and mechanism audits.
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/results/revision_v5_1/{qwen,mistral}.timing.s0-of-1.jsonl`: raw measurements.
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/results/revision_v5_1/{qwen,mistral}.timing.s0-of-1.meta.json`: protocol, provenance and actual worker software/device configuration.
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/results/revision_v5_1/{qwen,mistral}.timing.s0-of-1.attempts/*.json`: attempt and completion receipts.
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/results/revision_v5_1/preflight-timing-server.json`: server preflight; worker metadata are the authority for actual CPU-thread settings.
- `../server_operations_20261021/server_backup/completed_v5_1/ea54251aba1d63f6d608c556cfc8320b868d892fc0fa2b2e81cba07ca7980c8d/verified_contents/project/experiments/revision_v3/{analyze,core,engine,run,launch}.py`: frozen analysis, percentile definition, measurement boundaries, warmup/scheduling and timing isolation.
