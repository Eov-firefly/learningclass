JANUS v6 LaTeX project / LaTeX 稿件

主文件：main.tex
参考文献：references.bib

编译：使用 pdfLaTeX + BibTeX。
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

也可将本文件夹内容上传至 Overleaf，将 main.tex 设为主文件，选择 pdfLaTeX。
本项目采用 article 审阅排版（双倍行距、连续行号、5 张可编辑表格、作者-年份引文）。
这不是官方 PeerJ 类文件，也不表示已完成期刊全部投稿要求。

来源：peerj_revision_20261022_v6/output/revision/revised_manuscript.md
本项目仅转换排版、数学公式及引用形式，不修改实验数据或科学结论。
原 v6 包和服务器备份保持不变。

投稿前仍需核实作者姓名/顺序/单位/通信作者、资金/利益冲突/作者贡献/AI使用声明，
以及补充真实公开归档链接；独立人工语义评审目前未完成，正文仍如实标明。

已编译预览 PDF：output/pdf/main.pdf（18 页）。
main.bbl 为本次编译生成的参考文献内容，重新运行 BibTeX 后会自动更新。
本地已用 Tectonic 完成编译；无需模型权重、实验数据或服务器即可编辑和编译。
validation.json 和 SHA256SUMS 记录本次转换检查与文件校验值。
